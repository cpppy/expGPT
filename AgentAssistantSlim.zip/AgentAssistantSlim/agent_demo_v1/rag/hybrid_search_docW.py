import os

os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'

from llama_index.readers.file import UnstructuredReader
from llama_index.core import Document

# Define Hybrid Retriever
from llama_index.core.retrievers import BaseRetriever
from llama_index.core.indices.query.embedding_utils import get_top_k_embeddings
from llama_index.core import QueryBundle
from llama_index.core.schema import NodeWithScore
from typing import List, Any, Optional

from loguru import logger

import glob
from tqdm import tqdm


class HybridRetriever(BaseRetriever):
    """Hybrid retriever."""

    def __init__(
            self,
            vector_index,
            docstore,
            similarity_top_k: int = 2,
            out_top_k: Optional[int] = None,
            alpha: float = 0.5,
            **kwargs: Any,
    ) -> None:
        """Init params."""
        super().__init__(**kwargs)
        self._vector_index = vector_index
        self._embed_model = vector_index._embed_model
        self._retriever = vector_index.as_retriever(
            similarity_top_k=similarity_top_k
        )
        self._out_top_k = out_top_k or similarity_top_k
        self._docstore = docstore
        self._alpha = alpha

    def _retrieve(self, query_bundle: QueryBundle) -> List[NodeWithScore]:
        """Retrieve nodes given query."""

        # first retrieve chunks
        nodes = self._retriever.retrieve(query_bundle.query_str)

        # get documents, and embedding similiaryt between query and documents

        ## get doc embeddings
        docs = [self._docstore.get_document(n.node.index_id) for n in nodes]
        doc_embeddings = [d.embedding for d in docs]
        query_embedding = self._embed_model.get_query_embedding(
            query_bundle.query_str
        )

        ## compute doc similarities
        doc_similarities, doc_idxs = get_top_k_embeddings(
            query_embedding, doc_embeddings
        )

        ## compute final similarity with doc similarities and original node similarity
        result_tups = []
        for doc_idx, doc_similarity in zip(doc_idxs, doc_similarities):
            node = nodes[doc_idx]
            # weight alpha * node similarity + (1-alpha) * doc similarity
            full_similarity = (self._alpha * node.score) + (
                    (1 - self._alpha) * doc_similarity
            )
            print(
                f"Doc {doc_idx} (node score, doc similarity, full similarity): {(node.score, doc_similarity, full_similarity)}"
            )
            result_tups.append((full_similarity, node))

        result_tups = sorted(result_tups, key=lambda x: x[0], reverse=True)
        # update scores
        for full_score, node in result_tups:
            node.score = full_score

        return [n for _, n in result_tups][:self._out_top_k]



def main(debug=False):

    from agent_demo_v1.load_model import load_model
    llm, embed_model = load_model()

    reader = UnstructuredReader()
    all_md_files = glob.glob("/data/data/shuiwen_p1_notice/*.md")#[0:10]
    logger.debug(f'all_md_files: {all_md_files}')

    if not debug:
        all_md_files = []

    # import os
    # tags = list(set([os.path.basename(f).split('.')[0] for f in all_md_files]))
    # logger.debug(tags)

    docs = []
    for filepath in tqdm(all_md_files):
        raw_docs = reader.load_data(file=filepath, split_documents=True)
        for raw_doc in raw_docs:
            logger.debug(f'############################')
            logger.debug(raw_doc)
            logger.debug(f'metadata: {raw_doc.metadata}')

        # Hardcoded Index. Everything before this is ToC for all pages
        # Adjust this start_idx to suit your needs
        start_idx = 0
        # doc_metadata = raw_docs[0].metadata
        # doc_metadata.pop('page_number')
        # logger.info(f'doc_metadata: {doc_metadata}')
        doc_obj = Document(
            # # id_=str(filepath),
            # text="\n\n".join([d.get_content() for d in raw_docs[start_idx:]]),
            # metadata=doc_metadata

            id_=str(filepath),
            text="\n\n".join([d.get_content() for d in raw_docs[start_idx:]]),
            metadata={"path": str(filepath)},
        )
        logger.debug(str(filepath))
        docs.append(doc_obj)

    # Create Document Store
    from llama_index.core.storage.docstore import SimpleDocumentStore

    for doc in docs:
        embedding = embed_model.get_text_embedding(doc.get_content())
        doc.embedding = embedding

    docstore_persist_path = 'docstore_cache/docstore.db'
    if not os.path.exists(docstore_persist_path):
        docstore = SimpleDocumentStore()
        docstore.add_documents(docs)
        docstore.persist(persist_path=docstore_persist_path)
    else:
        docstore = SimpleDocumentStore.from_persist_path(persist_path=docstore_persist_path)

    # Build Vector Index
    from llama_index.core.schema import IndexNode
    from llama_index.core import (
        load_index_from_storage,
        StorageContext,
        VectorStoreIndex,
    )
    from llama_index.core.node_parser import SentenceSplitter
    from llama_index.core import SummaryIndex
    from llama_index.core.retrievers import RecursiveRetriever
    # import os
    # from tqdm.notebook import tqdm
    import pickle

    def build_index(docs, out_path: str = "storage/chunk_index"):
        nodes = []

        splitter = SentenceSplitter(chunk_size=512, chunk_overlap=70)
        for idx, doc in enumerate(tqdm(docs)):
            # print('Splitting: ' + str(idx))
            cur_nodes = splitter.get_nodes_from_documents([doc])
            for cur_node in cur_nodes:
                # ID will be base + parent
                file_path = doc.metadata["path"]
                new_node = IndexNode(
                    text=cur_node.text or "None",
                    index_id=str(file_path),
                    metadata=doc.metadata
                    # obj=doc
                )
                nodes.append(new_node)
        print("num nodes: " + str(len(nodes)))

        # save index to disk
        if not os.path.exists(out_path):
            index = VectorStoreIndex(nodes, embed_model=embed_model)
            index.set_index_id("simple_index")
            index.storage_context.persist(f"./{out_path}")
        else:
            # rebuild storage context
            storage_context = StorageContext.from_defaults(
                persist_dir=f"./{out_path}"
            )
            # load index
            index = load_index_from_storage(
                storage_context, index_id="simple_index", embed_model=embed_model
            )

        return index, nodes

    index, nodes = build_index(docs)

    if debug:
        # bm25 retriever
        bm25_docstore = SimpleDocumentStore()
        bm25_docstore.add_documents(nodes)
        from llama_index.retrievers.bm25 import BM25Retriever
        bm25_retriever = BM25Retriever.from_defaults(
            docstore=docstore, similarity_top_k=3
        )


    #################### hybrid retriever ###################
    top_k = 10
    out_top_k = 3
    hybrid_retriever = HybridRetriever(
        index, docstore, similarity_top_k=top_k, out_top_k=3, alpha=0
    )
    from llama_index.core.query_engine import RetrieverQueryEngine
    query_engine = RetrieverQueryEngine(hybrid_retriever)

    # response = query_engine.query("山东水文局引发给高村水文站的通知中具体要求了哪些任务？")
    # print(response)

    if debug:
        base_retriever = index.as_retriever(similarity_top_k=out_top_k)

        def show_nodes(nodes, out_len: int = 200):
            for idx, n in enumerate(nodes):
                print(f"\n\n >>>>>>>>>>>> ID {n.id_}: {n.metadata['path']}")
                print(n.get_content()[:out_len])

        query_str = "悬移质泥沙测验包含哪些内容?"

        nodes = hybrid_retriever.retrieve(query_str)

        show_nodes(nodes)

        base_nodes = base_retriever.retrieve(query_str)

        show_nodes(base_nodes)

        # Run Some Queries
        # from llama_index.core.query_engine import RetrieverQueryEngine
        # query_engine = RetrieverQueryEngine(hybrid_retriever)

        base_query_engine = index.as_query_engine(similarity_top_k=out_top_k)

        response = query_engine.query(query_str)
        print(f'################ hybrid search result ################')
        print(str(response))

        base_response = base_query_engine.query(query_str)
        print(f'################ base search result ################')
        print(str(base_response))

        # bm25 test
        response = bm25_retriever.retrieve(query_str)
        print(f'################ bm25 search result ################')
        for node in response:
            print('-------------')
            print(node)

    return query_engine


if __name__ == '__main__':
    import sys

    logger.remove()
    logger.add(sys.stderr, level="DEBUG")
    main(debug=False)
