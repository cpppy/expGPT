from pydantic import BaseModel, Field
from llama_index.core.output_parsers import PydanticOutputParser

from llama_index.core.query_pipeline import QueryPipeline
from llama_index.core import PromptTemplate


class ReportMeta(BaseModel):
    """Object representing a single movie."""
    year: int = Field(..., description="Year number in the given string.")
    location: str = Field(..., description="Location Name.")
    document_type: str = Field(..., description="Document type of the sample, such as 产品调研报告 or 年度或季度升级计划 etc.")




class ExtractShuiwenMetadata:

    def __init__(self, llm):

        output_parser = PydanticOutputParser(ReportMeta)
        json_prompt_str = """
                Please parse the year number and location name in {title}.
                \nOutput with the following JSON format:
                """

        json_prompt_str = output_parser.format(json_prompt_str)

        # add JSON spec to prompt template
        json_prompt_tmpl = PromptTemplate(json_prompt_str)

        self.qp = QueryPipeline(chain=[json_prompt_tmpl, llm, output_parser], verbose=True)

    def __call__(self, query):
        output = self.qp.run(title=query)
        return output



