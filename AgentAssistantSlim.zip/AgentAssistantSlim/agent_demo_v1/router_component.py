import os

os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'
os.environ['NUMEXPR_MAX_THREADS'] = '12'

from llama_index.core import PromptTemplate
from llama_index.core.llms import ChatMessage, MessageRole

from llama_index.core.agent.react.types import (
    ObservationReasoningStep,
)
from llama_index.core.agent import Task
from llama_index.core.query_pipeline import (
    AgentInputComponent,
    AgentFnComponent,
    ToolRunnerComponent
)
from llama_index.core.agent import AgentChatResponse
from typing import (
    Dict,
    Any,
    Set,
    List,
    Tuple, NamedTuple
)

from functools import partial

from agent_demo_v1.router.custom_qp import CustomQueryPipeline as QueryPipeline

from agent_demo_v1.router.parse_format import ResponseClassify, ActionSelected

from router.parser import CustomPydanticOutputParser
from agent_demo_v1 import api_params_parse


from loguru import logger
import json
import logging


## Agent Input Component
## This is the component that produces agent inputs to the rest of the components
## Can also put initialization logic here.
def agent_input_fn(task: Task, state: Dict[str, Any]) -> Dict[str, Any]:
    """Agent input function.

    Returns:
        A Dictionary of output keys and values. If you are specifying
        src_key when defining links between this component and other
        components, make sure the src_key matches the specified output_key.

    """
    # initialize current_reasoning
    if "current_reasoning" not in state:
        state["current_reasoning"] = []
    reasoning_step = ObservationReasoningStep(observation=task.input)
    state["current_reasoning"].append(reasoning_step)

    # add record
    task.extra_state['record'].append(dict(layername='input', messages=[('user', task.input)]))

    return {"input": task.input}


def action_cls_component_fn(
        task: Task, state: Dict[str, Any], llm, flow_params,
):

    logger.debug(f'task_input: {task.input}')
    # response_last_stage = flow_params['response_str']
    request_str = task.input

    ### add output parser
    TEMPLATE = """
       Here's a JSON schema to follow:
       {schema}

       Output a valid JSON object but do not repeat the schema.
       """

    output_parser = CustomPydanticOutputParser(output_cls=ActionSelected,
                                               pydantic_format_tmpl=TEMPLATE)

    ## query template
    json_prompt_str = """
           analyse the request content and give suggestion of the next step about this topic.
           there are several choices of the next step: \n
           1. RAG: 如果客户是在询问一些问题，该问题关系到黄河或者水文站的工作安排、记录，或者相关机构下发的通知内容。以及关于伊春的林业生态规划。请选择此接口。\n
           2. BackendSearch: 如果客户的请求内容是查询一些信息，比如：森林的蓄积量及变化、城市面积、森林覆盖率排行、森林植物总生物量等，请选择此接口。\n
           3. WebSearch: 如果客户请求的内容无法通过前面RAG或者Backend提供的功能解决，同时你认为通过互联网可以查询相关信息完成回答的时候，请选择此接口。\n

           you should select only one from the choices above.
           \n Now, the request content is: {request}.
           \n Output with the following JSON format:
           """

    # json_prompt_str = """
    #            analyse the request content and give suggestion of the next step about this topic.
    #            there are several choices of the next step: \n
    #            1. RAG: 如果用户是在询问问题，该问题关系到黄河或者水文站的工作安排、记录或通知内容, 以及关于伊春的林业生态规划。请选择此接口。\n
    #            2. BackendSearch: 如果用户的请求内容是查询一些信息，比如：森林的蓄积量及变化、城市面积、森林覆盖率排行、森林植物总生物量等，请选择此接口。\n
    #            3. WebSearch: 如果客户请求的内容无法通过前面RAG或者Backend提供的功能解决，同时你认为通过互联网可以查询相关信息完成回答的时候，请选择此接口。\n
    #
    #            you should select only one from the choices above.
    #            \n Now, the request content is: {request}.
    #            \n Output with the following JSON format:
    #            """
    json_prompt_str = output_parser.format(json_prompt_str)
    json_prompt_tmpl = PromptTemplate(json_prompt_str)
    qp_cls = QueryPipeline(chain=[json_prompt_tmpl, llm, output_parser])
    cls_response = qp_cls.run_component(request=request_str)
    logger.info(f'cls_response: {cls_response}')

    ret_response = {
        'task_input': request_str,
        "cls_response": cls_response['output'],
        "step": cls_response['output'].step,
        "is_done": True
    }

    # update record
    task.extra_state['record'].append(
        dict(layername='action_cls',
             messages=[
                 ('assistant', json.dumps({
                     "step": cls_response['output'].step,
                 }, indent=4, ensure_ascii=True))
             ])
    )

    return ret_response


def rag_component_fn(
        task: Task, state: Dict[str, Any], query_engine, flow_params,
):
    query_str = task.input

    response = query_engine.query(query_str)

    ret_response = {
        'response_str': str(response),
        'action_type': 'RAG',
        'is_done': True
    }

    # update record
    task.extra_state['record'].append(
        dict(layername='RAG',
             messages=[
                 ('assistant', json.dumps(ret_response, indent=4, ensure_ascii=False))
             ])
    )

    return ret_response


def backend_search_component_fn(
        task: Task, state: Dict[str, Any], llm, flow_params,
):
    query_str = task.input
    actions = api_params_parse.completion(query_str=query_str)
    actions = actions[0:1]

    ret_response = {
        "response_str": json.dumps(actions,
                                   # indent=4
                                   ensure_ascii=False),
        'action_type': 'BackendSearch',
        "is_done": True
    }

    # update record
    task.extra_state['record'].append(
        dict(layername='backend_search',
             messages=[
                 ('assistant', json.dumps(ret_response,
                                          # indent=4,
                                          ensure_ascii=False))
             ])
    )
    return ret_response


def web_search_component_fn(
        task: Task, state: Dict[str, Any], llm, flow_params,
):
    # try:
    #     query_str = task.input
    #     search_api = DuckDuckGoSearchAPI()
    #     context = search_api.call_for_agent(query_str)
    #
    #     # add branch
    #     prompt_str = """Answer the question based only on the following context:
    #             {context}
    #
    #             Question: {question}
    #             """
    #     prompt_tmpl = PromptTemplate(prompt_str)
    #     prompt = prompt_tmpl.format(context=context, question=query_str)
    #     llm_output = llm.complete(prompt)
    #     logger.debug(f'llm_output: {llm_output}')
    #     response_str = str(llm_output)
    # except Exception as e:
    #     logger.error(e)
    response_str = 'WebSearchAPI INVALID.'

    ret_response = {
        "response_str": response_str,
        'action_type': 'WebSearch',
        "is_done": True
    }
    # update record
    task.extra_state['record'].append(
        dict(layername='web_search',
             messages=[
                 ('assistant', json.dumps(ret_response, indent=4, ensure_ascii=False))
             ])
    )
    return ret_response


def unknown_action_component_fn(
        task: Task, state: Dict[str, Any], llm, flow_params,
):
    ret_response = {
        "response_str": 'Can not get valid action content.',
        'action_type': 'None',
        "is_done": False
    }

    # update record
    task.extra_state['record'].append(
        dict(layername='unknown_action',
             messages=[
                 ('assistant', json.dumps(ret_response, indent=4, ensure_ascii=True))
             ])
    )
    return ret_response


def process_agent_response_fn(
        task: Task, state: Dict[str, Any], response_dict: dict
):
    """Process agent response."""
    # return (
    #     AgentChatResponse(response_dict["response_str"]),
    #     response_dict["is_done"],
    # )

    # update record
    task.extra_state['record'].append(
        dict(layername='output',
             messages=[
                 ('assistant', response_dict["response_str"])
             ])
    )

    return (
        AgentChatResponse(response_dict["response_str"]),
        True,
    )


def build_agent_worker(debug=True):
    from agent_demo_v1.load_model import load_model
    llm, embed_model = load_model()

    input_component = AgentInputComponent(fn=agent_input_fn)

    action_cls_component = AgentFnComponent(fn=partial(action_cls_component_fn, llm=llm))

    from agent_demo_v1.rag import query_engine_multi
    query_engine = query_engine_multi.main()
    rag_component = AgentFnComponent(fn=partial(rag_component_fn, query_engine=query_engine))

    backend_search_component = AgentFnComponent(fn=partial(backend_search_component_fn, llm=llm))

    web_search_component = AgentFnComponent(fn=partial(web_search_component_fn, llm=llm))

    unknown_action_component = AgentFnComponent(fn=partial(unknown_action_component_fn, llm=llm))

    output_component = AgentFnComponent(fn=process_agent_response_fn)

    # from llama_index.core.query_pipeline import InputComponent
    # input = InputComponent()
    qp_router = QueryPipeline(verbose=True)
    qp_router.add_modules(
        {
            'Input': input_component,
            'ActionClassify': action_cls_component,
            'RAG': rag_component,
            'BackendSearch': backend_search_component,
            'WebSearch': web_search_component,
            'UnknownAction': unknown_action_component,
            'Output': output_component,

        }
    )
    qp_router.add_chain(['Input', 'ActionClassify'])
    qp_router.add_link(src='ActionClassify', dest='RAG',
                       condition_fn=lambda x: x['step'] == 'RAG',
                       input_fn=lambda x: x)
    qp_router.add_link(src='ActionClassify', dest='BackendSearch',
                       condition_fn=lambda x: x['step'] == 'BackendSearch',
                       input_fn=lambda x: x)
    qp_router.add_link(src='ActionClassify', dest='WebSearch',
                       condition_fn=lambda x: x['step'] == 'WebSearch',
                       input_fn=lambda x: x)
    qp_router.add_link(src='ActionClassify', dest='UnknownAction',
                       condition_fn=lambda x: x['step'] not in ['RAG', 'BackendSearch', 'WebSearch'],
                       input_fn=lambda x: x)
    qp_router.add_link(src='RAG', dest='Output')
    qp_router.add_link(src='BackendSearch', dest='Output')
    qp_router.add_link(src='WebSearch', dest='Output')
    qp_router.add_link(src='UnknownAction', dest='Output')

    ###################### AGENT ###################
    from llama_index.core.agent import AgentRunner
    from llama_index.core.callbacks import CallbackManager
    from agent_demo_v1.router.custom_qp_agent_worker import CustomQueryPipelineAgentWorker
    agent_worker = CustomQueryPipelineAgentWorker(qp_router)
    agent = AgentRunner(
        agent_worker=agent_worker,
        chat_history=[
            ChatMessage(role=MessageRole.SYSTEM,
                        content="You are a helpful assistant. can answer all questions from human beings."),
        ],
        callback_manager=CallbackManager([]),
        verbose=True
    )

    if debug:

        # start task
        task = agent.create_task(
            # input="山东水文局引发给高村水文站的通知中具体要求了哪些任务？",
            # input="帮我查询一下水资源局下发的关于防洪抗讯的通知",
            # input="我想了解一下伊春市各区域的森林覆盖率情况",
            # input="成都未来几天的天气情况",
            input='伊春森工的林地面积是多少？',

            # chat_history=[],
            extra_state=dict(a=1, b=2, record=[]),
        )
        logging.debug(f'task_input: {task.input}')
        # response = agent_input_component._run_component(task=task, state={})
        # logging.debug(f'response: {response}')
        # exit(0)

        # # chat history in task.memory
        # print(f'[task memory] {task.memory}')
        # print(f'[task extra_state] {task.extra_state}')
        # exit(0)

        step_output = agent.run_step(task.task_id)
        logging.info(f'step_output: {step_output}')

        # response = agent.chat("What are some tracks from the artist AC/DC? Limit it to 3")
        # print(response)

        record = task.extra_state['record']
        print(f'################## RECORD ################## ')
        for r in record:
            print(f'- layer: {r["layername"]}')
            for m in r['messages']:
                print(f'    {m}')

    return agent


if __name__ == '__main__':
    import sys

    logger.remove()
    logger.add(sys.stderr, level="INFO")

    build_agent_worker()
