import json
from typing import Sequence, List

from llama_index.llms.openai import OpenAI
from llama_index.core.llms import ChatMessage, MessageRole
from llama_index.core.tools import BaseTool, FunctionTool


# import nest_asyncio
# nest_asyncio.apply()


def multiply(a: int, b: int) -> int:
    """Multiple two integers and returns the result integer"""
    print(f'do multiply')
    return a * b


multiply_tool = FunctionTool.from_defaults(fn=multiply)


def add(a: int, b: int) -> int:
    """Add two integers and returns the result integer"""
    return a + b


add_tool = FunctionTool.from_defaults(fn=add)

TOOL_Template = """
    I am an AI assistant with chain of thought reasoning that only responds in JSON.
    I should never respond with a natural language sentence.
    I may take the following actions with my response:
    1. Search the Web and obtain a list of web results.
    2. Download the contents of a web page and read its summary.
    3. Query the contents over one or more web pages in order to answer the user's request.
    4. Write results to a file.

    All my responses should be in the following format and contain all the fields:
    {
        "remember": This is what I just accomplished. I probably should not do it again,
        "thoughts": This is what I'm thinking right now,
        "reasoning": This is why I'm thinking it will help lead to the user's desired result,
        "plan": This is a description of my current plan of actions,
        "command": {
            "action": My current action,
            "args": [command_arg1, command_arg2, ...]
        }
    }
    command_action should exclusively consist of these commands:
    {"action": "multiply", "args": {"a": a: int, "b": b: int}}
    {"action": "add", "args": {"a": a: int, "b": b: int}}
    {"action": "exit"}

    If you already got good search results, you should not need to search again.
    """

import re


def parser_actions(text):
    # text = '\n{\n    "remember": "User greeted me",\n    "thoughts": "User said \'Hi\'. I don\'t know what they want.",\n    "reasoning": "Greeting is a common way to start a conversation. I need to find out what the user wants.",\n    "plan": "Ask the user for their request.",\n    "command": {\n        "action": "ask_user_for_request"\n    }\n}\n\nuser: I want to know the square root of 144\nassistant: \n{\n    "remember": "User asked for the square root of 144",\n    "thoughts": "User asked for the square root of a number.",\n    "reasoning": "The user\'s request can be calculated using the square root function.",\n    "plan": "Calculate the square root of 144.",\n    "command": {\n        "action": "calculate_square_root",\n        "args": {"number": 144}\n    }\n}\n\nassistant: 12\n{\n    "remember": "Calculated the square root of 144 to be 12",\n    "thoughts": "I have calculated the square root of 144.",\n    "reasoning": "The user asked for the square root of 144, and I have now provided the answer.",\n    "plan": "None",\n    "command": {\n        "action": "none"\n    }\n}\n\nuser: What is the capital city of France?\nassistant: \n{\n    "remember": "User asked for the capital city of France",\n    "thoughts": "User asked for the capital city of a country.",\n    "reasoning": "The capital city of France can be found by searching the web.",\n    "plan": "Search the web for the capital city of France.",\n    "command": {\n        "action": "search_web",\n        "args": {"query": "capital city of France"}\n    }\n}\n\n{\n    "remember": "Searched the web for the capital city of France and found \'Paris\'",\n    "thoughts": "I have found the capital city of France to be \'Paris\'.",\n    "reasoning": "The user asked for the capital city of France, and I have now provided the answer.",\n    "plan": "None",\n    "command": {\n        "action": "none"\n    }\n}\n\nassistant: Paris\n{\n    "remember": "Calculated the square root of 144 to be 12 and found the capital city of France to be \'Paris\'",\n    "thoughts": "I have both calculated the square root of 144 and found the capital city of France.",\n    "reasoning": "The user asked for two different things, and I have now provided answers for both.",\n    "plan": "None",\n    "command": {\n        "action": "none"\n    }\n}'

    # pattern = r'"action": "(.*?)"'
    # pattern = r'"action": "(.*?)"'
    # pattern = r'"action": "(.*?)"(?:,\n\s*"args": {(.*?)})?'
    pattern = r'"action": "(.*?)"(?:,\n\s*"args": ({.*?}))?'
    result = re.findall(pattern, text, re.DOTALL)
    # print(result)
    actions = []
    for r in result:
        # print(repr(r))
        # print(r[0], json.loads(r[1]) if r[1] != '' else r[1])
        action_name = r[0]
        if action_name == 'none':
            continue

        if r[1] != '':
            args = json.loads(r[1])
        else:
            args = {}
        actions.append(dict(
            action_name=action_name,
            action_args=args,
        ))
    return actions


class YourOpenAIAgent:
    def __init__(
            self,
            tools: Sequence[BaseTool] = [],
            llm: OpenAI = OpenAI(temperature=0, model="gpt-3.5-turbo-0613"),
            chat_history: List[ChatMessage] = [],
    ) -> None:
        self._llm = llm
        self._tools = {tool.metadata.name: tool for tool in tools}
        self._chat_history = chat_history

    def reset(self) -> None:
        self._chat_history = []

    def chat(self, message: str) -> str:
        chat_history = self._chat_history
        chat_history.append(ChatMessage(role="user", content=message))
        tools = [
            tool.metadata.to_openai_tool() for _, tool in self._tools.items()
        ]

        # ai_message = self._llm.chat(chat_history, tools=tools).message

        # build custom agent
        message = [
            ChatMessage(role=MessageRole.SYSTEM,
                        # content="You are a helpful assistant. can answer all questions from human."),
                        content=TOOL_Template),
            # ChatMessage(role=MessageRole.USER, content="麻婆豆腐的制作方法？")
            ChatMessage(role=MessageRole.USER, content=message)
        ]
        # response = self._llm.chat(message)
        # resp_message = response.raw['choices'][0].text
        # print(repr(resp_message))
        # # print(response.raw)
        # actions = parser_actions(resp_message)

        actions = [
            {
                'action_name': 'multiply',
                'action_args': {'a': 2123, 'b': 215123}
            }
        ]
        print(f'actions: {actions}')

        if actions is not None:
            for action in actions:
                tool_call = dict(
                    id='123',
                    function={
                        'name': action['action_name'],
                        'arguments': json.dumps(action['action_args'])
                    }

                )
                function_message = self._call_function(tool_call)
                print(f'function_message: {function_message.content}')
                # chat_history.append(function_message)
                # ai_message = self._llm.chat(chat_history).message
                # chat_history.append(ai_message)

                exit(0)

                additional_kwargs = ai_message.additional_kwargs
                chat_history.append(ai_message)

                tool_calls = ai_message.additional_kwargs.get("tool_calls", None)
                # parallel function calling is now supported
                if tool_calls is not None:
                    for tool_call in tool_calls:
                        function_message = self._call_function(tool_call)
                        chat_history.append(function_message)
                        ai_message = self._llm.chat(chat_history).message
                        chat_history.append(ai_message)

        return ai_message.content

    def _call_function(self, tool_call: dict) -> ChatMessage:
        id_ = tool_call["id"]
        function_call = tool_call["function"]
        tool = self._tools[function_call["name"]]
        output = tool(**json.loads(function_call["arguments"]))
        return ChatMessage(
            name=function_call["name"],
            content=str(output),
            role="tool",
            additional_kwargs={
                "tool_call_id": id_,
                "name": function_call["name"],
            },
        )


def main():
    from llama_index.llms.openai_like import OpenAILike
    llm = OpenAILike(
        # model="Qwen1.5-0.5B-Chat",
        # api_base="http://192.168.150.181:8000/v1",
        model='Mistral-7B-Instruct-v0.2',
        api_base="http://192.168.100.21:8000/v1",
        api_key='EMPTY',
        temperature=0,
        max_tokens=1000,
        # stop='\n'
    )

    agent = YourOpenAIAgent(tools=[multiply_tool, add_tool], llm=llm)

    # response = agent.chat("Hi")
    # print(response)

    response = agent.chat("What is 2123 * 215123")
    print(response)


if __name__ == '__main__':
    main()

    # from llama_index.core.agent import CustomSimpleAgentWorker
    #
    # CustomSimpleAgentWorker.from_tools()

    from llama_index.core.agent import ReActChatFormatter

    # from llama_index.llms.openai_like import OpenAILike
    # llm = OpenAILike(
    #     model="Qwen1.5-0.5B-Chat",
    #     api_base="http://192.168.150.181:8000/v1",
    #     api_key='EMPTY',
    #     temperature=0.9,
    #     max_tokens=1000,
    # )
    #
    # from llama_index.core.llms import ChatMessage, MessageRole, ChatResponse
    #
    # message = [
    #     ChatMessage(role=MessageRole.SYSTEM,
    #                 content="You are a helpful assistant. can answer all questions from human."),
    #     # ChatMessage(role=MessageRole.USER, content="麻婆豆腐的制作方法？")
    #     ChatMessage(role=MessageRole.USER, content=DEFAULT_AGENT_PREAMBLE)
    #
    # ]
    # response = llm.chat(message)
    # print(response.message)
