import os

os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'

from llama_index.core.agent import (
    CustomSimpleAgentWorker,
    Task,
    AgentChatResponse,
)
from typing import Dict, Any, List, Tuple, Optional
from llama_index.core.tools import BaseTool, QueryEngineTool
from llama_index.core.program import LLMTextCompletionProgram
from llama_index.core.output_parsers import PydanticOutputParser
from llama_index.core.output_parsers import SelectionOutputParser, ChainableOutputParser, LangchainOutputParser
from llama_index.core.query_engine import RouterQueryEngine
from llama_index.core import ChatPromptTemplate, PromptTemplate
from llama_index.core.selectors import PydanticSingleSelector
from llama_index.core.bridge.pydantic import Field, BaseModel

from llama_index.core.llms import ChatMessage, MessageRole

DEFAULT_PROMPT_STR = """
Given previous question/response pairs, please determine if an error has occurred in the response, and suggest \
    a modified question that will not trigger the error.

Examples of modified questions:
- The question itself is modified to elicit a non-erroneous response
- The question is augmented with context that will help the downstream system better answer the question.
- The question is augmented with examples of negative responses, or other negative questions.

An error means that either an exception has triggered, or the response is completely irrelevant to the question.

Please return the evaluation of the response in the following JSON format.

"""


'''
I will give you the format at first, then, I will give you one question.
You need to give me only one JSON object, do not repeat and generate more question/response pairs.
'''


def get_chat_prompt_template(
        system_prompt: str, current_reasoning: Tuple[str, str]
) -> ChatPromptTemplate:
    system_msg = ChatMessage(role=MessageRole.SYSTEM, content=system_prompt)
    messages = [system_msg]
    for raw_msg in current_reasoning:
        if raw_msg[0] == "user":
            messages.append(
                ChatMessage(role=MessageRole.USER, content=raw_msg[1])
            )
        else:
            messages.append(
                ChatMessage(role=MessageRole.ASSISTANT, content=raw_msg[1])
            )
    return ChatPromptTemplate(message_templates=messages)


class ResponseEval(BaseModel):
    """Evaluation of whether the response has an error."""

    has_error: bool = Field(
        ..., description="Whether the response has an error."
    )
    new_question: str = Field(..., description="The suggested new question.")
    explanation: str = Field(
        ...,
        description=(
            "The explanation for the error as well as for the new question."
            "Can include the direct stack trace as well."
        ),
    )


class ResponseEstimate(BaseModel):
    """Evaluation of whether the response has an error."""

    has_error: bool = Field(
        ..., description="Whether the response has an error."
    )
    # new_question: str = Field(..., description="The suggested new question.")
    valid_answer: bool = Field(
        ...,
        description="Whether the response message contain all the information that can answer the user's question?"
    )
    explanation: str = Field(
        ...,
        description=(
            "The explanation for the error as well as for the judgement of valid answer."
            "Can include the direct stack trace as well."
        ),
    )
    new_question: str = Field(..., description="The suggested new question.")


from llama_index.core.bridge.pydantic import PrivateAttr


# class RouterQueryEngine:
#     def __init__(self):
#         pass
#
#     def query(self, text):
#         return f'[RouterQueryEngine] response for text: {text}.'


class RetryAgentWorker(CustomSimpleAgentWorker):
    """Agent worker that adds a retry layer on top of a router.

    Continues iterating until there's no errors / task is done.

    """

    prompt_str: str = Field(default=DEFAULT_PROMPT_STR)
    max_iterations: int = Field(default=10)

    _router_query_engine: RouterQueryEngine = PrivateAttr()

    def __init__(self, tools: List[BaseTool], **kwargs: Any) -> None:
        """Init params."""
        # validate that all tools are query engine tools
        logging.info(f'tool_names: {[tool.metadata.name for tool in tools]}')
        for tool in tools:
            if not isinstance(tool, QueryEngineTool):
                raise ValueError(
                    f"Tool {tool.metadata.name} is not a query engine tool."
                )
        # self._router_query_engine = RouterQueryEngine(
        #     selector=PydanticSingleSelector.from_defaults(),
        #     query_engine_tools=tools,
        #     verbose=kwargs.get("verbose", False),
        # )

        # self._router_query_engine = RouterQueryEngine()

        from router.llm_selector_rel import CustomLLMSingleSelector
        self._router_query_engine = RouterQueryEngine(
            # selector=PydanticSingleSelector.from_defaults(),
            selector=CustomLLMSingleSelector.from_defaults(),
            query_engine_tools=tools,
            verbose=kwargs.get("verbose", False),
        )

        super().__init__(
            tools=tools,
            **kwargs,
        )

    def _initialize_state(self, task: Task, **kwargs: Any) -> Dict[str, Any]:
        """Initialize state."""
        return {"count": 0, "current_reasoning": []}

    def _run_step(
            self, state: Dict[str, Any], task: Task, input: Optional[str] = None
    ) -> Tuple[AgentChatResponse, bool]:
        """Run step.

        Returns:
            Tuple of (agent_response, is_done)

        """
        logging.debug(f'########################## STEP: {state["count"]} ##########################')

        if "new_input" not in state:
            new_input = task.input
        else:
            new_input = state["new_input"]

        # first run router query engine
        response = self._router_query_engine.query(new_input)
        logging.debug(f'response from query_engine: {response}')

        # append to current reasoning
        state["current_reasoning"].extend([
            ("user", new_input),
            ("assistant", str(response))
        ])

        # Then, check for errors
        # dynamically create pydantic program for structured output extraction based on template
        chat_prompt_tmpl = get_chat_prompt_template(
            self.prompt_str, state["current_reasoning"]
        )

        logging.debug(f'chat_prompt_template: {chat_prompt_tmpl}')

        # same as llm_chain, define prompts and llm, then get response which has been parsed by output_parser
        # llm_program = LLMTextCompletionProgram.from_defaults(
        #     # output_parser=PydanticOutputParser(output_cls=ResponseEval),
        #     output_parser=PydanticOutputParser(output_cls=ResponseEstimate),
        #     prompt=chat_prompt_tmpl,
        #     llm=self.llm,
        #     verbose=True,
        # )

        from router.parser import CustomPydanticOutputParser
        from router.llm_program import CustomLLMTextCompletionProgram
        llm_program = CustomLLMTextCompletionProgram.from_defaults(
            # output_parser=PydanticOutputParser(output_cls=ResponseEval),
            # output_parser=CustomPydanticOutputParser(output_cls=ResponseEval),
            output_parser=CustomPydanticOutputParser(output_cls=ResponseEstimate),
            prompt=chat_prompt_tmpl,
            llm=self.llm,
            verbose=True,
        )
        # run program, look at the result
        response_eval = llm_program(
            query_str=new_input, response_str=str(response)
        )
        logging.debug(f'response_eval: {response_eval}')
        # exit(0)

        # if not response_eval.has_error:
        #     is_done = True
        # else:
        #     is_done = False
        # state["new_input"] = response_eval.new_question
        #
        # is_done = False

        ########### for ResponseEstimate as output_cls
        if response_eval.valid_answer:
            is_done = True
        else:
            is_done = False
        state["new_input"] = response_eval.new_question

        from llm_backend.chat_cli import bcolors
        if self.verbose:
            print(bcolors.OKGREEN + f"> Question: {new_input}" + bcolors.ENDC)
            print(bcolors.OKGREEN + f"> Response: {response}" + bcolors.ENDC)
            print(bcolors.OKGREEN + f"> Response eval: {response_eval.dict()}" + bcolors.ENDC)

        # return response
        return AgentChatResponse(response=str(response)), is_done

    def _finalize_task(self, state: Dict[str, Any], **kwargs) -> None:
        """Finalize task."""
        # nothing to finalize here
        # this is usually if you want to modify any sort of
        # internal state beyond what is set in `_initialize_state`
        logging.info(f'[FINALIZE TASK] finalize task.')
        logging.info(f'state: {state}')
        logging.info(f'kwargs: {kwargs}')
        pass


def load_model():
    from llama_index.llms.openai_like import OpenAILike
    llm = OpenAILike(
        # model="Qwen1.5-0.5B-Chat",
        # api_base="http://192.168.150.181:8000/v1",
        model='Mistral-7B-Instruct-v0.2',
        api_base="http://192.168.100.21:8000/v1",
        api_key='EMPTY',
        temperature=0.,
        max_tokens=1000,
    )

    from llama_index.embeddings.huggingface import HuggingFaceEmbedding
    from llama_index.core import Settings

    Settings.embed_model = HuggingFaceEmbedding(
        model_name="BAAI/bge-small-en-v1.5"
    )

    Settings.llm = llm
    return llm


def main():
    llm = load_model()

    from llama_index.core.tools import QueryEngineTool
    from sqlalchemy import (
        create_engine,
        MetaData,
        Table,
        Column,
        String,
        Integer,
        select,
        column,
    )
    from llama_index.core import SQLDatabase

    engine = create_engine("sqlite:///:memory:", future=True)
    # engine = create_engine("sqlite:///local_cache.db", future=True)
    metadata_obj = MetaData()
    # create city SQL table
    table_name = "city_stats"
    city_stats_table = Table(
        table_name,
        metadata_obj,
        Column("city_name", String(16), primary_key=True),
        Column("population", Integer),
        Column("country", String(16), nullable=False),
    )

    metadata_obj.create_all(engine)

    from sqlalchemy import insert

    rows = [
        {"city_name": "Toronto", "population": 2930000, "country": "Canada"},
        {"city_name": "Tokyo", "population": 13960000, "country": "Japan"},
        {"city_name": "Berlin", "population": 3645000, "country": "Germany"},
    ]
    for row in rows:
        stmt = insert(city_stats_table).values(**row)
        with engine.begin() as connection:
            cursor = connection.execute(stmt)

    from llama_index.core.query_engine import NLSQLTableQueryEngine

    sql_database = SQLDatabase(engine, include_tables=["city_stats"])
    sql_query_engine = NLSQLTableQueryEngine(
        llm=llm,
        sql_database=sql_database,
        tables=["city_stats"],
        verbose=True
    )
    sql_tool = QueryEngineTool.from_defaults(
        query_engine=sql_query_engine,
        description=(
            "Useful for translating a natural language query into a SQL query over"
            " a table containing: city_stats, containing the population/country of"
            " each city"
        ),
    )

    from llama_index.readers.wikipedia import WikipediaReader
    from llama_index.core import VectorStoreIndex

    cities = ["Toronto", "Berlin", "Tokyo"]
    cache = './wiki_cities.pkl'
    import pickle
    if not os.path.exists(cache):
        wiki_docs = WikipediaReader().load_data(pages=cities)
        with open(cache, 'wb') as f:
            pickle.dump(wiki_docs, f)
    else:
        with open(cache, 'rb') as f:
            wiki_docs = pickle.load(f)

    # print(wiki_docs)

    # build a separate vector index per city
    # You could also choose to define a single vector index across all docs, and annotate each chunk by metadata
    vector_tools = []
    for city, wiki_doc in zip(cities, wiki_docs):
        vector_index = VectorStoreIndex.from_documents([wiki_doc])
        vector_query_engine = vector_index.as_query_engine()
        vector_tool = QueryEngineTool.from_defaults(
            query_engine=vector_query_engine,
            description=f"Useful for answering semantic questions about {city}",
        )
        vector_tools.append(vector_tool)

    from llama_index.core.agent import AgentRunner
    # from llama_index.llms.openai import OpenAI
    # llm = OpenAI(model="gpt-4")

    print(sql_tool.metadata.fn_schema_str)
    print(vector_tools[0].metadata.fn_schema_str)
    # {"type": "object", "properties": {"input": {"title": "Input", "type": "string"}}, "required": ["input"]}
    # {"type": "object", "properties": {"input": {"title": "Input", "type": "string"}}, "required": ["input"]}
    # exit(0)

    callback_manager = llm.callback_manager

    query_engine_tools = [sql_tool] + vector_tools
    agent_worker = RetryAgentWorker.from_tools(
        query_engine_tools,
        llm=llm,
        verbose=True,
        callback_manager=callback_manager,
    )
    agent = AgentRunner(agent_worker, callback_manager=callback_manager)

    # response = agent.chat(
    #     "Which countries are each city from?"
    # )
    # print(f'final response: {str(response)}')

    task = agent.create_task(
        # "Which country are Beijing city from?"
        # "Which countries are each city from?"
        # "Which countries are several famous cities from?"
        "Find several famous cities and tell me which countries are they come from ?"
    )

    for i in range(10):
        step_output = agent.run_step(task.task_id)
        print(f'step_output: {step_output}')



if __name__ == '__main__':
    import logging
    import sys

    logging.basicConfig(stream=sys.stdout,
                        level=logging.DEBUG,
                        format="[%(levelname)s] %(filename)s[%(levelno)s]{%(funcName)s} %(message)s")

    # logging.getLogger().addHandler(logging.StreamHandler(stream=sys.stdout))
    main()
