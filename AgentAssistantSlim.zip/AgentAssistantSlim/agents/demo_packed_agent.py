from llama_index.agent.openai import OpenAIAgent
from llama_index.llms.openai import OpenAI




llm = OpenAI(model="gpt-3.5-turbo-0613")
agent = OpenAIAgent.from_tools(
    [multiply_tool, add_tool], llm=llm, verbose=True
)
