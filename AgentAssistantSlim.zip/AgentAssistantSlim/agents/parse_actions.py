import re
import json

# 输入字符串
input_str = '''
{
    "remember": "User greeted me",
    "thoughts": "User said 'Hi'. I don't know what they want.",
    "reasoning": "Greeting is a common way to start a conversation. I need to find out what the user wants.",
    "plan": "Ask the user for their request.",
    "command": {
        "action": "ask_user_for_request"
    }
}

user: I want to know the square root of 144
assistant: 
{
    "remember": "User asked for the square root of 144",
    "thoughts": "User asked for the square root of a number.",
    "reasoning": "The user's request can be calculated using the square root function.",
    "plan": "Calculate the square root of 144.",
    "command": {
        "action": "calculate_square_root",
        "args": {"number": 144}
    }
}

assistant: 12
{
    "remember": "Calculated the square root of 144 to be 12",
    "thoughts": "I have calculated the square root of 144.",
    "reasoning": "The user asked for the square root of 144, and I have now provided the answer.",
    "plan": "None",
    "command": {
        "action": "none"
    }
}

user: What is the capital city of France?
assistant: 
{
    "remember": "User asked for the capital city of France",
    "thoughts": "User asked for the capital city of a country.",
    "reasoning": "The capital city of France can be found by searching the web.",
    "plan": "Search the web for the capital city of France.",
    "command": {
        "action": "search_web",
        "args": {"query": "capital city of France"}
    }
}

{
    "remember": "Searched the web for the capital city of France and found 'Paris'",
    "thoughts": "I have found the capital city of France to be 'Paris'.",
    "reasoning": "The user asked for the capital city of France, and I have now provided the answer.",
    "plan": "None",
    "command": {
        "action": "none"
    }
}

assistant: Paris
{
    "remember": "Calculated the square root of 144 to be 12 and found the capital city of France to be 'Paris'",
    "thoughts": "I have both calculated the square root of 144 and found the capital city of France.",
    "reasoning": "The user asked for two different things, and I have now provided answers for both.",
    "plan": "None",
    "command": {
        "action": "none"
    }
}
'''
# 定义正则表达式匹配模式
pattern = r"\{(.*?)\}"

# 匹配多个JSON字符串
matches = re.findall(pattern, input_str, re.DOTALL)

output_data = []

# 处理每个匹配结果
for match in matches:
    match = match.replace('\n', '').replace('    ', '')
    data = json.loads("{" + match + "}")
    output_data.append(data)

# 输出JSON格式数据
print(json.dumps(output_data, indent=4))