


def main():

    from jinja2 import Template
    template = Template('Hello {{ name }}!')
    template.render(name='John Doe')
    print(template)


if __name__=='__main__':

    main()