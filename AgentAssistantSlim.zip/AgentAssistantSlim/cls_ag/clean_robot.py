from llama_index.core import PromptTemplate
from llama_index.core.query_pipeline import QueryPipeline, RouterComponent

from llama_index.core.bridge.pydantic import Field, BaseModel

from loguru import logger
import json


def main():

    from agents.demo_custom_agent_v2 import load_model
    llm = load_model(with_embedding=False)

    # prompt_str = "You are an excellent email processing robot." \
    #              "Referring to the title and body of the email, please sort out the body parts, extract the effective content, and form a new body.\n"\
    #              "The body of the email quotes the body of the email you are currently replying to. Please do not be disturbed by the quoted email.\n"\
    #              "The email's title and body provided as below:\n" \
    #              "\n Title: {title}" \
    #              "\n Body: {body}" \
    #              "\n Now, please output the new version of body content." \
    #              "Body: "

    prompt_str = "You are an excellent email processing robot." \
                 "Referring to the title and body of the email, please sort out the body parts, extract the effective content, and form a new body.\n" \
                 "if the body contain the email you are currently replying to. Please delete this quoted email.\n" \
                 "The email's title and body provided as below:\n" \
                 "\n Title: {title}" \
                 "\n Body: {body}" \
                 "\n Now, please output the new version of body content."

    prompt_tmpl = PromptTemplate(prompt_str)

    qp1 = QueryPipeline(chain=[prompt_tmpl, llm])

    from cls_ag import load_data
    mails = load_data.main(mail_tag='to_reply')
    logger.info(f'n_mails: {len(mails)}')
    title = mails[0]['subject']
    body = mails[0]['body']
    print('-----------------------------------')
    print(f'[title] {title}')
    print(f'[body] {body}')
    print(f'----------------------------------')
    response = qp1.run(title=title, body=body)
    logger.debug(f'response: {response.text}')

    return qp1


def clean_v2():
    from agents.demo_custom_agent_v2 import load_model
    llm = load_model(with_embedding=False)

    # prompt_str = "You are an excellent email processing robot." \
    #              "Referring to the title and body of the email, please sort out the body parts, extract the effective content, and form a new body.\n"\
    #              "The body of the email quotes the body of the email you are currently replying to. Please do not be disturbed by the quoted email.\n"\
    #              "The email's title and body provided as below:\n" \
    #              "\n Title: {title}" \
    #              "\n Body: {body}" \
    #              "\n Now, please output the new version of body content." \
    #              "Body: "

    prompt_str = "You are an excellent email processing robot." \
                 "Referring to the title and body of the email, please sort out the body parts, extract the effective content, and form a new body.\n" \
                 "if the body contain the email you are currently replying to. Please delete this quoted email.\n" \
                 "The email's title and body provided as below:\n" \
                 "\n Title: {title}" \
                 "\n Body: {body}" \
                 "\n Now, please output the new version of body content."

    prompt_tmpl = PromptTemplate(prompt_str)

    qp1 = QueryPipeline(chain=[prompt_tmpl, llm])

    from cls_ag import load_data
    mails = load_data.main(mail_tag='to_reply')
    logger.info(f'n_mails: {len(mails)}')
    title = mails[0]['subject']
    body = mails[0]['body']
    print('-----------------------------------')
    print(f'[title] {title}')
    print(f'[body] {body}')
    print(f'----------------------------------')
    response = qp1.run(title=title, body=body)
    logger.debug(f'response: {response.text}')

    return qp1


if __name__ == '__main__':
    import sys

    logger.remove()
    logger.add(sys.stderr, level="DEBUG")

    # main()
    clean_v2()

