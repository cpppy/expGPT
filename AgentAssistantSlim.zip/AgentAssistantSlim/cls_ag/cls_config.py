CLASS_DETAILS = [
    dict(
        class_name="Bounce",
        description="Hard Bounce or Soft Bounce. "
                    "A hard bounce indicates a permanent reason an email can't be delivered. "
                    "Common reasons include invalid recipient email address, "
                    "recipient email address doesn't exist, "
                    "recipient email server has permanently blocked delivery, and more. "
                    "A soft bounce indicates a temporary delivery issue. "
                    "Common reasons include mailbox is full (over quota), "
                    "mailbox isn't configured correctly, mailbox is inactive, "
                    "recipient email server is down or offline, email message is too large, "
                    "email message doesn't meet the recipient server's policies, and more.",
        sub_classes=[
            dict(
                class_name='Hard Bounce',
                description="A hard bounce indicates a permanent reason an email can't be delivered. "
                            "Common reasons include invalid recipient email address, "
                            "recipient email address doesn't exist, "
                            "recipient email server has permanently blocked delivery, and more. ",
            ),
            dict(
                class_name='Soft Bounce',
                description="A soft bounce indicates a temporary delivery issue. "
                            "Common reasons include mailbox is full (over quota), "
                            "mailbox isn't configured correctly, mailbox is inactive, "
                            "recipient email server is down or offline, email message is too large, "
                            "email message doesn't meet the recipient server's policies, and more.",
            )
        ],
        examples=[
            dict(
                class_name='Hard Bounce',
                title='Mail delivery failed: returning message to sender',
                body="""This message was created automatically by mail delivery software.

A message that you sent could not be delivered to one or more of its recipients. This is a permanent error.

The following address failed:

    bahar.choudhary@baharchy.com:
        SMTP error from remote server for RCPT TO command, host: baharchy-com.mail.protection.outlook.com (52.101.89.2) reason: 550 5.4.1 Recipient address rejected: Access denied. [LO1PEPF000022FE.GBRP 265.PROD.OUTLOOK.COM 2024-03-10T23:06:00.461Z 08DC3FF4C6F8C802]
"""
            ),
            dict(
                class_name='Hard Bounce',
                title="Undelivered Mail Returned to Sender",
                body="""This is the mail system at host mailout-pe-b.jellyfish.systems.

I'm sorry to have to inform you that your message could not
be delivered to one or more recipients. It's attached below.

For further assistance, please send mail to postmaster.

If you do so, please include this problem report. You can
delete your own text from the attached returned message.

                   The mail system

<uk.transcripts@auscript.com>: host aspmx.l.google.com[142.251.2.27] said:
    550-5.1.1 The email account that you tried to reach does not exist. Please
    try 550-5.1.1 double-checking the recipient's email address for typos or
    550-5.1.1 unnecessary spaces. For more information, go to 550 5.1.1
    https://support.google.com/mail/?p=NoSuchUser
    k18-20020a6568d2000000b005e47afd5c60si6033603pgt.646 - gsmtp (in reply to
    RCPT TO command)"""
            ),
            dict(
                class_name='Hard Bounce',
                title="Undeliverable: greeting",
                description="""Your message to sebastian.schroeder@schmelter-olpe.de couldn't be delivered.
sebastian.schroeder wasn't found at schmelter-olpe.de.
newsletter	Office 365	sebastian.schroeder
Action Required		Recipient
Unknown To address		

How to Fix It
The address may be misspelled or may not exist. Try one or more of the following:
Send the message again following these steps: In Outlook, open this non-delivery report (NDR) and choose Send Again from the Report ribbon. In Outlook on the web, select this NDR, then select the link "To send this message again, click here." Then delete and retype the entire recipient address. If prompted with an Auto-Complete List suggestion don't select it. After typing the complete address, click Send.
Contact the recipient (by phone, for example) to check that the address exists and is correct.
The recipient may have set up email forwarding to an incorrect address. Ask them to check that any forwarding they've set up is working correctly.
Clear the recipient Auto-Complete List in Outlook or Outlook on the web by following the steps in this article: Fix email delivery issues for error code 5.1.10 in Office 365, and then send the message again. Retype the entire recipient address before selecting Send.
If the problem continues, forward this message to your email admin. If you're an email admin, refer to the More Info for Email Admins section below.

Was this helpful? Send feedback to Microsoft.

More Info for Email Admins
Status code: 550 5.1.10

This error occurs because the sender sent a message to an email address hosted by Office 365 but the address is incorrect or doesn't exist at the destination domain. The error is reported by the recipient domain's email server, but most often it must be fixed by the person who sent the message. If the steps in the How to Fix It section above don't fix the problem, and you're the email admin for the recipient, try one or more of the following:

The email address exists and is correct - Confirm that the recipient address exists, is correct, and is accepting messages.

Synchronize your directories - If you have a hybrid environment and are using directory synchronization make sure the recipient's email address is synced correctly in both Office 365 and in your on-premises directory.

Errant forwarding rule - Check for forwarding rules that aren't behaving as expected. Forwarding can be set up by an admin via mail flow rules or mailbox forwarding address settings, or by the recipient via the Inbox Rules feature.

Recipient has a valid license - Make sure the recipient has an Office 365 license assigned to them. The recipient's email admin can use the Office 365 admin center to assign a license (Users > Active Users > select the recipient > Assigned License > Edit).

Mail flow settings and MX records are not correct - Misconfigured mail flow or MX record settings can cause this error. Check your Office 365 mail flow settings to make sure your domain and any mail flow connectors are set up correctly. Also, work with your domain registrar to make sure the MX records for your domain are configured correctly.

For more information and additional tips to fix this issue, see Fix email delivery issues for error code 5.1.10 in Office 365.

Original Message Details
Created Date:	3/12/2024 2:20:24 AM
Sender Address:	newsletter@globalipmarket.com
Recipient Address:	sebastian.schroeder@schmelter-olpe.de
Subject:	greeting

Error Details
Error:	550 5.1.10 RESOLVER.ADR.RecipientNotFound; Recipient sebastian.schroeder@schmelter-olpe.de not found by SMTP address lookup
Message rejected by:	PR3P193MB0713.EURP193.PROD.OUTLOOK.COM
"""
            ),
            dict(
                class_name='Soft Bounce',
                title="Mail delivery failed: returning message to sender",
                body="""This message was created automatically by mail delivery software.

A message that you sent could not be delivered to one or more of its recipients. This is a permanent error.

The following address failed:

    rbnhandel24@gmx.de:
        SMTP error from remote server for RCPT TO command, host: mx01.emig.gmx.net (212.227.17.5) reason: 552-Requested mail action aborted: exceeded storage allocation 552-Quota exceeded.
552 For explanation visit https://postmaster.gmx.net/de/case?c=r1503&i=ip&
v=74.208.4.194&r=1Mf2Re-1rCFSl0OkM-00m6Cw
"""
            )
        ]
    ),

    dict(
        class_name="Unsubscribe",
        description="The recipient doesn't want to be contacted.",
        sub_classes=[],
        examples=[
            dict(
                title="RE: Connect With Top Brands & Expand Your Healthcare Business",
                body="""Please remove me. 
Sent from my Galaxy

	Alistair Benn
CEO

MHH International

+44 (0) 7968 797 834
+44 (0) 7968 797 834
aj@mhhinternational.com
www.mhhinternational.com

	 	Rated Excellent on Trustpilot
	86.7i Dunsfold Park, Stovolds Hill
	, 
	Cranleigh
	, 
	Surrey
	, 
	GU68TB
	, 
	UK

This e-mail and any files transmitted with it are confidential and intended solely for the use of the individual or entity to whom they are addressed.  If you have received this e-mail in error, please notify the sender.
MHH International Ltd may not be held responsible for the content of this e-mail as it may reflect the personal views of the sender and not those of the company.
MHH International Ltd runs anti-virus software on all workstations but it cannot be held responsible for any infected files that you may receive. MHH International Ltd advises all recipients to virus scan any file attachments.

-------- Original message --------
From: Henry <growth@mail.iptransaction.com> 
Date: 07/02/2024 16:39 (GMT+00:00) 
To: MJC UK Enquiries <enquiries@mhhjapanesecars.co.uk> 
Subject: Connect With Top Brands & Expand Your Healthcare Business 

 
Dear MHH GROUP LIMITED,
 
Top healthcare brands like Hotgen, FlowFlex, yuwell, and EUROPAPA are issuing trademark licenses on iptransaction.com - The World's Premier Trademark Marketplace. You may spend as low as $250 (per quarter) licensing fee to leverage the power of these eye-catching brands.
 
We understand you've been running a promising healthcare business with your own trademark Racib and more assets. Now you've got an opportunity to capture consumer attention, slash marketing cost, and grow your own brand by obtaining trademark licenses from some top healthcare players - all within a budget that works for you.
 Click the button below to start your trademark journey and business growth. It's best for you to visit our website from a laptop or desktop PC.
Connect With Top Brands Now 
Happy Growing,
Henry Z
Marketing Manager
iptransaction.com, The World's Premier Trademark Marketplace
 
P.S. To ensure you keep receiving our updates, please add growth@mail.iptransaction.com to your contact list.


iptransaction.com

216 Lagrange Street, 02467, Chestnut Hill

This email was sent to enquiries@mhhjapanesecars.co.uk
View in browser| Unsubscribe
"""
            ),
            dict(
                title="REMOVE THIS EMAIL ADDRESS OFF YOUR DATABASE",
                body="""Please remove this email address from your database 
As per GDPR regulations we did not sign up to be contacted 

From: Henry <growth@mail.iptransaction.com> 
Sent: Wednesday, March 6, 2024 4:27 PM
To: Support <support@keep-in-touch.uk>
Subject: Grow Your Business By Connecting With Top Healthcare Brands

 
Dear Prep Kit LTD,
 
Top healthcare brands like Hotgen, FlowFlex, yuwell, and EUROPAPA are issuing trademark licenses on iptransaction.com - The World's Premier Trademark Marketplace. You may spend as low as $250 (per quarter) licensing fee to leverage the power of these eye-catching brands.
 
We understand you've been running a promising healthcare business with your own trademark Prep Kit and more assets. Now you've got an opportunity to capture consumer attention, slash marketing cost, and grow your own brand by obtaining trademark licenses from some top healthcare players - all within a budget that works for you.
 Click the button below to start your trademark journey and business growth. It's best for you to visit our website from a laptop or desktop PC.
Connect With Top Brands Now 
Happy Growing,
Henry Z
Marketing Manager
iptransaction.com, The World's Premier Trademark Marketplace
 
P.S. To ensure you keep receiving our updates, please add growth@mail.iptransaction.com to your contact list.




iptransaction.com

216 Lagrange Street, 02467, Chestnut Hill

This email was sent to support@keep-in-touch.uk
View in browser| Unsubscribe"""
            )
        ]
    ),

    dict(
        class_name="Receipt",
        description="The recipient considers our email as some kind of request and simply confirms the receipt of such a request, "
                    "with or without informing an ID/Number for the request.",
        examples=[
            dict(
                title="Thanks for your email to Liforme",
                body="""Hi there,

Thank you so much for your email! Our dedicated team will respond as quickly as we can; we normally aim to respond to every email within 1-2 working days :)

Kindly note that we are experiencing higher than normal volumes of inquiries at the moment, so it will take us a bit longer to get back to you, thanks for your patience with this. Please do not re-send your email, as this may delay us getting back to you.

Just to let you know, our business hours are Monday-Friday 09:00 – 18:00 GMT (UK time). 

In the meantime, we do have a helpful FAQ page on our website which can be used to find answers to common queries.
 
All the best,
the Liforme Team
""",
            ),
            dict(
                title="Re: Connect With Top Brands & Expand Your Healthcare Business { 01917402 }",
                body="""Phone: 1-800-363-5900
Fax: 1-514-355-7119
E-Mail: info@coleparmer.ca
Web: www.coleparmer.ca  

Thank you for contacting us. Your request has been received and is being reviewed by our support staff.  Your case number is:  01917402

Nous vous remercions de votre demande. Votre demande a été reçue et est en cours d'examen par notre personnel de soutien.  Votre numéro de dossier est: 01917402.


 
________________________________________
For your protection, our company does not accept credit card information via fax or email.
WORLDWIDE CONFIDENTIALITY NOTE: Dissemination, distribution or copying of this e-mail or the information herein by anyone other than the intended recipient, or any employee or agent of a system responsible for delivering the message to the intended recipient, is prohibited. If you are not the intended recipient, please inform the sender and delete all copies.""",
            ),
            dict(
                title="Automatic reply: Grow Your Online Retail Business By Connecting With Top Brands",
                body="""Hello, 

I am out of the office with limited access to emails. 

I will respond as soon as I'm able. 

Thank you."""
            )
        ]
    ),

    dict(
        class_name="Unsolicited",
        description="Feedback request, follow-up, event invitation, campaign/ad, "
                    "information sharing, and anything unsolicited.",
        examples=[
            dict(
                title="Let us know how we did",
                body="""Dear Growth

Thank you for taking the time to contact Lavazza. We hope we have been able to address your enquiry 189310. 

So we can continue to review and improve our service, if you could take the time to complete the below survey question and provide any feedback regarding your experience it would be greatly appreciated. 

________________________________________
How would you rate your recent interaction with Lavazza?
		
Extremely satisfied 
Neither satisfied nor dissatisfied 
Dissatisfied 
Sincerely,
Lavazza Customer Service team  

189310:1463189 

The information contained in this message is intended only for the personal and confidential use of the recipient(s) named above. Independently of the contents of this message, if you’re not the intended recipient, you are hereby notified that you have received this document in error and that any review, dissemination, distribution, or copying of this message is strictly prohibited. If you have received this message in error, please notify the sender immediately by e-mail, and delete the original message.
""",
            ),
            dict(
                title="A Day in the Life of the Hedoine Founders",
                body="""Want to Peek Behind The Scenes?

Winter can be tough, but laughter makes it easier! We wanted to share a few behind-the-scenes laughs with you to brighten up these cold days. Thanks for being part of our journey!

Follow us for more 

SHOP 	SUSTAINABILITY 	OFFERS 	SUBSCRIPTION 

 The Biodegradable | 50 Denier

Shop now 

	 The Bold | 20 Denier

Shop now 


 The Biodegradable | 30 Denier

Shop now 

	 The Bump | Seamless Maternity Tights 60

Shop now 


Hedoine Limited, 28 Old Brompton Road, 223, SW7 3SS London, United Kingdom
Manage Preferences | Unsubscribe""",
            )
        ]
    ),
    dict(
        class_name="Business",
        description="Anything with at least a minimum relation to the Business Topic behind the current Mailing List/Campaign.",
        examples=[
            dict(
                title="RE: Connect With Top Brands & Expand Your Healthcare Business",
                body="""Harry Z has some interesting stuff

David LaflinSales Manager | MedicsPro

0208 506 6744	 	0749 442 0113

David.Laflin@medicspro.com	 	111   115 North Street, Romford, RM1 1ES


From: Henry <growth@mail.iptransaction.com> 
Sent: Wednesday, February 7, 2024 3:02 PM
To: Business Development <business.development@medicspro.com>
Subject: Connect With Top Brands & Expand Your Healthcare Business

CAUTION: This email originated from outside of the organisation. Do not click links or open attachments unless you recognise the sender and know for definite the content is safe.
 
 
Dear Dan Medical Ltd,
 
Top healthcare brands like Hotgen, FlowFlex, yuwell, and EUROPAPA are issuing trademark licenses on iptransaction.com - The World's Premier Trademark Marketplace. You may spend as low as $250 (per quarter) licensing fee to leverage the power of these eye-catching brands.
 
We understand you've been running a promising healthcare business with your own trademark Dan Medical and more assets. Now you've got an opportunity to capture consumer attention, slash marketing cost, and grow your own brand by obtaining trademark licenses from some top healthcare players - all within a budget that works for you.
 Click the button below to start your trademark journey and business growth. It's best for you to visit our website from a laptop or desktop PC.
Connect With Top Brands Now 
Happy Growing,
Henry Z
Marketing Manager
iptransaction.com, The World's Premier Trademark Marketplace
 
P.S. To ensure you keep receiving our updates, please add growth@mail.iptransaction.com to your contact list.




iptransaction.com

216 Lagrange Street, 02467, Chestnut Hill

This email was sent to business.development@medicspro.com
View in browser| Unsubscribe""",
            ),
            dict(
                title="potentially interested in   iptransaction.com",
                body="""Dear 
Henry Z,

Alpafarma is a brand owned by Yellow People Lab Srl.

We are potentially interested in   iptransaction.com  as a business growth opportunity.
Our registration has been placed into your website with the email  s.schiavi@yellowpeoplelab.com  and we are now waiting for the invitation code.

Thanks for your attention.
Best regards

YPL


Da: Henry <growth@mail.iptransaction.com>
Data: 15 marzo 2024 alle ore 16:24:53 CET
A: amministrazione@alpafarma.it
Rispondi a: growth@mail.iptransaction.com
  
Dear YELLOW PEOPLE LAB SRL,
 
Trending healthcare brands like Hotgen, FlowFlex, yuwell, and EUROPAPA are issuing trademark licenses on iptransaction.com - The World's Premier Trademark Marketplace. Our platform offers versatile licensing, seamless online negotiation, and automated agreement updates, complemented by Stripe's secure payment and instant legal document delivery, enabling a complete and streamlined online trademark transaction experience.
 
We understand you've been running a promising healthcare business with your own trademark DIMANN and more assets. Now you've got an opportunity to maximize the visibility and credibility of your products by obtaining trademark licenses from some top healthcare players. Through dual-brand distribution, you may even grow your own brand with dramatically reduced marketing costs.
 Click the button below to start your trademark journey and business growth. It's best for you to visit our website from a laptop or desktop PC.
Connect With Top Brands Now 
Happy Growing,
Henry Z
Marketing Manager
iptransaction.com, The World's Premier Trademark Marketplace
 
P.S. To ensure you keep receiving our updates, please add growth@mail.iptransaction.com to your contact list.


iptransaction.com
216 Lagrange Street, 02467, Chestnut Hill

This email was sent to amministrazione@alpafarma.it
View in browser| Unsubscribe
 
Privo di virus.www.avast.com
""",
            )
        ]
    )

]
