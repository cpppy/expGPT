from llama_index.core import PromptTemplate
from llama_index.core.query_pipeline import QueryPipeline, RouterComponent

from llama_index.core.bridge.pydantic import Field, BaseModel

from loguru import logger
import json


class ResponseClassify(BaseModel):
    """Evaluation of whether the response has an error."""

    be_certain: bool = Field(
        ..., description="Are you sure about this answer ?"
    )
    # new_question: str = Field(..., description="The suggested new question.")
    category: str = Field(
        ..., description="the category name of the mail provide by user, it should be one of the list: [Bounce, Unsubscribe, Receipt, Unsolicited, Business]."
    )
    explanation: str = Field(
        ...,
        description=(
            "Give a reason why you choose this category."
        ),
    )


def main():

    from cls_ag import load_data
    mails = load_data.main(mail_tag='to_reply')
    logger.info(f'n_mails: {len(mails)}')

    from agents.demo_custom_agent_v2 import load_model
    llm = load_model(with_embedding=False)

    ### add output parser
    TEMPLATE = """
        Here's a JSON schema to follow:
        {schema}

        Output a valid JSON object but do not repeat the schema.
        """

    from router.parser import CustomPydanticOutputParser
    output_parser = CustomPydanticOutputParser(output_cls=ResponseClassify,
                                               pydantic_format_tmpl=TEMPLATE)

    # json_prompt_str = """
    #         analyse the response from llm, give suggestion of the next step about this topic.
    #         \n Response: {response_str}.
    #         \n Output with the following JSON format:
    #         """
    template = """
        You are an excellent email classification robot.
        Answer the following questions as best you can, but speaking as a pirate might speak.
        Now, i will provide the title and content of an email, you need to find the best match category from the categories below:
        [\n
        $categories
        ]
        \n
        the email message provided by user is:
        Email Title: {title}
        Email Body: {body}
        
        \n Output with the following JSON format:

        """
    from cls_ag.cls_config import CLASS_DETAILS
    category_names = [x['class_name'] for x in CLASS_DETAILS]
    logger.info(f'category_names: {category_names}')

    category_infos = [
        f"{i+1}. category_name: {x['class_name']}, \n description: {x['description']}"
        for i, x in enumerate(CLASS_DETAILS)
    ]
    category_infos = '\n\n'.join(category_infos)
    logger.info(f'category_infos: {category_infos}')

    template = template.replace('$categories', category_infos).replace('$category_names', ', '.join(category_names))

    json_prompt_str = output_parser.format(template)
    json_prompt_tmpl = PromptTemplate(json_prompt_str)
    qp_cls = QueryPipeline(chain=[json_prompt_tmpl, llm, output_parser])

    mails = mails[0:1]

    for mail in mails:
        try:
            # clean robot
            from cls_ag import clean_robot
            qp_clean = clean_robot.main()
            new_body = qp_clean.run(title=mail['subject'], body=mail['body']).text
            mail['body'] = new_body

            response = qp_cls.run(title=mail['subject'], body=mail['body'])
            logger.debug(f'response: {response}')
            # print(response.category)
            # print(response.explanation)
            # print(response.schema_json())
            print(f"Title: {mail['subject']}")
            print(f"Body: {mail['body']}")

        except Exception as e:
            logger.error(e)
            logger.error(f"title: {mail['subject']}")
            logger.error(f"body: {mail['body']}")
            logger.error('-' * 20)

if __name__ == '__main__':
    import sys

    logger.remove()
    logger.add(sys.stderr, level="DEBUG")
    main()






