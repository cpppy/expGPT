
from loguru import logger

from cls_ag.sqlite_util import SQLiteComponent


def main(mail_tag=None):
    assert mail_tag in ['unsubscribe', 'case_id', 'to_reply']

    table_name = 'inbox_v1'
    db_name = "/data/SenseMail/interface_v2/pegasus_mails.db"

    comp = SQLiteComponent(db_name=db_name, table_name=table_name)
    names = comp.collect_column_names()
    print(f'col_names: {names}')
    result = comp.search()
    # print(f'search_result: {result}')
    print(f'n_mails: {len(result)}')

    # key2arr = {k: [x[idx] for x in result] for idx, k in enumerate(names)}
    # key_inlist = ['sender', 'recipient', 'body_mails']
    # for k in key2arr.keys():
    #     if k in key_inlist:
    #         key2arr[k] = list(map(lambda x: json.loads(x), key2arr[k]))
    emails = [{k: v for k, v in zip(names, x)} for x in result]

    unique_clsnames = set([x['cls_name'] for x in emails])
    print(unique_clsnames)

    if mail_tag is not None:
        selected_emails = [x for x in emails if x['cls_name'] == mail_tag]
    else:
        selected_emails = emails

    # results = []
    # for email in selected_emails:
    #     title = email['subject']
    #     body = email['body']
    #     logger.debug(f'title: {title}')
    #     logger.debug(f'body: {repr(body)}')
    #     cls_name = email['cls_name']
    #     text = dict(title=title, body=body)
    #     logger.debug(f'mail_text: {text}')

        # resp = classifier.run(text=text)
        # logger.info(f'resp: {resp}')
        # results.append(
        #     dict(title=title,
        #          body=body,
        #          manual_label=cls_name,
        #          AI_label=resp)
        # )

    # import json
    # from classifiy.convert_log_to_excel import MyEncoder
    # with open('./mail_classification_type-ToReply_model-Mistral7B.json', 'w') as f:
    #     json.dump(results, f, indent=4, cls= MyEncoder)
    return  selected_emails


if __name__ == '__main__':
    import sys

    logger.remove()
    logger.add(sys.stderr, level="DEBUG")

    mails = main('case_id')[130:141]
    for mail in mails:
        print(f'Title: {mail["subject"]}')
        print(f'Body: {mail["body"]}')
