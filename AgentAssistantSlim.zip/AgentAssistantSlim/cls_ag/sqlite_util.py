import sqlite3
import json


class SQLiteComponent:

    def __init__(self, db_name, table_name=None):
        self.conn = sqlite3.connect(db_name)
        self.table_name = table_name

    def init_database(self, table_name=None, column2type=None, insert_rows=None):
        if table_name is None:
            table_name = self.table_name
        assert table_name is not None

        s = self.conn.cursor()
        # s.execute('CREATE TABLE IF NOT EXISTS pet_owners (person TEXT, pet TEXT, mail TEXT);')

        # create table
        s.execute(
            f'CREATE TABLE IF NOT EXISTS {table_name} ({", ".join([k + " " + v for k, v in column2type.items()])});')
        s.execute(f'DELETE FROM {table_name}')

        # datatype: https://www.sqlite.org/datatype3.html
        # https://stackoverflow.com/questions/3379166/writing-blob-from-sqlite-to-file-using-python

        if insert_rows is not None:
            print(insert_rows)
            # pet_owners = [('a', 'b', json.dumps(['a1', 'a2', 'a3']))]
            for i in range(len(insert_rows)):
                insert_command = f"INSERT INTO {table_name} ({', '.join(list(column2type.keys()))}) VALUES({', '.join(['?']*3)})"
                print(insert_command, insert_rows[i])
                s.execute(f"INSERT INTO {table_name} ({', '.join(list(column2type.keys()))}) VALUES({', '.join(['?']*len(insert_rows[i]))})", list(insert_rows[i]))

        self.conn.commit()
        s.close()

    def collect_column_names(self, table_name=None):
        if table_name is None:
            table_name = self.table_name
        assert table_name is not None

        cursor = self.conn.cursor()
        cursor.execute(f'select * from {table_name} LIMIT 1;').fetchall()
        # names = list(map(lambda x: x[0], cursor.description))
        names = [description[0] for description in cursor.description]
        cursor.close()
        return names

    def search(self, table_name=None):
        if table_name is None:
            table_name = self.table_name
        assert table_name is not None

        cursor = self.conn.cursor()
        results = cursor.execute(f'select * from {table_name} LIMIT 1000;').fetchall()
        cursor.close()
        return results

    def update(self, command):
        cursor = self.conn.cursor()
        cursor.execute(command)
        self.conn.commit()
        cursor.close()


if __name__ == '__main__':
    table_name = 'pet_owners'
    comp = SQLiteComponent(db_name="pets2.db", table_name='pet_owners')
    comp.init_database(column2type=dict(person='TEXT', pet='TEXT', mail='TEXT'),
                       insert_rows=[('a', 'b', json.dumps(['a1', 'a2', 'a3'])), ('a', 'd', json.dumps(['a2', 'a3', 'a4']))])
    names = comp.collect_column_names()
    print(f'col_names: {names}')
    result = comp.search()
    print(f'search_result: {result}')
