import aiohttp
import asyncio
import time


# def do_requests(session):
#     print(f'start !!!')
#     # await asyncio.sleep(2)
#     return session.get('https://www.baidu.com')
#
#
# async def main():
#     async with aiohttp.ClientSession() as session:
#         tasks = []
#         for _ in range(0, 10):
#             tasks.append(do_requests(session))
#
#         results = await asyncio.gather(*tasks)
#         for idx, r in enumerate(results):
#             print(f'{idx} example.com =>', r.status)


if __name__ == '__main__':

    # asyncio.run(main())
    # main()

    import asyncio

    def hard_work():
        time.sleep(10)

    async def main():
        print('start')
        await asyncio.sleep(1)
        # hard_work()
        await asyncio.to_thread(hard_work)
        print('hello')

    async def main2():
        print('start2')
        await asyncio.sleep(2)
        print('hello2')

    # # asyncio.run(main())
    # loop = asyncio.get_event_loop()
    # task = loop.create_task(main())
    # task2 = loop.create_task(main2())
    # loop.run_until_complete(task)
    # loop.run_until_complete(task2)

    async def main3():
        await asyncio.gather(main(), main2())

    asyncio.run(main3())



