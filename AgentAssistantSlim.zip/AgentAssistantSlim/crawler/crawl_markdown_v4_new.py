import time
from selenium import webdriver
# from selenium.webdriver.chrome.options import Options
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.common.by import By
import pandas as pd


options = Options()
options.headless = True

# driver = webdriver.Edge(options=options)  #这里可以换成chrome
# driver = webdriver.Firefox(options=options)

options.add_argument("--width=1280")
options.add_argument("--height=720")

# options.binary_location = '/usr/bin/firefox'


from selenium.webdriver.firefox.service import Service
# driverService = Service('chromedriver/geckodriver') ## path where you saved geckodriver
from selenium.webdriver.firefox.firefox_binary import FirefoxBinary
binary = FirefoxBinary('/usr/bin/firefox')
options.binary = binary
driver = webdriver.Firefox(
    # service=driverService,
    # firefox_binary=binary,

    options=options
)


# 目标网页
url = "https://cpubmed.openi.org.cn/graph/wiki"
driver.get(url)
time.sleep(5)


data = []
max_sources = 0  # 记录最大来源的数量,生成Excel列,因为不确定有多少的文献


def handle_links_in_frame(first_level_text, second_level_text, third_level_text, initial_url):
    try:
        # 切换到 iframe(前端代码)
        iframe = driver.find_element(By.ID, 'wikiiframe')
        driver.switch_to.frame(iframe)

        # 查找所有带有 onclick 属性的链接
        links = driver.find_elements(By.CSS_SELECTOR, 'a[onclick*="/index.php/"]')
        print(f"Found {len(links)} links")

        for link_index in range(len(links)):
            links = driver.find_elements(By.CSS_SELECTOR, 'a[onclick*="/index.php/"]')
            link = links[link_index]  # 获取当前链接
            link_text = link.text
            print(f"Processing link {link_index + 1}/{len(links)}: {link_text}")

            try:
                driver.execute_script("arguments[0].click();", link)
                time.sleep(1)  # 等一下加载

                # 获取 h1 标题并分割为主实体、关系、尾实体
                try:
                    title_element = driver.find_element(By.ID, 'firstHeading')
                    main_entity, relation, tail_entity = title_element.text.split('-')

                    source_elements = driver.find_elements(By.CSS_SELECTOR, 'h3 .mw-headline')
                    sources = [source.text for source in source_elements]

                    global max_sources
                    max_sources = max(max_sources, len(sources))

                    # 存储每一行的结果
                    row_data = [first_level_text, second_level_text, third_level_text, main_entity,
                                relation, tail_entity] + sources

                    print(f"当前所记录的内容为:{row_data}")
                    data.append(row_data)

                except Exception as e:
                    print(f"Error processing link {link_text}: {str(e)}")

                # 手动恢复到点击前的页面状态，重新加载 iframe
                driver.switch_to.default_content()  # 回到主文档
                driver.execute_script(f"document.getElementById('wikiiframe').src = '{initial_url}';")
                time.sleep(2)  # 等待 iframe 恢复

                # 切换回 iframe
                iframe = driver.find_element(By.ID, 'wikiiframe')
                driver.switch_to.frame(iframe)  # 切换到 iframe

            except Exception as e:
                print(f"Error clicking on link {link_text}: {str(e)}")

        driver.switch_to.default_content()

    except Exception as e:
        print(f"Error switching to iframe: {str(e)}")


# 点击展开符号 "+"
def click_expand_icon(item):
    try:
        expand_icon = item.find_element(By.CSS_SELECTOR, 'span.expand-icon')
        if 'glyphicon-plus' in expand_icon.get_attribute('class'):
            driver.execute_script("arguments[0].click();", expand_icon)
            time.sleep(1)
    except Exception as e:
        print(f"Error clicking expand icon: {e}")

def traverse_levels(first_level_text, level=2, second_level_text=None, start_nodeid=0):
    items = driver.find_elements(By.CSS_SELECTOR, 'li.list-group-item.node-treeview4')
    item_count = len(items)

    for i in range(start_nodeid, item_count):
        items = driver.find_elements(By.CSS_SELECTOR, 'li.list-group-item.node-treeview4')
        item = items[i]
        indent_count = item.find_elements(By.CSS_SELECTOR, '.indent')

        # 获取当前 nodeid
        nodeid = int(item.get_attribute("data-nodeid"))

        if len(indent_count) == level - 1:
            current_text = item.text.split()[0]
            print(f"{'  ' * level}Traversing level {level}: {current_text} (nodeid: {nodeid})")

            if level == 2:
                # 点击展开符号 "+"，如果有的话
                try:
                    expand_icon = item.find_element(By.CSS_SELECTOR, 'span.expand-icon')
                    if 'glyphicon-plus' in expand_icon.get_attribute('class'):
                        driver.execute_script("arguments[0].click();", expand_icon)
                        time.sleep(1)
                except:
                    pass

                traverse_levels(first_level_text, level + 1, second_level_text=current_text, start_nodeid=nodeid + 1)

            if level == 3:
                try:
                    item.click()
                    time.sleep(1)

                    # 获取 iframe 的当前 URL，保存下来用于恢复
                    iframe = driver.find_element(By.ID, 'wikiiframe')
                    initial_url = iframe.get_attribute('src')  # 保存 iframe 的初始 URL

                    # 处理第三层的链接，将 second_level_text 作为第二层，current_text 作为第三层
                    handle_links_in_frame(first_level_text, second_level_text, third_level_text=current_text, initial_url=initial_url)

                    # 切换回 treeview 继续处理下一个症状
                    treeview = driver.find_element(By.ID, "wikitree")  # 找到 treeview 容器
                    driver.execute_script("arguments[0].scrollIntoView(true);", treeview)
                    time.sleep(1)

                except Exception as e:
                    print(f"Error clicking third level item: {str(e)}")


# 外层：遍历第一层和第二层
def traverse_first_level():
    first_level_items = driver.find_elements(By.CSS_SELECTOR, 'li.list-group-item.node-treeview4')

    for item in first_level_items:
        indent_count = item.find_elements(By.CSS_SELECTOR, '.indent')

        if len(indent_count) == 0:
            first_level_text = item.text.split()[0]
            print(f"Traversing first level: {first_level_text}")

            # 点击展开符号 "+"
            click_expand_icon(item)

            traverse_levels(first_level_text, level=2, second_level_text=None, start_nodeid=0)



# 开始!
traverse_first_level()

# 字段名称
columns = ['第一层', '第二层', '第三层', '主实体', '关系', '尾实体'] + [f'来源{i + 1}' for i in range(max_sources)]

df = pd.DataFrame(data, columns=columns)

df.to_excel('result.xlsx', index=False)

# 关闭浏览器
driver.quit()
