

if __name__=='__main__':

    import time
    from crawl4ai.web_crawler import WebCrawler

    crawler = WebCrawler()
    crawler.warmup()

    start = time.time()
    url = r"https://www.bing.com/news"
    result = crawler.run(url, word_count_threshold=10, bypass_cache=True)
    print(result.markdown)
    print(f'=========================== LINKS ==========================')
    print(result.links)
    end = time.time()
    print(f"Time taken: {end - start}")





