import json


def convert():
    # json_path = '/data/AgentAssistant/eval_generate_v2/samples_generated_by_doubao32k_20241101.jsonl'
    json_path = '/data/AgentAssistant/eval_generate_v2/samples_generated_by_doubao32k_20241108_demo.jsonl'
    samples = []
    with open(json_path, 'r') as f:
        lines = f.readlines()
        for line in lines:
            data = json.loads(line)
            print(data)
            samples.append(data)

    with open(f'samples_generated_by_doubao32k_20241104_partial.json', 'w') as f:
        json.dump(samples, f, ensure_ascii=False)


if __name__=='__main__':

    with open(f'/data/AgentAssistant/eval_generate_v2/transformed_samples.jsonl', 'r') as f:
        data = json.load(f)
        print(json.dumps(data, indent=4, ensure_ascii=False))

    with open(f'sample_checked_1.json', 'w') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)
