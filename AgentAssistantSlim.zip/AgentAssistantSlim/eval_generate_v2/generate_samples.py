import pandas as pd
import json

from openai import OpenAI

import time



def load_context():

    data_path = '/data/data/medical_data/医院项目明细表1-上传dify.xlsx'
    df = pd.read_excel(data_path, engine='openpyxl', sheet_name=0)
    print(df.head(100))
    print(df.shape)

    df_data = df.to_dict(orient='records')
    # print(json.dumps(df_data[0], ensure_ascii=False))

    # group2items = {}
    # for x in df_data:
    #     if x['项目名称'] in x:
    #         group2items[x['项目名称']].append()
    context_str = '\n'.join([
        json.dumps(x, ensure_ascii=False)
        for x in df_data
    ])
    # print(context_str)
    return context_str


def main():

    client = OpenAI(
        # api_key=os.environ.get("ARK_API_KEY"),
        api_key='cc39f7e2-359e-4acb-b2d5-09f219394316',
        base_url="https://ark.cn-beijing.volces.com/api/v3",
    )

    context_str = load_context()
    # print(len(context_str))
    #
    # exit(0)

    from eval_generate_v2.generate_prompt_v1 import SYSTEM_PROMPT_V1, GENERATE_PROMPT_V1
    prompt = GENERATE_PROMPT_V1.format(context=context_str)
    # print(prompt)
#     exit(0)
#
#     prompt = """
# 生成100个人的信息，每个人的信息包含：性别、年龄、饮食习惯、生活习惯、气候条件等。
# 要求每人的信息都不一样，请按json格式输出
# """
    prompt = """
{"项目名称": "肿瘤标志物", "明细编码": 60449, "明细名称": "AFP（甲胎蛋白）"}
{"项目名称": "肿瘤标志物", "明细编码": 60450, "明细名称": "CEA（癌胚抗原）"}
{"项目名称": "肿瘤标志物", "明细编码": 60503, "明细名称": "TPSA（总前列腺特异性抗原）"}
{"项目名称": "肿瘤标志物", "明细编码": 130102, "明细名称": "人类免疫缺陷病毒抗体(Anti-HIV)"}
{"项目名称": "肿瘤标志物", "明细编码": 60353, "明细名称": "RPR"}
{"项目名称": "肿瘤标志物", "明细编码": 60322, "明细名称": "抗'O'"}
{"项目名称": "肿瘤标志物", "明细编码": 130104, "明细名称": "直接法类风湿因子(RF)"}
{"项目名称": "肿瘤标志物", "明细编码": 60296, "明细名称": "降钙素"}
{"项目名称": "肿瘤标志物", "明细编码": 60389, "明细名称": "CYFRA21－1"}
{"项目名称": "肿瘤标志物", "明细编码": 130020, "明细名称": "CA125"}
{"项目名称": "肿瘤标志物", "明细编码": 60380, "明细名称": "鳞状细胞癌相关抗原（Scc-Ag）"}
{"项目名称": "肿瘤标志物", "明细编码": 130022, "明细名称": "CA19-9"}
{"项目名称": "肿瘤标志物", "明细编码": 60507, "明细名称": "CA50"}
{"项目名称": "肿瘤标志物", "明细编码": 130021, "明细名称": "CA15-3"}
{"项目名称": "肿瘤标志物", "明细编码": 60508, "明细名称": "CA242"}
{"项目名称": "肿瘤标志物", "明细编码": 190209, "明细名称": "糖链抗原125(CA125)"}
{"项目名称": "肿瘤标志物", "明细编码": 60551, "明细名称": "异常凝血酶原（PIVKA-Ⅱ）"}
{"项目名称": "肿瘤标志物", "明细编码": 60513, "明细名称": "胸苷激酶1（TK1）"}
{"项目名称": "肿瘤标志物", "明细编码": 60452, "明细名称": "FPSA（游离前列腺特异性抗原）"}
{"项目名称": "肿瘤标志物", "明细编码": 60571, "明细名称": "HE4人附睾蛋白4测定（体检）"}
{"项目名称": "肿瘤标志物", "明细编码": 60572, "明细名称": "血清胃泌素释放肽前体ProGRP（体）"}


请将上述内容转化为markdown表格形式
"""

    t0 = time.time()
    # Non-streaming:
    print("----- standard request -----")
    completion = client.chat.completions.create(
        model="ep-20241031134418-mgbsw",  # your model endpoint ID
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT_V1},
            {"role": "user", "content": prompt},
        ],
        max_tokens=4096,
    )
    t1 = time.time()

    print(completion.choices[0].message.content)
    print(f'time_cost: {round(t1-t0, 3)} s')




if __name__=='__main__':

    main()




