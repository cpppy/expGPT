import pandas as pd
import json

from openai import OpenAI

import time


def load_context():

    data_path = '/data/data/medical_data/医院项目明细表1-上传dify.xlsx'
    df = pd.read_excel(data_path, engine='openpyxl', sheet_name=0)
    print(df.head(100))
    print(df.shape)

    df_data = df.to_dict(orient='records')
    # print(json.dumps(df_data[0], ensure_ascii=False))

    # group2items = {}
    # for x in df_data:
    #     if x['项目名称'] in x:
    #         group2items[x['项目名称']].append()
    context_str = '\n'.join([
        json.dumps(x, ensure_ascii=False)
        for x in df_data
    ])
    # print(context_str)
    return context_str


def main():

    client = OpenAI(
        # api_key=os.environ.get("ARK_API_KEY"),
        api_key='cc39f7e2-359e-4acb-b2d5-09f219394316',
        base_url="https://ark.cn-beijing.volces.com/api/v3",
    )

    context_str = load_context()
    # print(len(context_str))
    #
    # exit(0)

    from eval_generate_v2.generate_prompt_v1 import SYSTEM_PROMPT_V1, GENERATE_PROMPT_V1
    prompt = GENERATE_PROMPT_V1.format(context=context_str)
    # print(prompt)
    # exit(0)

    t0 = time.time()
    # Non-streaming:
    print("----- standard request -----")
    completion = client.chat.completions.create(
        model="ep-20241031134418-mgbsw",  # your model endpoint ID
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT_V1},
            {"role": "user", "content": prompt},
        ],
    )
    t1 = time.time()

    print(completion.choices[0].message.content)
    print(f'time_cost: {round(t1-t0, 3)} s')






if __name__=='__main__':

    main()




