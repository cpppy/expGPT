import os
from openai import OpenAI


def main():
    client = OpenAI(
        # api_key=os.environ.get("ARK_API_KEY"),
        api_key='cc39f7e2-359e-4acb-b2d5-09f219394316',
        base_url="https://ark.cn-beijing.volces.com/api/v3",
    )

    # # Non-streaming:
    # print("----- standard request -----")
    # completion = client.chat.completions.create(
    #     model="ep-20241031134418-mgbsw",  # your model endpoint ID
    #     messages=[
    #         {"role": "system", "content": "你是豆包，是由字节跳动开发的 AI 人工智能助手"},
    #         {"role": "user", "content": "常见的十字花科植物有哪些？"},
    #     ],
    # )
    # print(completion.choices[0].message.content)

    # Streaming:
    print("----- streaming request -----")
    stream = client.chat.completions.create(
        model="ep-20241031134418-mgbsw",  # your model endpoint ID
        messages=[
            {"role": "system", "content": "你是豆包，是由字节跳动开发的 AI 人工智能助手"},
            # {"role": "user", "content": "常见的十字花科植物有哪些？"},
            {"role": "user", "content": "今天上海的天气怎么样？"},
        ],
        stream=True
    )

    for chunk in stream:
        if not chunk.choices:
            continue
        print(chunk.choices[0].delta.content, end="")
    print()

if __name__=='__main__':

    main()

