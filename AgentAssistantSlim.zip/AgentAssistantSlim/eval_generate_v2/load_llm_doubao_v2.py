from volcenginesdkarkruntime import Ark

from volcengine.iam.IamService import IamService

def main():

    # iam_service = IamService()
    # iam_service.set_ak('AKLTMjc2ZWI2NDlkYWUxNGViODhlZWEwZTgyMjlhODJjZTg')
    # iam_service.set_sk('T1Rjek5USTNZVGd4TkRrMU5HTTNOR0kxWm1GaU1qUmxZMkZpT1RNME5XUQ==')

    client = Ark(
        base_url="https://ark.cn-beijing.volces.com/api/v3",

        # ak='AKLTMjc2ZWI2NDlkYWUxNGViODhlZWEwZTgyMjlhODJjZTg',
        # sk='T1Rjek5USTNZVGd4TkRrMU5HTTNOR0kxWm1GaU1qUmxZMkZpT1RNME5XUQ==',

        api_key='cc39f7e2-359e-4acb-b2d5-09f219394316',
        # api_key='T1Rjek5USTNZVGd4TkRrMU5HTTNOR0kxWm1GaU1qUmxZMkZpT1RNME5XUQ==',
    )

    # # Non-streaming:
    # print("----- standard request -----")
    # completion = client.chat.completions.create(
    #     model="ep-20241031134418-mgbsw",
    #     messages=[
    #         {"role": "system", "content": "你是豆包，是由字节跳动开发的 AI 人工智能助手"},
    #         {"role": "user", "content": "常见的十字花科植物有哪些？"},
    #     ],
    # )
    # print(completion.choices[0].message.content)

    # Streaming:
    print("----- streaming request -----")
    stream = client.chat.completions.create(
        model="ep-20241031134418-mgbsw",
        messages=[
            {"role": "system", "content": "你是豆包，是由字节跳动开发的 AI 人工智能助手"},
            {"role": "user", "content": "常见的十字花科植物有哪些？"},
        ],
        stream=True
    )
    for chunk in stream:
        if not chunk.choices:
            continue
        print(chunk.choices[0].delta.content, end="")
    print()


def link2():
    import os
    from volcengine.maas.v2 import MaasService
    from volcengine.maas import MaasException, ChatRole

    def test_chat(maas, endpoint_id, req):
        try:
            resp = maas.chat(endpoint_id, req)
            print(resp)
        except MaasException as e:
            print(e)

    def test_stream_chat(maas, endpoint_id, req):
        try:
            resps = maas.stream_chat(endpoint_id, req)
            for resp in resps:
                print(resp)
        except MaasException as e:
            print(e)

    if __name__ == '__main__':
        # maas = MaasService('maas-api.ml-platform-cn-beijing.volces.com', 'cn-beijing')
        maas = MaasService("https://ark.cn-beijing.volces.com/api/v3", 'cn-beijing')

        ak='AKLTMjc2ZWI2NDlkYWUxNGViODhlZWEwZTgyMjlhODJjZTg'
        sk='T1Rjek5USTNZVGd4TkRrMU5HTTNOR0kxWm1GaU1qUmxZMkZpT1RNME5XUQ=='
        maas.set_ak(ak)
        maas.set_sk(sk)

        # document: "https://www.volcengine.com/docs/82379/1099475"
        # chat
        req = {
            "parameters": {
                "max_new_tokens": 2000,
                "temperature": 0.8
            },
            "messages": [
                {
                    "role": ChatRole.USER,
                    "content": "天为什么这么蓝"
                }, {
                    "role": ChatRole.ASSISTANT,
                    "content": "因为有你"
                }, {
                    "role": ChatRole.USER,
                    "content": "花儿为什么这么香？"
                },
            ]
        }

        endpoint_id = "https://ark.cn-beijing.volces.com/api/v3"
        test_chat(maas, endpoint_id, req)
        test_stream_chat(maas, endpoint_id, req)
    #


if __name__ == '__main__':
    main()
    # link2()

