import torch

from gradnorm_pytorch import (
    GradNormLossWeighter,
    MockNetworkWithMultipleLosses
)


def main():
    # a mock network with multiple discriminator losses

    network = MockNetworkWithMultipleLosses(
        dim = 512,
        num_losses = 4
    )

    # backbone shared parameter

    backbone_parameter = network.backbone[-1].weight

    # grad norm based loss weighter

    loss_weighter = GradNormLossWeighter(
        num_losses = 4,
        learning_rate = 1e-4,
        restoring_force_alpha = 0.,                  # 0. is perfectly balanced losses, while anything greater than 1 would account for the relative training rates of each loss. in the paper, they go as high as 3.
        grad_norm_parameters = backbone_parameter
    )

    # mock input

    mock_input = torch.randn(2, 512)
    losses, backbone_output_activations = network(mock_input)

    # backwards with the loss weights
    # will update on each backward based on gradnorm algorithm

    loss_weighter.backward(losses, retain_graph = True)

    # if you would like to update the loss weights wrt activations just do the following instead

    loss_weighter.backward(losses, backbone_output_activations)


if __name__=='__main__':

    main()

