import logging
import sys

'''
https://medium.aiplanet.com/implement-rag-with-knowledge-graph-and-llama-index-6a3370e93cdd

'''

from llama_index.core import (SimpleDirectoryReader,
    # LLMPredictor,
                              ServiceContext,
                              KnowledgeGraphIndex)

from llama_index.core.storage.storage_context import StorageContext
# from langchain.embeddings import HuggingFaceInferenceAPIEmbeddings
from pyvis.network import Network

from llama_index.core import SimpleDirectoryReader, KnowledgeGraphIndex
from llama_index.core.graph_stores import SimpleGraphStore

from llama_index.llms.openai import OpenAI
from llama_index.core import Settings
from IPython.display import Markdown, display


def main():
    ############# load model #############
    from llm_backend.mistral03 import load_model
    llm, emb_model = load_model.load_model()

    # load data
    documents = SimpleDirectoryReader("/data/data/shuiwen_p1_notice/").load_data()
    logging.info(f'n_doc: {len(documents)}')


    # # setup service context
    # service_context = ServiceContext.from_defaults(
    #     chunk_size=256,
    #     llm=llm,
    #     embed_model=emb_model,
    # )

    # setup storage context
    graph_store = SimpleGraphStore()
    storage_context = StorageContext.from_defaults(graph_store=graph_store)

    # construct kownledge graph index
    index = KnowledgeGraphIndex.from_documents(
        documents=documents,
        storage_context=storage_context,
        show_progress=True,
        include_embeddings=True,
        max_triplets_per_chunk=3,
    )

    storage_context.persist(
        persist_dir='./kg_db_shuiwen',
        # docstore_fname='ESOP_pdf'
    )

    # query
    query = 'What is ESOP ?'
    query_engine = index.as_query_engine(
        llm=llm,
        include_text=True,
        response_mode='tree_summarize',
        embedding_mode='hybrid',
        similarity_top_k=5,
    )

    # message_template = f"""<|system|>Please check if the following pieces of context has any mention of the  keywords provided in the Question.If not then don't know the answer, just say that you don't know.Stop there.Please donot try to make up an answer.</s>
    # <|user|>
    # Question: {query}
    # Helpful Answer:
    # </s>"""
    message = f"""Question: {query}"""
    response = query_engine.query(message)
    #
    print(response.response.split("<|assistant|>")[-1].strip())


if __name__ == '__main__':
    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
    # logging.getLogger().addHandler(logging.StreamHandler(stream=sys.stdout))

    main()
