import spacy

'''
https://prateekjoshi.medium.com/knowledge-graph-a-powerful-data-science-technique-to-mine-information-from-text-with-python-f8bfd217accc
https://zhuanlan.zhihu.com/p/243211697

'''

def main():

    nlp = spacy.load('en_core_web_sm')
    # import en_core_web_sm
    # nlp = en_core_web_sm.load()

    '''
    # ERROR: no module named en_core_web_sm
    pip install https://github.com/explosion/spacy-models/releases/download/en_core_web_sm-3.0.0/en_core_web_sm-3.0.0.tar.gz
    reference:
        https://github.com/explosion/spaCy/issues/4577
        https://github.com/explosion/spaCy/issues/7453
    '''


    doc = nlp("The 22-year-old recently won ATP Challenger tournament.")
    for tok in doc:
        print(tok.text, "...", tok.dep_)

    doc = nlp("Nagal won the first set.")
    for tok in doc:
        print(tok.text, "...", tok.dep_)


if __name__ == '__main__':
    main()
