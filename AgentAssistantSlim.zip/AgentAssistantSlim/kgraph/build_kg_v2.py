import os
import logging
import sys

from llama_index.core import StorageContext
from llama_index.core.storage.docstore import SimpleDocumentStore
from llama_index.core.vector_stores import SimpleVectorStore
from llama_index.core.storage.index_store import SimpleIndexStore



def main():

    '''
    load storage_context from persist dir
    https://docs.llamaindex.ai/en/stable/module_guides/storing/save_load/
    '''

    persist_dir = './kg_db'
    storage_context = StorageContext.from_defaults(
        docstore=SimpleDocumentStore.from_persist_dir(persist_dir=persist_dir),
        vector_store=SimpleVectorStore.from_persist_dir(
            persist_dir=persist_dir
        ),
        index_store=SimpleIndexStore.from_persist_dir(persist_dir=persist_dir),
    )


if __name__=='__main__':

    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
    main()



