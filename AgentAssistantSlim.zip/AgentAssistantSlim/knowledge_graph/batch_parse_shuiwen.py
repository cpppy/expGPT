import os
import glob

from rag_release_v1.metafilter.load_chunks import load_markdown_file, split_text

from loguru import logger
from tqdm import tqdm
import pickle
import pandas as pd

import networkx as nx

import matplotlib

matplotlib.use('TkAgg')
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = 'SimHei'

# from matplotlib import font_manager
#
# fontP = font_manager.FontProperties()
# fontP.set_family('SimHei')
# fontP.set_size(14)

# import matplotlib
# matplotlib.rcParams['font.family'] = ['SimHei']

'''
>>> import matplotlib
>>> print(matplotlib.matplotlib_fname())
/home/data/.local/lib/python3.10/site-packages/matplotlib/mpl-data/matplotlibrc
>>> print(matplotlib.get_cachedir())
/home/data/.cache/matplotlib
>>> 


'''


def main():
    from llm_backend.mistral03.load_model import load_model
    # from llm_backend.llama3.load_model import load_model
    llm, _ = load_model()

    from knowledge_graph.triplet_parse_v2 import TripletParser
    triplet_parser = TripletParser(llm=llm)

    data_dir = '/data/data/shuiwen_md'
    file_paths = glob.glob(f'{data_dir}/*.md')
    print(f'n_file: {len(file_paths)}')

    tags = list(set([os.path.basename(f).split('_')[0].split('.')[0] for f in file_paths]))
    print(tags)

    _file_paths = [f for f in file_paths if os.path.basename(f).startswith("孙口水文站2023年水雨情应急测报预案_output")]
    print(_file_paths)

    _file_paths = sorted(_file_paths, key=lambda x: int(x.split('_')[-1].split('.')[0]))
    print(_file_paths)

    parse_cache = './nodes_with_triplet_cache.pkl'
    from rag_release_v1.metafilter.custom_vectorstore_v3_pmt import CustomVectorStore
    vector_store = CustomVectorStore()
    meta_data = dict(
        year=2023,
        location="孙口水文站",
        document_type="水雨情应急测报预案",
    )
    if not os.path.exists(parse_cache):
        nodes = []
        for i in range(len(_file_paths)):
            _nodes = load_markdown_file(_file_paths[i])
            nodes.extend(_nodes)
        logger.debug(f'n_node: {len(nodes)}')

        from itertools import chain
        chunk_nodes = list(chain(*[(split_text(node)) for node in nodes]))

        for chunk_node in chunk_nodes:
            chunk_node.metadata = meta_data

        print(chunk_nodes[0:3])

        for node in tqdm(chunk_nodes):
            text = node.text
            triplets = triplet_parser.extract_triplets(text)
            node.metadata.update(dict(triplets=triplets))

        print(f'--------------- PRINT RESULT ----------------')
        for node in chunk_nodes[0:3]:
            print(node.metadata["triplets"])
        vector_store.add(chunk_nodes)
        vector_store.persist(persist_path=parse_cache)
    else:
        vector_store.restore(parse_cache)

    # load triplets
    nodes = vector_store.node_dict.values()
    print(f'n_nodes: {len(nodes)}')

    triplets = []
    for node in nodes:
        _triplets = node.metadata['triplets']
        triplets.extend(_triplets)
    print(f'n_triplets: {len(triplets)}')
    print(f'----------------------------------------')

    check_result_cache = './triplet_checked.pkl'
    if os.path.exists(check_result_cache):
        with open(check_result_cache, 'rb') as f:
            _data = pickle.load(f)
        valid_triplets = _data['valid_triplets']
        invalid_triplets = _data['invalid_triplets']
    else:
        valid_triplets = []
        invalid_triplets = []
        from knowledge_graph.check_triplet_content import CheckTripletContent
        check_tool = CheckTripletContent(llm=llm)
        for tr in tqdm(triplets, desc='CHECK TRIPLET CONTENT'):
            if tr['people'] == '未解析出':
                continue
            # check validity of content in triplet
            check_result = check_tool(tr)
            tr.update({'check_result': check_result.model_dump()})
            if check_result.is_valid:
                valid_triplets.append(tr)
            else:
                invalid_triplets.append(tr)
        with open(check_result_cache, 'wb') as f:
            pickle.dump(dict(valid_triplets=valid_triplets, invalid_triplets=invalid_triplets), f)

    print(f'n_valid_triplets: {len(valid_triplets)}')
    print(f'----------------------------------------')
    for tr in valid_triplets:
        print(tr)

    # ############### write to csv file ##############
    # df = pd.DataFrame(
    #     {
    #         'task': [t['task'] for t in valid_triplets],
    #         'staff': [t['people'] for t in valid_triplets],
    #         'work': [t['work'] for t in valid_triplets]
    #     }
    # )
    # df.to_csv('SunKou_valid_triplets.csv', index=False)

    ################# build knowledge graph #################
    re_pairs = []
    re_pairs.append(dict(
        source=meta_data['location'],
        relation='document',
        target=str(meta_data['year']) + meta_data['document_type']
    ))
    for tr in valid_triplets:
        task = tr['task']
        staff = tr['people']
        work = tr['work']

        # if staff != '高玄':
        #     continue

        re_pairs.extend([
            dict(source=str(meta_data['year']) + meta_data['document_type'], relation='task', target=task),
            dict(source=task, relation='work', target=work),
            dict(source=work, relation='staff', target=staff)
        ])
    # kg_df = pd.DataFrame(
    #     {
    #         'source': [r['source'] for r in re_pairs],
    #         'target': [r['target'] for r in re_pairs],
    #         'edge': [r['relation'] for r in re_pairs],
    #     }
    # )

    return {
        'source': [r['source'] for r in re_pairs],
        'target': [r['target'] for r in re_pairs],
        'edge': [r['relation'] for r in re_pairs],
    }

    G = nx.from_pandas_edgelist(kg_df, "source", "target",
                                edge_attr=True, create_using=nx.MultiDiGraph())

    # G = nx.from_pandas_edgelist(kg_df[kg_df['source'] == "madison"], "source", "target",
    #                             edge_attr=True, create_using=nx.MultiDiGraph())

    # G = nx.from_pandas_edgelist(kg_df[(kg_df['source'] == "script") | (kg_df['target'] == "script")], "source",
    #                             "target",
    #                             edge_attr=True, create_using=nx.MultiDiGraph())

    plt.figure(figsize=(12, 12))
    pos = nx.spring_layout(G, k=0.5)  # k regulates the distance between nodes
    nx.draw(G, with_labels=True, node_color='skyblue', node_size=1500, edge_cmap=plt.cm.Blues, pos=pos)
    plt.show()


if __name__ == '__main__':
    import sys

    logger.remove()
    logger.add(sys.stderr, level="DEBUG")

    main()
