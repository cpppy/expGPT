import os

os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'

from typing import List
from pydantic import BaseModel, Field
from llama_index.core.output_parsers import PydanticOutputParser

import glob
import logging


def load_models():
    from llama_index.llms.openai_like import OpenAILike
    llm = OpenAILike(
        # model="Qwen1.5-0.5B-Chat",
        # api_base="http://192.168.150.181:8000/v1",
        model='Mistral-7B-Instruct-v0.3',
        api_base="http://192.168.100.21:9000/v1",
        api_key='EMPTY',
        temperature=0.,
        max_tokens=1000,
    )

    from llama_index.core import Settings
    from llama_index.embeddings.huggingface import HuggingFaceEmbedding
    embed_model = HuggingFaceEmbedding(
        # model_name="BAAI/bge-small-en-v1.5",
        # model_name="BAAI/bge-small-zh-v1.5"
        # model_name="BAAI/bge-base-zh-v1.5"
        model_name="BAAI/bge-large-zh-v1.5",
        device='cpu',
    )

    Settings.llm = llm
    Settings.embed_model = embed_model
    return llm, embed_model


class ValidityReport(BaseModel):
    """Object representing the validity of values in triplet content."""
    is_valid: bool = Field(..., description="if BOTH values of the human's name and task content is a valid, return True, else, return False.")
    reason: str = Field(..., description="give the reason why you return True or False.")

from llama_index.core.query_pipeline import QueryPipeline
from llama_index.core import PromptTemplate

class CheckTripletContent:

    def __init__(self, llm):

        output_parser = PydanticOutputParser(ValidityReport)
        json_prompt_str = """
                Please check the STRING given to one Chinese person as a name. Is it a valid name for a person?
                the STRING is {name}.
                And then, continue checking the TASK content. Is it a valid task which need human to execute?
                the TASK is {task}.
                
                Output with the following JSON format:
                """

        json_prompt_str = output_parser.format(json_prompt_str)

        # add JSON spec to prompt template
        json_prompt_tmpl = PromptTemplate(json_prompt_str)

        self.qp = QueryPipeline(chain=[json_prompt_tmpl, llm, output_parser], verbose=True)

    def __call__(self, triplet):
        logging.debug(f'------------------------------')
        output = self.qp.run(name=triplet['people'], task=triplet['task'])
        logging.debug(f'output: {output}')
        return output



def main():

    llm, embed_model = load_models()

    check_tool = CheckTripletContent(llm=llm)
    result = check_tool(
        # triplet={'task': '情况13-安全预案-针对以上风险点，分别制定安全预案', 'people': '测船驶向预先考察停船位置停泊', 'work': '做好安全防护'},\
        # {'task': '情况13-安全预案-针对以上风险点，分别制定安全预案', 'people': '安全小组', 'work': '对测船及码头的安全性检查'}
        {'task': '测定水位', 'people': '刘凯<测洪预备队员>', 'work': '人工观测水位'}

    )

    print(result.model_dump())

    '''
    {
      "is_valid": false,
      "reason": "The given string is not a name for a person and the task is not a task that a human can execute."
    }

    {
      "is_valid": true,
      "reason": "The given string '安全小组' can be a name for a group or a team in Chinese, and the task '情况13-安全预案-针对以上风险点，分别制定安全预案' is a valid task that requires human execution."
    }
    {
      "is_valid": true,
      "reason": "The given name 刘凯<测洪预备队员> is a valid name for a person in Chinese culture, and the task 测定水位 (determine water level) is a valid task that a human can execute."
    }

    '''



if __name__=='__main__':

    import sys

    logging.basicConfig(stream=sys.stdout,
                        level=logging.DEBUG,
                        format="[%(levelname)s] %(filename)s[%(levelno)s]{%(funcName)s} %(message)s")

    main()



