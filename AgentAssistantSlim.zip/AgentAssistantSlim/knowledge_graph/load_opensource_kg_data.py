import pandas as pd


def main():

    file_path = '/home/data/Downloads/ownthink_v2.csv'
    df = pd.read_csv(file_path)
    print(df.head())





if __name__=='__main__':

    main()

