import os

os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'

from transformers import pipeline


def example1():
    triplet_extractor = pipeline('text2text-generation',
                                 model='Babelscape/rebel-large',
                                 tokenizer='Babelscape/rebel-large'
                                 )
    # We need to use the tokenizer manually since we need special tokens.
    extracted_text = triplet_extractor.tokenizer.batch_decode(
        [
            triplet_extractor(
                # "Punta Cana is a resort town in the municipality of Higuey, in La Altagracia Province, the eastern most province of the Dominican Republic",
                "情况2|测报方案|1.吊箱缆道因河势改变无法使用或因暴雨、洪水发生损毁时，测报方案如下：（1）在测验条件满足ADCP法测验时，使用冲锋舟或过河缆悬吊黄测1107牵引ADCP测验（驾驶：孙彦钊，机舱：吴雷，ADCP操作：黄国飞、尚景伟）。（2）在测验条件不满足ADCP法测验时，采用过河索悬吊黄测1107（驾驶：孙彦钊，机舱：吴雷）流速仪法测验，流量测验程序、流速测算仪测记（尚景伟、黄国飞），GNSS或六分仪交汇法定位（黄国立），测深仪、重铅鱼、测深杆、测深锤测深（侯宪省、吴雷），悬索悬吊流速仪施测流速（赵彦龙、吕金闯）。2.吊船缆道因河势改变无法使用或因暴雨、洪水发生损毁时，测报方案如下：采用黄测1107或黄测1108抛锚法施测（1107驾驶：孙彦钊，1108驾驶：董进东），流速仪法测验，流量测验程序、流速测算仪测记（尚景伟、黄国飞），GNSS或六分仪交汇法定位（黄国立），测深仪、重铅鱼、测深杆、测深锤测深（侯宪省、吴雷）。",
                return_tensors=True,
                return_text=False
            )[0]["generated_token_ids"]
        ])
    print(extracted_text[0])

    # Function to parse the generated text and extract the triplets
    def extract_triplets(text):
        triplets = []
        relation, subject, relation, object_ = '', '', '', ''
        text = text.strip()
        current = 'x'
        for token in text.replace("<s>", "").replace("<pad>", "").replace("</s>", "").split():
            if token == "<triplet>":
                current = 't'
                if relation != '':
                    triplets.append({'head': subject.strip(), 'type': relation.strip(), 'tail': object_.strip()})
                    relation = ''
                subject = ''
            elif token == "<subj>":
                current = 's'
                if relation != '':
                    triplets.append({'head': subject.strip(), 'type': relation.strip(), 'tail': object_.strip()})
                object_ = ''
            elif token == "<obj>":
                current = 'o'
                relation = ''
            else:
                if current == 't':
                    subject += ' ' + token
                elif current == 's':
                    object_ += ' ' + token
                elif current == 'o':
                    relation += ' ' + token
        if subject != '' and relation != '' and object_ != '':
            triplets.append({'head': subject.strip(), 'type': relation.strip(), 'tail': object_.strip()})
        return triplets

    extracted_triplets = extract_triplets(extracted_text[0])
    print(extracted_triplets)
    for i, elem in enumerate(extracted_triplets):
        print(f'-------------- {i} ---------------')
        print(elem)


def example2():
    from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

    def extract_triplets(text):
        triplets = []
        relation, subject, relation, object_ = '', '', '', ''
        text = text.strip()
        current = 'x'
        for token in text.replace("<s>", "").replace("<pad>", "").replace("</s>", "").split():
            if token == "<triplet>":
                current = 't'
                if relation != '':
                    triplets.append({'head': subject.strip(), 'type': relation.strip(), 'tail': object_.strip()})
                    relation = ''
                subject = ''
            elif token == "<subj>":
                current = 's'
                if relation != '':
                    triplets.append({'head': subject.strip(), 'type': relation.strip(), 'tail': object_.strip()})
                object_ = ''
            elif token == "<obj>":
                current = 'o'
                relation = ''
            else:
                if current == 't':
                    subject += ' ' + token
                elif current == 's':
                    object_ += ' ' + token
                elif current == 'o':
                    relation += ' ' + token
        if subject != '' and relation != '' and object_ != '':
            triplets.append({'head': subject.strip(), 'type': relation.strip(), 'tail': object_.strip()})
        return triplets

    # Load model and tokenizer
    tokenizer = AutoTokenizer.from_pretrained("Babelscape/rebel-large")
    model = AutoModelForSeq2SeqLM.from_pretrained("Babelscape/rebel-large")
    gen_kwargs = {
        "max_length": 256,
        "length_penalty": 0,
        "num_beams": 3,
        "num_return_sequences": 3,
    }

    # Text to extract triplets from
    text = 'Punta Cana is a resort town in the municipality of Higüey, in La Altagracia Province, the easternmost province of the Dominican Republic.'

    # Tokenizer text
    model_inputs = tokenizer(text, max_length=256, padding=True, truncation=True, return_tensors='pt')

    # Generate
    generated_tokens = model.generate(
        model_inputs["input_ids"].to(model.device),
        attention_mask=model_inputs["attention_mask"].to(model.device),
        **gen_kwargs,
    )

    # Extract text
    decoded_preds = tokenizer.batch_decode(generated_tokens, skip_special_tokens=False)

    # Extract triplets
    for idx, sentence in enumerate(decoded_preds):
        print(f'Prediction triplets sentence {idx}')
        print(extract_triplets(sentence))


def mrebel_example1():
    from transformers import pipeline

    triplet_extractor = pipeline('translation_xx_to_yy',
                                 model='Babelscape/mrebel-large',
                                 tokenizer='Babelscape/mrebel-large',
                                 )
    # We need to use the tokenizer manually since we need special tokens.
    # text = "The Red Hot Chili Peppers were formed in Los Angeles by Kiedis, Flea, guitarist Hillel Slovak and drummer Jack Irons.",
    text = "情况2|测报方案|1.吊箱缆道因河势改变无法使用或因暴雨、洪水发生损毁时，测报方案如下：（1）在测验条件满足ADCP法测验时，使用冲锋舟或过河缆悬吊黄测1107牵引ADCP测验（驾驶：孙彦钊，机舱：吴雷，ADCP操作：黄国飞、尚景伟）。（2）在测验条件不满足ADCP法测验时，采用过河索悬吊黄测1107（驾驶：孙彦钊，机舱：吴雷）流速仪法测验，流量测验程序、流速测算仪测记（尚景伟、黄国飞），GNSS或六分仪交汇法定位（黄国立），测深仪、重铅鱼、测深杆、测深锤测深（侯宪省、吴雷），悬索悬吊流速仪施测流速（赵彦龙、吕金闯）。2.吊船缆道因河势改变无法使用或因暴雨、洪水发生损毁时，测报方案如下：采用黄测1107或黄测1108抛锚法施测（1107驾驶：孙彦钊，1108驾驶：董进东），流速仪法测验，流量测验程序、流速测算仪测记（尚景伟、黄国飞），GNSS或六分仪交汇法定位（黄国立），测深仪、重铅鱼、测深杆、测深锤测深（侯宪省、吴雷）。",

    extracted_text = triplet_extractor.tokenizer.batch_decode(
        [
            triplet_extractor(
                text,
                decoder_start_token_id=250058,
                # src_lang="en_XX",
                src_lang='zh_XX',
                tgt_lang="<triplet>",
                return_tensors=True,
                return_text=False,
            )[0]["translation_token_ids"],
        ])  # change en_XX for the language of the source.
    print(extracted_text[0])

    # Function to parse the generated text and extract the triplets
    def extract_triplets_typed(text):
        triplets = []
        relation = ''
        text = text.strip()
        current = 'x'
        subject, relation, object_, object_type, subject_type = '', '', '', '', ''

        for token in text.replace("<s>", "").replace("<pad>", "").replace("</s>", "").replace("tp_XX", "").replace(
                "__en__", "").split():
            if token == "<triplet>" or token == "<relation>":
                current = 't'
                if relation != '':
                    triplets.append({'head': subject.strip(), 'head_type': subject_type, 'type': relation.strip(),
                                     'tail': object_.strip(), 'tail_type': object_type})
                    relation = ''
                subject = ''
            elif token.startswith("<") and token.endswith(">"):
                if current == 't' or current == 'o':
                    current = 's'
                    if relation != '':
                        triplets.append({'head': subject.strip(), 'head_type': subject_type, 'type': relation.strip(),
                                         'tail': object_.strip(), 'tail_type': object_type})
                    object_ = ''
                    subject_type = token[1:-1]
                else:
                    current = 'o'
                    object_type = token[1:-1]
                    relation = ''
            else:
                if current == 't':
                    subject += ' ' + token
                elif current == 's':
                    object_ += ' ' + token
                elif current == 'o':
                    relation += ' ' + token
        if subject != '' and relation != '' and object_ != '' and object_type != '' and subject_type != '':
            triplets.append(
                {'head': subject.strip(), 'head_type': subject_type, 'type': relation.strip(), 'tail': object_.strip(),
                 'tail_type': object_type})
        return triplets

    extracted_triplets = extract_triplets_typed(extracted_text[0])
    print(extracted_triplets)
    for i, elem in enumerate(extracted_triplets):
        print(f'-------------- {i} ---------------')
        print(elem)


def mrebel_example2():
    from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

    def extract_triplets_typed(text):
        triplets = []
        relation = ''
        text = text.strip()
        current = 'x'
        subject, relation, object_, object_type, subject_type = '', '', '', '', ''

        for token in text.replace("<s>", "").replace("<pad>", "").replace("</s>", "").replace("tp_XX", "").replace(
                "__en__", "").split():
            if token == "<triplet>" or token == "<relation>":
                current = 't'
                if relation != '':
                    triplets.append({'head': subject.strip(), 'head_type': subject_type, 'type': relation.strip(),
                                     'tail': object_.strip(), 'tail_type': object_type})
                    relation = ''
                subject = ''
            elif token.startswith("<") and token.endswith(">"):
                if current == 't' or current == 'o':
                    current = 's'
                    if relation != '':
                        triplets.append({'head': subject.strip(), 'head_type': subject_type, 'type': relation.strip(),
                                         'tail': object_.strip(), 'tail_type': object_type})
                    object_ = ''
                    subject_type = token[1:-1]
                else:
                    current = 'o'
                    object_type = token[1:-1]
                    relation = ''
            else:
                if current == 't':
                    subject += ' ' + token
                elif current == 's':
                    object_ += ' ' + token
                elif current == 'o':
                    relation += ' ' + token
        if subject != '' and relation != '' and object_ != '' and object_type != '' and subject_type != '':
            triplets.append(
                {'head': subject.strip(), 'head_type': subject_type, 'type': relation.strip(), 'tail': object_.strip(),
                 'tail_type': object_type})
        return triplets

    # Load model and tokenizer
    tokenizer = AutoTokenizer.from_pretrained("Babelscape/mrebel-large",
                                              # src_lang="en_XX",
                                              # src_lang="zh",
                                              tgt_lang="tp_XX")
    # Here we set English ("en_XX") as source language. To change the source language swap the first token of the input for your desired language or change to supported language. For catalan ("ca_XX") or greek ("el_EL") (not included in mBART pretraining) you need a workaround:
    # tokenizer._src_lang = "ca_XX"
    # tokenizer.cur_lang_code_id = tokenizer.convert_tokens_to_ids("ca_XX")
    # tokenizer.set_src_lang_special_tokens("ca_XX")
    model = AutoModelForSeq2SeqLM.from_pretrained("Babelscape/mrebel-large")
    gen_kwargs = {
        "max_length": 256,
        "length_penalty": 0,
        "num_beams": 3,
        "num_return_sequences": 3,
        "forced_bos_token_id": None,
    }

    # Text to extract triplets from
    # text = 'The Red Hot Chili Peppers were formed in Los Angeles by Kiedis, Flea, guitarist Hillel Slovak and drummer Jack Irons.'
    text = "情况2|测报方案|1.吊箱缆道因河势改变无法使用或因暴雨、洪水发生损毁时，测报方案如下：（1）在测验条件满足ADCP法测验时，使用冲锋舟或过河缆悬吊黄测1107牵引ADCP测验（驾驶：孙彦钊，机舱：吴雷，ADCP操作：黄国飞、尚景伟）。（2）在测验条件不满足ADCP法测验时，采用过河索悬吊黄测1107（驾驶：孙彦钊，机舱：吴雷）流速仪法测验，流量测验程序、流速测算仪测记（尚景伟、黄国飞），GNSS或六分仪交汇法定位（黄国立），测深仪、重铅鱼、测深杆、测深锤测深（侯宪省、吴雷），悬索悬吊流速仪施测流速（赵彦龙、吕金闯）。2.吊船缆道因河势改变无法使用或因暴雨、洪水发生损毁时，测报方案如下：采用黄测1107或黄测1108抛锚法施测（1107驾驶：孙彦钊，1108驾驶：董进东），流速仪法测验，流量测验程序、流速测算仪测记（尚景伟、黄国飞），GNSS或六分仪交汇法定位（黄国立），测深仪、重铅鱼、测深杆、测深锤测深（侯宪省、吴雷）。",

    # Tokenizer text
    model_inputs = tokenizer(text, max_length=256, padding=True, truncation=True, return_tensors='pt')

    # Generate
    generated_tokens = model.generate(
        model_inputs["input_ids"].to(model.device),
        attention_mask=model_inputs["attention_mask"].to(model.device),
        decoder_start_token_id=tokenizer.convert_tokens_to_ids("tp_XX"),
        **gen_kwargs,
    )

    # Extract text
    decoded_preds = tokenizer.batch_decode(generated_tokens, skip_special_tokens=False)

    # Extract triplets
    for idx, sentence in enumerate(decoded_preds):
        print(f'Prediction triplets sentence {idx}')
        print(extract_triplets_typed(sentence))


if __name__ == '__main__':

    example2()

