from llama_index.core import PromptTemplate


PARSE_TRIPLETS_TEMPLATE = '''
Some text is provided below. Given the text,
extract up to 3 knowledge triplets in the form of (task, people, role). Avoid stopwords.
下面的内容是关于这三个元素的定义。
    task: 任务名称，比如测试任务/测验任务/观测任务/执行动作/事件等，仅输出任务名，不要包含执行人名字;
    people: 执行人的名字，一定是人名，而不是物体或者工具名，若没有则输出"未解析出";
    work: 执行人在该任务中的工作内容/职责/负责的具体事情等，若没有则输出"未解析出";
---------------------
Example:Text: 用冲锋舟或过河缆悬吊黄测1107牵引ADCP测验（驾驶：孙彦钊，机舱：机舱，ADCP操作：黄国飞、尚景伟）
Triplets:
(用冲锋舟或过河缆悬吊黄测1107牵引ADCP测验, 孙彦钊, 驾驶)
(用冲锋舟或过河缆悬吊黄测1107牵引ADCP测验, 机舱, 机舱)
(用冲锋舟或过河缆悬吊黄测1107牵引ADCP测验, 黄国飞, ADCP操作)
(用冲锋舟或过河缆悬吊黄测1107牵引ADCP测验, 尚景伟, ADCP操作)
---------------------
Now, I will provide a Text to you, please parse the triplets of it. If no triplet relation exists, just return empty string.
Text: {text}
Triplets:
'''


class TripletParser:

    def __init__(self, llm, prompt_str=None):
        self.llm = llm
        if prompt_str is None:
            prompt_str = PARSE_TRIPLETS_TEMPLATE
        self.prompt_template = PromptTemplate(prompt_str)

    def extract_triplets(self, text):
        prompt_str = self.prompt_template.format(text=text)
        print(prompt_str)
        response = self.llm.complete(prompt_str)
        print(f'----------------- response -----------------')
        # print(response)
        triplets = parse_triplets_from_response(response.text)
        for i, tri in enumerate(triplets):
            print(i, tri)
        return triplets




def main():

    from llm_backend.mistral03.load_model import load_model
    # from llm_backend.llama3.load_model import load_model
    llm, _ = load_model()

    # prompt_template = '''
    # Some text is provided below. Given the text,
    # extract up to 3 knowledge triplets in the form of (subject, predicate, object). Avoid stopwords.
    # ---------------------
    # Example:Text: 工程部的小红驾驶一辆面包车去公司. Triplets:
    # (小红, 驾驶, 面包车)
    # (小红, 归属于, 工程部)
    # ---------------------
    # Text: {text}
    # Triplets:\n
    # '''

    # prompt_template = '''
    #     Some text is provided below. Given the text,
    #     extract up to 3 knowledge triplets in the form of (subject, relation, object). Avoid stopwords.
    #     ---------------------
    #     subject: 事件或关系的主体，可以是：人名/任务名成/组织机构/地点；
    #     relation: subject与object之间的关系，可以是：从属关系/人与任务之间的关系/人与物的关系等；
    #     object: 事件或关系的客体，可以是：人名/物品/地点等。
    #     ---------------------
    #     Now, I will provide a Text to you, please parse the triplets of it.
    #     Text: {text}
    #     Triplets:\n
    #     '''

    # prompt_template = '''
    #         Some text is provided below. Given the text,
    #         extract up to 3 knowledge triplets in the form of ("subject": <subject>, "predicate": <predicate>, "object": <object>). Avoid stopwords.
    #         ---------------------
    #         subject: 事件或关系的主体，可以是：人名/组织机构；
    #         predicate: subject与object之间的关系，可以是：从属关系/人与任务之间的关系/人与物的关系等，比如"执行"、"负责"、"操作"、"使用"等，如果提供的Text中不存在，可以自行补充；
    #         object: 时间或关系的客体，可以是：工具/任务/物品/地点等。
    #         ---------------------
    #         Now, I will provide a Text to you, please parse the triplets of it, always answer the question in Chinese.
    #         Text: {text}
    #         Triplets:\n
    #         '''

    prompt_template = '''
Some text is provided below. Given the text,
extract up to 3 knowledge triplets in the form of (task, people, role). Avoid stopwords.
下面的内容是关于这三个元素的定义。
    task: 任务名称；
    people: 执行人的名字；
    role: 执行人在该任务中的角色/职责等，若没有则输出"成员"。
---------------------
Example:Text: 用冲锋舟或过河缆悬吊黄测1107牵引ADCP测验（驾驶：孙彦钊，机舱：机舱，ADCP操作：黄国飞、尚景伟）
Triplets:
(用冲锋舟或过河缆悬吊黄测1107牵引ADCP测验, 孙彦钊, 驾驶)
(用冲锋舟或过河缆悬吊黄测1107牵引ADCP测验, 机舱, 机舱)
(用冲锋舟或过河缆悬吊黄测1107牵引ADCP测验, 黄国飞, ADCP操作)
(用冲锋舟或过河缆悬吊黄测1107牵引ADCP测验, 尚景伟, ADCP操作)
---------------------
Now, I will provide a Text to you, please parse the triplets of it.
Text: {text}
Triplets:
'''

    from llama_index.core import PromptTemplate
    prompt = PromptTemplate(prompt_template)

    text = "情况2|测报方案|1.吊箱缆道因河势改变无法使用或因暴雨、洪水发生损毁时，测报方案如下：（1）在测验条件满足ADCP法测验时，使用冲锋舟或过河缆悬吊黄测1107牵引ADCP测验（驾驶：孙彦钊，机舱：吴雷，ADCP操作：黄国飞、尚景伟）。（2）在测验条件不满足ADCP法测验时，采用过河索悬吊黄测1107（驾驶：孙彦钊，机舱：吴雷）流速仪法测验，流量测验程序、流速测算仪测记（尚景伟、黄国飞），GNSS或六分仪交汇法定位（黄国立），测深仪、重铅鱼、测深杆、测深锤测深（侯宪省、吴雷），悬索悬吊流速仪施测流速（赵彦龙、吕金闯）。2.吊船缆道因河势改变无法使用或因暴雨、洪水发生损毁时，测报方案如下：采用黄测1107或黄测1108抛锚法施测（1107驾驶：孙彦钊，1108驾驶：董进东），流速仪法测验，流量测验程序、流速测算仪测记（尚景伟、黄国飞），GNSS或六分仪交汇法定位（黄国立），测深仪、重铅鱼、测深杆、测深锤测深（侯宪省、吴雷）。"
    # text = "知识建模是解决将真实世界中的海量信息转化为符合计算机处理模式的结构化数据，其中包括对真实世界中事物的属性特征及其关系的共性的抽象，制定表示的规范，同时兼顾对常识或领域概念及概念层级体系的语义理解，即体现了对知识的认知过程。"

    # text = "希腊比墨西哥大。希腊的面积约为131,957平方公里，而墨西哥的面积约为1,964,375平方公里，使墨西哥比希腊大了1,389%。"

    # text = "工程部的小红驾驶一辆面包车去公司"

    prompt_str = prompt.format(text=text)
    print(prompt_str)
    response = llm.complete(prompt_str)
    # print(f'----------------- response -----------------')
    # print(response.text)
    triplets = parse_triplets_from_response(response.text)
    # print(triplets)
    return triplets


def parse_triplets_from_response(response_text, tags=('task', 'people', 'work')):
#     response_text = '''
# (在测验条件满足ADCP法测验时，使用冲锋舟或过河缆悬吊黄测1107牵引ADCP测验, 孙彦钊, 驾驶)
# (在测验条件满足ADCP法测验时，使用冲锋舟或过河缆悬吊黄测1107牵引ADCP测验, 吴雷, 机舱)
# (在测验条件满足ADCP法测验时，使用冲锋舟或过河缆悬吊黄测1107牵引ADCP测验, 黄国飞, ADCP操作)
# (在测验条件满足ADCP法测验时，使用冲锋舟或过河缆悬吊黄测1107牵引ADCP测验, 尚景伟, ADCP操作)
#
# (在测验条件不满足ADCP法测验时，采用过河索悬吊黄测1107流速仪法测验, 孙彦钊, 驾驶)
# (在测验条件不满足ADCP法测验时，采用过河索悬吊黄测1107流速仪法测验, 吴雷, 机舱)
# (在测验条件不满足ADCP法测验时，采用过河索悬吊黄测1107流速仪法测验, 赵彦龙, 悬索悬吊流速仪施测流速)
# (在测验条件不满足ADCP法测验时，采用过河索悬吊黄测1107流速仪法测验, 吕金闯, 悬索悬吊流速仪施测流速)
# (在测验条件不满足ADCP法测验时，采用过河索悬吊黄测1107流速仪法测验, 尚景伟, 流量测验程序、流速测算仪测记)
# (在测验条件不满足ADCP法测验时，采用过河索悬吊黄测1107流速仪法测验, 黄国飞, 流量测验程序、流速测算仪测记)
# (在测验条件不满足ADCP法测验时，采用黄测1107或黄测1108抛锚法施测, 孙彦钊, 1107驾驶)
# (在测验条件不满足ADCP法测验时，采用黄测1107或黄测1108抛锚法施测, 董进东, 1108驾驶)
# (在测验条件不满足ADCP法测验时，采用黄测1107或黄测1108抛锚法施测, 黄国立, GNSS或六分仪交汇法定位)
# (在测验条件不满足ADCP法测验时，采用黄测1107或黄测1108抛锚法施测, 侯宪省, 测深仪、重铅鱼、测深杆、测深锤测深)
# (在测验条件不满足ADCP法测验时，采用黄测1107或黄测1108抛锚法施测, 吴雷, 测深仪、重铅鱼、测深杆、测深锤测深)
#     '''

    lines = response_text.split('\n')
    triplets = []
    for i, line in enumerate(lines):
        if line is None or len(line.strip()) == 0:
            continue
        if not ('(' in line and ')' in line):
            continue
        # print(i, line)
        start_pos = line.find('(')
        end_pos = line.rfind(')')
        # print(start_pos, end_pos)
        vals = line[start_pos+1: end_pos].split(', ')
        # assert len(vals)==3, f'ERROR RESULT: {vals}'
        if len(vals) > 3:
            vals = ('，'.join(vals[0:-2]), vals[-2], vals[-1])
        elif len(vals) < 3:
            continue

        task, people, work = vals[:]
        if tags is not None:
            triplet = {
                tags[0]: task,
                tags[1]: people,
                tags[2]: work,
            }
        else:
            triplet = (task, people, work)
        triplets.append(triplet)
    return triplets



if __name__=='__main__':

    main()
    # parse_triplets_from_response()

