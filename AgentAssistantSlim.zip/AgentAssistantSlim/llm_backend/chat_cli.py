from llama_index.core import VectorStoreIndex, SimpleDirectoryReader, Settings
# from llama_index.llms.vllm import Vllm
from llama_index.llms.vllm import VllmServer
from llama_index.llms.openai_like import OpenAILike

import logging


class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


def main():
    # https://docs.llamaindex.ai/en/stable/examples/llm/vllm/
    llm = OpenAILike(
        model="Qwen1.5-0.5B-Chat",
        api_base="http://192.168.150.181:8000/v1",
        api_key='EMPTY',
        temperature=0.9,
        max_tokens=1000,
    )

    callback_manager = llm.callback_manager
    # print(f'callback_manager: {callback_manager}')

    # response = llm.complete(
    #     "What is a black hole ?"
    # )
    # print(response)

    from llama_index.core.llms import ChatMessage, MessageRole, ChatResponse
    message = [
        ChatMessage(role=MessageRole.SYSTEM, content="You are a helpful assistant. can answer all questions from human."),
        # ChatMessage(role=MessageRole.USER, content="麻婆豆腐的制作方法？")

    ]
    # response = llm.chat(message)
    # print(response.message)

    while True:
        text_input = input(bcolors.BOLD+ "[User]: " + bcolors.ENDC)
        if text_input == "exit":
            break
        if text_input == 'clear':
            message = message[0:1]
        # logging.debug(f'USER: {text_input}')
        message.append(ChatMessage(role=MessageRole.USER, content=text_input))
        response = llm.chat(message)
        # print(f"Agent: {response.raw}")
        answer = response.raw['choices'][0].text
        print(f'[AI]: {answer}')
        message.append(ChatMessage(role=MessageRole.ASSISTANT, content=answer))





if __name__ == '__main__':

    logging.basicConfig(level=logging.WARNING)

    main()
