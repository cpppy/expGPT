
def main():

    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(
        # "meta-llama/Meta-Llama-3-8B-Instruct",
        "/data/Llama-3-8B-Instruct-Gradient-1048k",
        # "/data/Llama3-ChatQA-1.5-8B"
        # "/data/Llama3-Chinese-8B-Instruct-Agent-v1",
        # "/data/Meta-Llama-3-8B-Instruct",
        padding_side='left'

    )

    stopping_ids = [
        tokenizer.eos_token_id,
        tokenizer.convert_tokens_to_ids("<|eot_id|>"),
    ]


    import torch
    from llama_index.llms.huggingface import HuggingFaceLLM

    # Optional quantization to 4bit
    # import torch
    # from transformers import BitsAndBytesConfig

    # quantization_config = BitsAndBytesConfig(
    #     load_in_4bit=True,
    #     bnb_4bit_compute_dtype=torch.float16,
    #     bnb_4bit_quant_type="nf4",
    #     bnb_4bit_use_double_quant=True,
    # )

    llm = HuggingFaceLLM(
        # model_name="meta-llama/Meta-Llama-3-8B-Instruct",
        model_name="/data/Llama-3-8B-Instruct-Gradient-1048k",
        # model_name="/data/Llama3-ChatQA-1.5-8B",
        # model_name="/data/Llama3-Chinese-8B-Instruct-Agent-v1",
        # model_name="/data/Meta-Llama-3-8B-Instruct",
        model_kwargs={
            "torch_dtype": torch.bfloat16,  # comment this line and uncomment below to use 4bit
            # "quantization_config": quantization_config
        },
        generate_kwargs={
            "do_sample": False,
            "temperature": 0,
            "top_p": 0.9,
            'pad_token_id': tokenizer.eos_token_id,
        },
        # tokenizer_name="meta-llama/Meta-Llama-3-8B-Instruct",
        # tokenizer_name="/data/Llama-3-8B-Instruct-Gradient-1048k",
        tokenizer=tokenizer,
        stopping_ids=stopping_ids,
        max_new_tokens=10240,

    )

    response = llm.complete("Who is Paul Graham?")
    print(response)

    # from llama_index.core.llms import ChatMessage, ChatResponse
    # messages = [
    #     ChatMessage(role="system", content="You are CEO of MetaAI."),
    #     ChatMessage(role="user", content="Introduce Llama3 to the world."),
    # ]
    #
    # response = llm.chat(messages)
    # print(response.message)


if __name__=='__main__':

    main()

