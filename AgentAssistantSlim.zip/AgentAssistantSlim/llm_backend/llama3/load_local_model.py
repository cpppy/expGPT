

def load_model():

    from llama_index.core import Settings
    if Settings._llm is not None:
        llm = Settings._llm
    else:
        from transformers import AutoTokenizer
        tokenizer = AutoTokenizer.from_pretrained(
            # "meta-llama/Meta-Llama-3-8B-Instruct",
            # "/data/Llama-3-8B-Instruct-Gradient-1048k",
            # "/data/Llama3-ChatQA-1.5-8B",
            # "/data/Llama3-Chinese-8B-Instruct-Agent-v1",
            "/data/Meta-Llama-3-8B-Instruct",
            padding_side='left'
        )
        stopping_ids = [
            tokenizer.eos_token_id,
            tokenizer.convert_tokens_to_ids("<|eot_id|>"),
        ]
        import torch
        from llama_index.llms.huggingface import HuggingFaceLLM
        llm = HuggingFaceLLM(
            # model_name="meta-llama/Meta-Llama-3-8B-Instruct",
            # model_name="/data/Llama-3-8B-Instruct-Gradient-1048k",
            # model_name="/data/Llama3-ChatQA-1.5-8B",
            # model_name="/data/Llama3-Chinese-8B-Instruct-Agent-v1",
            model_name="/data/Meta-Llama-3-8B-Instruct",
            model_kwargs={
                "torch_dtype": torch.bfloat16,  # comment this line and uncomment below to use 4bit
                # "quantization_config": quantization_config
            },
            generate_kwargs={
                "do_sample": False,
                "temperature": 0,
                # "top_p": 0.9,
                'pad_token_id': tokenizer.eos_token_id,
            },
            # tokenizer_name="meta-llama/Meta-Llama-3-8B-Instruct",
            # tokenizer_name="/data/Llama-3-8B-Instruct-Gradient-1048k",
            tokenizer=tokenizer,
            stopping_ids=stopping_ids,
        )
        Settings._llm = llm

    if Settings._embed_model is not None:
        embed_model = Settings._embed_model
    else:
        from llama_index.embeddings.huggingface import HuggingFaceEmbedding
        embed_model = HuggingFaceEmbedding(
            model_name="BAAI/bge-large-zh-v1.5",
            device='cpu',
        )
        Settings._embed_model = embed_model
    return llm, embed_model





