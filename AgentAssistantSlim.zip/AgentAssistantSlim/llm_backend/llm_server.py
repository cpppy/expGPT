from typing import List, Optional

from pydantic import BaseModel
import logging
logging.basicConfig(level=logging.DEBUG)

class ChatMessage(BaseModel):
    role: str
    content: str


class ChatCompletionRequest(BaseModel):
    model: str = "mock-gpt-model"
    messages: List[ChatMessage]
    max_tokens: Optional[int] = 512
    temperature: Optional[float] = 0.1
    stream: Optional[bool] = False

import time

from fastapi import FastAPI

app = FastAPI(title="OpenAI-compatible API")


@app.get("/")
async def root():
    return {"message": "Hello World"}

@app.post("/chat/completions")
async def chat_completions(request: ChatCompletionRequest):

    if request.messages and request.messages[0].role == 'user':
        resp_content = "As a mock AI Assitant, I can only echo your last message:" + request.messages[-1].content
    else:
        resp_content = "As a mock AI Assitant, I can only echo your last message, but there were no messages!"

    return {
        "id": "1337",
        "object": "chat.completion",
        "created": time.time(),
        "model": request.model,
        "choices": [{
            "message": ChatMessage(role="assistant", content=resp_content)
        }]
    }


##################################### llamaindex ################################
'''
{
    'method': 'post', 
    'url': '/completions', 
    'files': None, 
    'json_data': {
        'model': 'mock-gpt-model', 
        'prompt': 'system: You are a helpful assistant. can answer all questions from human.\nuser: 麻婆豆腐的制作方法？\nassistant: ', 
        'max_tokens': 1000, 
        'stream': False, 
        'temperature': 0.0
        }
}
'''


class LlamaIndexRequest(BaseModel):
    model: str
    prompt: str
    max_tokens: int
    stream: Optional[bool] = False
    temperature: float


'''
{
    'id': 'cmpl-41b2d7bcc32940a885ddda769f29aa84', 
    'choices': [
        CompletionChoice(
            finish_reason='stop', 
            index=0, 
            logprobs=None, 
            text='麻婆豆腐的制作方法如下：\n\n1. 准备材料：豆腐、辣椒、茄子、蒜、姜、生姜、豌豉、盐、糖、料理油、鸡蛋、淀粉、辣椒油、芝麻油。\n\n2. 切好豆腐，辣椒、茄子、蒜、姜、生姜。\n\n3. 在锅中加入料理油，将辣椒、茄子、蒜、姜、生姜炒炒，直到辣椒、茄子、蒜、姜、生姜发出香气。\n\n4. 在锅中加入豆腐，炒炒，直到豆腐外面发黄。\n\n5. 在豆腐周围，放入豌豉，炒炒，直到豌豉发黑。\n\n6. 在豆腐上撒上盐、糖，然后加入鸡蛋，搅拌，直到鸡蛋冒泡。\n\n7. 在豆腐上撒上淀粉，使豆腐外面变得凝固。\n\n8. 在豆腐上撒上辣椒油和芝麻油，然后服务。\n\n享用！'
        )
    ], 
    'created': 11434585, 
    'model': 'Mistral-7B-Instruct-v0.3', 
    'object': 'text_completion', 
    'system_fingerprint': None, 
    'usage': CompletionUsage(completion_tokens=422, prompt_tokens=39, total_tokens=461)
}

'''

class LlamaIndexMessage(BaseModel):
    finish_reason: str
    index: int
    # logrobs: None
    text: str

class LlamaIndexResponse(BaseModel):
    id: str
    created: int
    model: str
    object: str
    choices: List[LlamaIndexMessage]

    stream: Optional[bool] = False
    temperature: float


@app.post("/completions")
async def completions(request: LlamaIndexRequest):

    logging.debug(f'request: {request}')

    # if request.messages and request.messages[0].role == 'user':
    #     resp_content = "As a mock AI Assitant, I can only echo your last message:" + request.messages[-1].content
    # else:
    resp_content = "As a mock AI Assitant, I can only echo your last message, but there were no messages!"


    # return {
    #     "id": "1337",
    #     "object": "text_completion",
    #     "created": int(time.time()),
    #     "model": request.model,
    #     "choices": [{
    #         "message": ChatMessage(role="assistant", content=resp_content)
    #     }]
    # }

    return {
        'id': 'cmpl-41b2d7bcc32940a885ddda769f29aa84',
        'choices': [
            LlamaIndexMessage(
                finish_reason='stop',
                index=0,
                # logprobs=None,
                # text='麻婆豆腐的制作方法如下：\n\n1. 准备材料：豆腐、辣椒、茄子、蒜、姜、生姜、豌豉、盐、糖、料理油、鸡蛋、淀粉、辣椒油、芝麻油。\n\n2. 切好豆腐，辣椒、茄子、蒜、姜、生姜。\n\n3. 在锅中加入料理油，将辣椒、茄子、蒜、姜、生姜炒炒，直到辣椒、茄子、蒜、姜、生姜发出香气。\n\n4. 在锅中加入豆腐，炒炒，直到豆腐外面发黄。\n\n5. 在豆腐周围，放入豌豉，炒炒，直到豌豉发黑。\n\n6. 在豆腐上撒上盐、糖，然后加入鸡蛋，搅拌，直到鸡蛋冒泡。\n\n7. 在豆腐上撒上淀粉，使豆腐外面变得凝固。\n\n8. 在豆腐上撒上辣椒油和芝麻油，然后服务。\n\n享用！'
                text=resp_content,
            )
        ],
        'created': 11434585,
        'model': "mock-gpt-model",
        'object': 'text_completion',
        'system_fingerprint': None,
        # 'usage': CompletionUsage(completion_tokens=422, prompt_tokens=39, total_tokens=461)
    }


if __name__=='__main__':

    import uvicorn

    uvicorn.run(app, host="127.0.0.1", port=8000)
