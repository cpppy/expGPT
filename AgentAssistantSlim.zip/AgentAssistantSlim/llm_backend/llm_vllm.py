from llama_index.core import VectorStoreIndex, SimpleDirectoryReader, Settings
# from llama_index.llms.vllm import Vllm
from llama_index.llms.vllm import VllmServer
from llama_index.llms.openai_like import OpenAILike

def main():

    # https://docs.llamaindex.ai/en/stable/examples/llm/vllm/
    llm = OpenAILike(
        # model="Qwen1.5-0.5B-Chat",
        # api_base="http://192.168.150.181:8000/v1",
        model='Mistral-7B-Instruct-v0.2',
        api_base="http://192.168.100.21:8000/v1",
        api_key='EMPTY',
        temperature=0,
        max_tokens=1000,
    )

    # response = llm.complete(
    #     "What is a black hole ?"
    # )

    from llama_index.core.llms import ChatMessage, MessageRole, ChatResponse
    message = [
        ChatMessage(role=MessageRole.SYSTEM, content="You are a helpful assistant. can answer all questions from human."),
        ChatMessage(role=MessageRole.USER, content="麻婆豆腐的制作方法？"),
        # ChatMessage(role=MessageRole.USER, content="Hello"),
    #     ChatMessage(role=MessageRole.TOOL, content="""
    #     麻婆豆腐
    #
    # 先將碎豬肉用醃料醃10分鐘
    # 豆腐切粒
    # 下油爆香蒜加入碎豬肉炒香
    # 再加入豆辦醬、糖及鹽炒香
    # 加入水及豆腐煮2-3分鐘
    # 最後加入麻油，再用生粉水煮到醬汁杰身即可""")
    ]

    tools = [
        {
            "type": "function",
            "function": {
                "name": "retrieve_payment_status",
                "description": "Get payment status of a transaction",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "transaction_id": {
                            "type": "string",
                            "description": "The transaction id.",
                        }
                    },
                    "required": ["transaction_id"],
                },
            },
        },
        {
            "type": "function",
            "function": {
                "name": "retrieve_payment_date",
                "description": "Get payment date of a transaction",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "transaction_id": {
                            "type": "string",
                            "description": "The transaction id.",
                        }
                    },
                    "required": ["transaction_id"],
                },
            },
        }
    ]

    response = llm.chat(message, tools=tools)

    print(response.message)

    # print(llm.metadata.is_chat_model)
    #
    # response = llm.complete(prompt='what is query engine ?')
    # print(f'response: {response}')


def completion():

    qp_router = QueryPipeline(chain=[router_c])
    output = qp_router.run("which kind of fruit is benefit for human's hair ?")
    print('----------------- final output --------------------')
    print(output)

    # add branch
    prompt_str = "analyse the response from llm, then generate a new question about this topic, Response: {response_str}"
    prompt_tmpl = PromptTemplate(prompt_str)
    llm_program = CustomLLMTextCompletionProgram.from_defaults(
        # output_parser=PydanticOutputParser(output_cls=ResponseEval),
        # output_parser=CustomPydanticOutputParser(output_cls=ResponseEval),
        output_parser=CustomPydanticOutputParser(output_cls=ResponseClassify),
        prompt=prompt_tmpl,
        llm=llm,
        verbose=True,
    )
    # test llm_program
    llm_p_output = llm_program(
        response_str='orange is good for human"s health.',
    )
    logging.debug(f'llm_p_output: {llm_p_output}')


if __name__=='__main__':

    main()




