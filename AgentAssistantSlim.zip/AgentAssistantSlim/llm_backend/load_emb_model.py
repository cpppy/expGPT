from llama_index.llms.openai_like import OpenAILike
from llama_index.embeddings.openai import OpenAIEmbedding


def main():
    # # https://docs.llamaindex.ai/en/stable/examples/llm/vllm/
    # llm = OpenAILike(
    #     # model="Qwen1.5-0.5B-Chat",
    #     # api_base="http://192.168.150.181:8000/v1",
    #     model='Mistral-7B-Instruct-v0.2',
    #     api_base="http://192.168.100.21:8000/v1",
    #     api_key='EMPTY',
    #     temperature=0,
    #     max_tokens=1000,
    # )

    # api_base = "http://192.168.100.21:8002/v1"
    api_base = "http://192.168.100.24:8002/v1"

    from llama_index.embeddings.openai import OpenAIEmbedding
    text_embedder = OpenAIEmbedding(
        # model='BAAI--bge-large-zh-v1.5',
        model="text-embedding-3-small",
        api_base=api_base,
        api_key='EMPTY')

    text = "Hello, world!"
    res = text_embedder.get_text_embedding(text)
    print(res)

    from openai import OpenAI
    client = OpenAI(base_url=api_base, api_key='EMPTY')
    text = "Hello, world!"
    # you can change the model to the actual model you use
    # model = "text2vec-base-chinese"
    model = 'BAAI--bge-large-zh-v1.5'
    res = client.embeddings.create(input=[text], model=model).data[0].embedding
    print(res)


if __name__ == '__main__':
    main()
