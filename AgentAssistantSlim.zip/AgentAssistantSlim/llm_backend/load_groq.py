import groq


def main():
    import os
    from groq import Groq

    client = Groq(
        api_key="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",
        base_url="http://47.237.0.195:8081/openai/v1",

    )

    chat_completion = client.chat.completions.create(
        messages=[
            {
                "role": "user",
                "content": "Explain the importance of low latency LLMs",
            }
        ],
        model="llama3-8b-8192",
    )
    print(chat_completion.choices[0].message.content)

if __name__=='__main__':

    main()