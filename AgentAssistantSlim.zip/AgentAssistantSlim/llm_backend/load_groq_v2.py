# from llama_index.llms.openai_like import OpenAILike

def main():
    # # https://docs.llamaindex.ai/en/stable/examples/llm/vllm/
    # llm = OpenAILike(
    #     # model="Qwen1.5-0.5B-Chat",
    #     # api_base="http://192.168.150.181:8000/v1",
    #     # model='Mistral-7B-Instruct-v0.2',
    #     # api_base="http://192.168.100.21:8000/v1",
    #     # api_key='EMPTY',
    #
    #     model="llama3-8b-8192",
    #     api_base="http://47.237.0.195:8080",
    #     api_key="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",
    #     temperature=0,
    #     max_tokens=1000,
    # )

    from llama_index.llms.groq import Groq
    llm = Groq(
        # model="mixtral-8x7b-32768",
        model="llama3-8b-8192",
        api_base="http://47.237.0.195:8081/openai/v1",
        api_key="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",
    )

    # response = llm.complete(prompt='what is query engine ?')
    # print(f'response: {response}')

    from llama_index.core.llms import ChatMessage, MessageRole, ChatResponse
    message = [
        ChatMessage(role=MessageRole.SYSTEM,
                    content="You are a helpful assistant. can answer all questions from human."),
        ChatMessage(role=MessageRole.USER, content="麻婆豆腐的制作方法？"),
    ]

    response = llm.chat(message)
    # print(response.message)
    print(response.raw)


def groq_proxy():
    import os
    from groq import Groq

    client = Groq(
        # This is the default and can be omitted
        base_url="http://47.237.0.195:8081",
        api_key="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",
    )

    chat_completion = client.chat.completions.create(
        messages=[
            {
                "role": "user",
                "content": "Explain the importance of low latency LLMs",
            }
        ],
        model="llama3-8b-8192",
    )
    print(chat_completion.choices[0].message.content)


if __name__ == '__main__':
    # main()
    groq_proxy()
