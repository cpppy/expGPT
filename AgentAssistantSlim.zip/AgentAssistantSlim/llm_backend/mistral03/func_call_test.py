

def main():
    # Building Hybrid Retrieval with Chunk Embedding + Parent Embedding
    from llama_index.llms.openai_like import OpenAILike
    llm = OpenAILike(
        # model='Mistral-7B-Instruct-v0.2',
        # api_base="http://192.168.100.21:8000/v1",

        model='Mistral-7B-Instruct-v0.3',
        api_base="http://192.168.100.21:9000/v1",
        api_key='EMPTY',
        temperature=0.,
        max_tokens=2048,
    )

    raw_input = """
    [AVAILABLE_TOOLS] [{"type": "function", "function": {"name": "get_current_weather", "description": "Get the current weather", "parameters": {"type": "object", "properties": {"location": {"type": "string", "description": "The city and state, e.g. San Francisco, CA"}, "format": {"type": "string", "enum": ["celsius", "fahrenheit"], "description": "The temperature unit to use. Infer this from the users location."}}, "required": ["location", "format"]}}}][/AVAILABLE_TOOLS][INST] What is the weather like today in San Francisco [/INST]
    
    """

    response = llm.complete(raw_input)
    print(response)



def format_tool_explaination():
    from mistral_common.protocol.instruct.tool_calls import Function, Tool
    tools = [
        Tool(
            function=Function(
                name="get_current_weather",
                description="Get the current weather",
                parameters={
                    "type": "object",
                    "properties": {
                        "location": {
                            "type": "string",
                            "description": "The city and state, e.g. San Francisco, CA",
                        },
                        "format": {
                            "type": "string",
                            "enum": ["celsius", "fahrenheit"],
                            "description": "The temperature unit to use. Infer this from the users location.",
                        },
                    },
                    "required": ["location", "format"],
                },
            )
        )
    ]
    # print(tools)
    # tool_str = tools[0].model_dump()
    import json
    # tool_str = json.dumps(tool_str)
    # print(tool_str)

    # tools_str = '[' + ', '.join([json.dumps(t.model_dump()) for t in tools]) + ']'
    # print(tools_str)

    tools_str = json.dumps([t.model_dump() for t in tools])
    print(tools_str)

    query_str = "What is the weather like today in San Francisco"
    
    tool_template = f"""
    [AVAILABLE_TOOLS] {tools_str}[/AVAILABLE_TOOLS][INST] {query_str} [/INST]
    """

    # Building Hybrid Retrieval with Chunk Embedding + Parent Embedding
    from llama_index.llms.openai_like import OpenAILike
    llm = OpenAILike(
        # model='Mistral-7B-Instruct-v0.2',
        # api_base="http://192.168.100.21:8000/v1",

        model='Mistral-7B-Instruct-v0.3',
        api_base="http://192.168.100.21:9000/v1",
        api_key='EMPTY',
        temperature=0.,
        max_tokens=2048,
    )

    response = llm.complete(tool_template)
    print(response)


if __name__ == '__main__':

    # main()
    format_tool_explaination()
