
'''
https://community.aws/content/2dFNOnLVQRhyrOrMsloofnW0ckZ/how-to-prompt-mistral-ai-models-and-why

https://github.com/vllm-project/vllm/issues/2080
'''



# Transform a string into input zephyr-specific input
def completion_to_prompt(completion):
    # return f"<|system|>\n</s>\n<|user|>\n{completion}</s>\n<|assistant|>\n"
    return f"<s>[INST]{completion}[/INST]"


# Transform a list of chat messages into zephyr-specific input
def messages_to_prompt(messages):
    prompt = "<s>"
    for message in messages:
        if message.role == "system":
            prompt += f"[INST]{message.content}[/INST]</s>"
        elif message.role == "user":
            prompt += f"[INST]\n{message.content}[/INST]"
        elif message.role == "assistant":
            prompt += f"{message.content}</s>"

    # # ensure we start with a system prompt, insert blank if needed
    # if not prompt.startswith("<|system|>\n"):
    #     prompt = "<|system|>\n</s>\n" + prompt

    # # add final assistant prompt
    # prompt = prompt + "<|assistant|>\n"

    return prompt


def main():
    sample = '<s>[INST] What\'s the weather like today in Paris[/INST][TOOL_CALLS] [{"name": "get_current_weather", "arguments": {"location": "Paris, France", "format": "celsius"}, "id": "VvvODy9mT"}]</s>[TOOL_RESULTS] {"call_id": "VvvODy9mT", "content": 22}[/TOOL_RESULTS] The current temperature in Paris, France is 22 degrees Celsius.</s>[AVAILABLE_TOOLS] [{"type": "function", "function": {"name": "get_current_weather", "description": "Get the current weather", "parameters": {"type": "object", "properties": {"location": {"type": "string", "description": "The city and state, e.g. San Francisco, CA"}, "format": {"type": "string", "enum": ["celsius", "fahrenheit"], "description": "The temperature unit to use. Infer this from the users location."}}, "required": ["location", "format"]}}}][/AVAILABLE_TOOLS][INST] What\'s the weather like today in San Francisco[/INST][TOOL_CALLS] [{"name": "get_current_weather", "arguments": {"location": "San Francisco", "format": "celsius"}, "id": "fAnpW3TEV"}]</s>[TOOL_RESULTS] {"call_id": "fAnpW3TEV", "content": 20}[/TOOL_RESULTS]'
    print(sample)

if __name__=='__main__':

    main()