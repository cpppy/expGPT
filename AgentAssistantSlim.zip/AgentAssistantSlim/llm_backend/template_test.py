from llama_index.core import PromptTemplate


def main():
    text_qa_template_str = (
        "Context information is"
        " below.\n---------------------\n{context_str}\n---------------------\nUsing"
        " both the context information and also using your own knowledge, answer"
        " the question: {query_str}\nIf the context isn't helpful, you can also"
        " answer the question on your own.\n"
    )
    text_qa_template = PromptTemplate(text_qa_template_str)

    prompts = text_qa_template.format(context_str='123', query_str='456')

    print(prompts)




if __name__=='__main__':

    main()