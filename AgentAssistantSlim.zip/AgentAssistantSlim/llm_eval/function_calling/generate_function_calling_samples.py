from llama_index.core import VectorStoreIndex, SimpleDirectoryReader, Settings
# from llama_index.llms.vllm import Vllm
from llama_index.llms.vllm import VllmServer
from llama_index.llms.openai_like import OpenAILike

from llama_index.core import PromptTemplate
from router.llm_program import CustomLLMTextCompletionProgram
import re
import json


def parser_actions(text):
    # text = '\n{\n    "remember": "User greeted me",\n    "thoughts": "User said \'Hi\'. I don\'t know what they want.",\n    "reasoning": "Greeting is a common way to start a conversation. I need to find out what the user wants.",\n    "plan": "Ask the user for their request.",\n    "command": {\n        "action": "ask_user_for_request"\n    }\n}\n\nuser: I want to know the square root of 144\nassistant: \n{\n    "remember": "User asked for the square root of 144",\n    "thoughts": "User asked for the square root of a number.",\n    "reasoning": "The user\'s request can be calculated using the square root function.",\n    "plan": "Calculate the square root of 144.",\n    "command": {\n        "action": "calculate_square_root",\n        "args": {"number": 144}\n    }\n}\n\nassistant: 12\n{\n    "remember": "Calculated the square root of 144 to be 12",\n    "thoughts": "I have calculated the square root of 144.",\n    "reasoning": "The user asked for the square root of 144, and I have now provided the answer.",\n    "plan": "None",\n    "command": {\n        "action": "none"\n    }\n}\n\nuser: What is the capital city of France?\nassistant: \n{\n    "remember": "User asked for the capital city of France",\n    "thoughts": "User asked for the capital city of a country.",\n    "reasoning": "The capital city of France can be found by searching the web.",\n    "plan": "Search the web for the capital city of France.",\n    "command": {\n        "action": "search_web",\n        "args": {"query": "capital city of France"}\n    }\n}\n\n{\n    "remember": "Searched the web for the capital city of France and found \'Paris\'",\n    "thoughts": "I have found the capital city of France to be \'Paris\'.",\n    "reasoning": "The user asked for the capital city of France, and I have now provided the answer.",\n    "plan": "None",\n    "command": {\n        "action": "none"\n    }\n}\n\nassistant: Paris\n{\n    "remember": "Calculated the square root of 144 to be 12 and found the capital city of France to be \'Paris\'",\n    "thoughts": "I have both calculated the square root of 144 and found the capital city of France.",\n    "reasoning": "The user asked for two different things, and I have now provided answers for both.",\n    "plan": "None",\n    "command": {\n        "action": "none"\n    }\n}'

    # pattern = r'"action": "(.*?)"'
    # pattern = r'"action": "(.*?)"'
    # pattern = r'"action": "(.*?)"(?:,\n\s*"args": {(.*?)})?'
    pattern = r'"action": "(.*?)"(?:,\n\s*"args": ({.*?}))?'
    result = re.findall(pattern, text, re.DOTALL)
    # print(result)
    actions = []
    for r in result:
        # print(repr(r))
        # print(r[0], json.loads(r[1]) if r[1] != '' else r[1])
        action_name = r[0]
        if action_name == 'none':
            continue

        if r[1] != '':
            args = json.loads(r[1])
        else:
            args = {}
        actions.append(dict(
            action=action_name,
            args=args,
        ))
    return actions


def main():
    # https://docs.llamaindex.ai/en/stable/examples/llm/vllm/
    llm = OpenAILike(
        # model="Qwen1.5-0.5B-Chat",
        # api_base="http://192.168.150.181:8000/v1",
        model='Mistral-7B-Instruct-v0.2',
        api_base="http://192.168.100.21:8000/v1",
        api_key='EMPTY',
        temperature=0,
        max_tokens=1000,
    )

    # response = llm.complete(
    #     "What is a black hole ?"
    # )

    from llama_index.core.llms import ChatMessage, MessageRole, ChatResponse
    message = [
        ChatMessage(role=MessageRole.SYSTEM,
                    content="You are a helpful assistant. can answer all questions from human."),
        ChatMessage(role=MessageRole.USER, content="麻婆豆腐的制作方法？"),
        # ChatMessage(role=MessageRole.USER, content="Hello"),
        #     ChatMessage(role=MessageRole.TOOL, content="""
        #     麻婆豆腐
        #
        # 先將碎豬肉用醃料醃10分鐘
        # 豆腐切粒
        # 下油爆香蒜加入碎豬肉炒香
        # 再加入豆辦醬、糖及鹽炒香
        # 加入水及豆腐煮2-3分鐘
        # 最後加入麻油，再用生粉水煮到醬汁杰身即可""")
    ]
    response = llm.chat(message)

    print(response.message)

    # print(llm.metadata.is_chat_model)
    #
    # response = llm.complete(prompt='what is query engine ?')
    # print(f'response: {response}')


def completion():
    llm = OpenAILike(
        model='Mistral-7B-Instruct-v0.3',
        api_base="http://192.168.100.21:9000/v1",
        api_key='EMPTY',
        temperature=0,
        max_tokens=2048,
    )

    prompt = """
你是一个文本数据合成方面的专家，现在你需要从一个接口描述信息中学习这个接口的具体用途，然后模拟人的提问方式，提出一些使用过程中可能出现的问题。
现在举例：
------------------------
下面是一个处理加法操作的接口信息：
{
    "action": "add", 
    "args": {
        "a": a: int, 
        "b": b: int
     }
}
用户提问：
1. 请问8+3的答案是什么？
2. 1+2等于几？
3. 告诉我100+200的结果？
...
------------------------
举例结束，现在给你如下接口信息：
{
    "action": "蓄积量及变化", 
    "action_description": 森林资源数量模块, 输入任意地区类型和编号查询对应的蓄积量及变化, 
    "args": {
        "dateSign": 二调数据年份，默认值是2019。数据类型为string, 可选参数，若不存在则输出2019。
        "regionCode": 任意地区对应的编号。数据类型为string, 可选参数，若不存在则返回null。
        "regionType": 任意地区类型枚举，分别为【伊春森工：sengong，林业局：linyeju，林场：linchang,小班：xiaoban】。数据类型为string, 可选参数，若不存在则不需要解析。
    }
}
用户提问：
"""

    response = llm.complete(prompt)
    print(f'response: {response}')

'''
1. 请问2019年伊春森工的蓄积量及变化是什么？
2. 请问2020年林业局的蓄积量及变化是什么？
3. 请问2019年林场的蓄积量及变化是什么？
4. 请问2020年小班的蓄积量及变化是什么？
5. 请问2019年伊春森工的蓄积量是多少？
6. 请问2020年林业局的蓄积量是多少？
7. 请问2019年林场的蓄积量是多少？
8. 请问2020年小班的蓄积量是多少？
9. 请问2019年伊春森工的蓄积量变化是多少？
10. 请问2020年林业局的蓄积量变化是多少？
11. 请问2019年林场的蓄积量变化是多少？
12. 请问2020年小班的蓄积量变化是多少？
13. 请问2019年伊春森工的蓄积量及变化是什么？
14. 请问2020年林业局的蓄积量及变化是什么？
15. 请问2019年林场的蓄积量及变化是什么？
16. 请问2020年小班的蓄积量及变化是什么？
17. 请问2019年伊春森工的蓄积量是多少，并且要求输出为数字。
18. 请问2020年林业局的蓄积量是多少，并且要求输出为数字。
19. 请问2019年林场的蓄积量是多少，并且要求输出为数字。
20. 请问2020年小班的蓄积量是多少，并且要求输出为数字。
21. 请问2019年伊春森工的蓄积量变化是多少，并且要求输出为数字。
22. 请问2020年林业局的蓄积量变化是多少，并且要求输出为数字。
23. 请问2019年林场的蓄积量变化是多少，并且要求输出为数字。
24. 请问2020年小班的蓄积量变化是多少，并且要求输出为数字。
25. 请问2019年伊春森工的蓄积量及变化是什么，并且要求输出为数字。
26. 请问2020年林业局的蓄积量及变化是什么，并且要求输出为数字。
27. 请问2019年林场的蓄积量及变化是什么，并且要求输出为数字。
28. 请问2020年小班的蓄积量及变化是什么，并且要求输出为数字。
29. 请问2019年伊春森工的蓄积量是多少，并且要求输出为数字，同时要求输出的数字保留两位小数。
30. 请问2020年林业局的蓄积量是多少，并且要求输出为数字，同时要求输出的数字保留两位小数。
31. 请问2019年林场的蓄积量是多少，并且要求输出为数字，同时要求输出的数字保留两位小数。
32. 请问2020年小班的蓄积量是多少，并且要求输出为数字，同时要求输出的数字保留两位小数。
33. 请问2019年伊春森工的蓄积量变化是多少，并且要求输出为数字，同时要求输出的数字保留两位小数。
34. 请问2020年林业局的蓄积量变化是多少，并且要求输出为数字，同时要求输出的数字保留两位小数。
35. 请问2019年林场的蓄积量变化是多少，并且要求输出为数字，同时要求输出的数字保留两位小数。
36. 请问2020年小班的蓄积量变化是多少，并且要求输出为数字，同时要求输出的数字保留两位小数。
37. 请问2019年伊春森工的蓄积量及变化是什么，并且要求输出为数字，同时要求输出的数字保留两位小数。
38. 请问2020年林业局的蓄积量及变化是什么，并且要求输出为数字，同时要求输出的数字保留两位小数。
39. 请问2019年林场的蓄积量及变化是什么，并且要求输出为数字，同时要求输出的数字保留两位小数。
40. 请问2020年小班的蓄积量及变化是什么，并且要求输出为数字，同时要求输出的数字保留两位小数。
41. 请问2019年伊春森工的蓄积量是多少，并且要求输出为数字，同时要求输出的数字保留两位小数，同时要求输出的数字是正数。
42. 请问2020年林业局的蓄积量是多少，并且要求输出为数字，同时要求输出的数字保留两位小数，同时要求输出的数字是正数。
43. 请问2019年林场的蓄积量是多少，并且要求输出为数字，同时要求输出的数字保留两位小数，同时要求输出的数字是正数。
44. 请问2020年小班的蓄积量是多少，并且要求输出为数字，同时要求输出的数字保留两位小数，同时要求输出的数字是正数。
45. 请问2019年伊春森工的蓄积量变化是多少，并且要求输出为数字，同时要求输出的数字保留两位小数，同时要求输出的数字是正数。
46. 请问2020年林业局的蓄积量变化是多少，并且要求输出为数字，同时要求输出的数字保留两位小数，同时要求输出的数字是正数。
47. 请问2019年林场的蓄积量变化是多少，并且要求输出为数字，同时要求输出的数字保留两位小数，同时要求输出的数字是正数。
48. 请问2020年小班的蓄积量变化是多少，并且要求输出为数字，同时要求输出的数字保留两位小数，同时要求输出的数字是正数。

'''


def completion_mistral03():
    api_list = [
        {
            "action": "蓄积量及变化",
            # "action": "XuJiLiang_Change",
            "action_description": "森林资源数量模块, 输入任意地区类型和编号查询对应的蓄积量及变化",
            "args": {
                "dateSign": "二调数据年份，默认值是2019。数据类型为string, 可选参数，若不存在则输出2019。",
                "regionCode": "任意地区对应的编号。数据类型为string, 可选参数，若不存在则返回null。",
                "regionType": "任意地区类型枚举，分别为【伊春森工：sengong，林业局：linyeju，林场：linchang,小班：xiaoban】。数据类型为string, 可选参数，若不存在则不需要解析。",
            }
        },
        {
            "action": "全市面积",
            "action_description": "森林资源数量模块, 输入任意地区类型和编号查询对应的林地面积，森林面积数值",
            "args": {
                "dateSign": "二调数据年份，默认值是2019。数据类型为string, 可选参数，若不存在则输出2019。",
                "regionCode": "任意地区对应的编号。数据类型为string, 可选参数，若不存在则不需要解析。",
                "regionType": "任意地区类型枚举，分别为【伊春森工：sengong，林业局：linyeju，林场：linchang,小班：xiaoban】。数据类型为string, 可选参数，若不存在则不需要解析。",
            }
        },
        {
            "action": "森林覆盖率排行",
            "action_description": "森林资源数量模块, 输入任意地区类型和编号查询对应的森林覆盖率排行",
            "args": {
                "dateSign": "二调数据年份，默认值是2019。数据类型为string, 可选参数，若不存在则输出2019。",
                "regionCode": "任意地区对应的编号。数据类型为string, 可选参数，若不存在则不需要解析。",
                "regionType": "任意地区类型枚举，分别为【伊春森工：sengong，林业局：linyeju，林场：linchang,小班：xiaoban】。数据类型为string, 可选参数，若不存在则不需要解析。",
            }
        },
        {
            "action": "森林植物总生物量",
            "action_description": "森林资源数量模块, 输入任意地区类型和编号查询对应的森林植物总生物量",
            "args": {
                "dateSign": "二调数据年份，默认值是2019。数据类型为string, 可选参数，若不存在则输出2019。",
                "regionCode": "任意地区对应的编号。数据类型为string, 可选参数，若不存在则不需要解析。",
                "regionType": "任意地区类型枚举，分别为【伊春森工：sengong，林业局：linyeju，林场：linchang,小班：xiaoban】。数据类型为string, 可选参数，若不存在则不需要解析。",
            }
        }
    ][1:2]

    from mistral_common.protocol.instruct.tool_calls import Function, Tool
    tools = [
        # Tool(
        #     function=Function(
        #         name="get_current_weather",
        #         description="Get the current weather",
        #         parameters={
        #             "type": "object",
        #             "properties": {
        #                 "location": {
        #                     "type": "string",
        #                     "description": "The city and state, e.g. San Francisco, CA",
        #                 },
        #                 "format": {
        #                     "type": "string",
        #                     "enum": ["celsius", "fahrenheit"],
        #                     "description": "The temperature unit to use. Infer this from the users location.",
        #                 },
        #             },
        #             "required": ["location", "format"],
        #         },
        #     )
        # )
        Tool(
            function=Function(
                name=t['action'],
                description=t['action_description'],
                parameters={
                    "type": "object",
                    "properties": {
                        # "location": {
                        #     "type": "string",
                        #     "description": "The city and state, e.g. San Francisco, CA",
                        # },
                        # "format": {
                        #     "type": "string",
                        #     "enum": ["celsius", "fahrenheit"],
                        #     "description": "The temperature unit to use. Infer this from the users location.",
                        # },
                        p_name: {
                            "type": "string",
                            "enum": ["sengong", "linyeju", "linchang", "xiaoban"],
                            "description": p_desc,
                        } if p_name == 'regionType' else {
                            "type": "string",
                            "description": p_desc,
                        }
                        for p_name, p_desc in t['args'].items()
                    },
                    # "required": ["dateSign", "regionType"],
                    # "required": [],
                },
            )
        )
        for t in api_list
    ]

    tools_str = json.dumps([t.model_dump() for t in tools], ensure_ascii=False)
    print(tools_str)

    # exit(0)

    # query_str = "What is the weather like today in San Francisco"
    # query_str = "我想了解一下伊春市各区域的森林覆盖率情况, You should always choose one from AVAILABLE_TOOLS and output with JSON Format."
    # query_str = "我想了解一下伊春市各区域的森林覆盖率情况"
    # query_str = "请问2019年伊春森工的蓄积量及变化是什么？"
    # query_str = "请问2020年小班的蓄积量变化是多少，并且要求输出为数字，同时要求输出的数字保留两位小数，同时要求输出的数字是正数。"
    query_str = "请问2019年的林业局、林场、小班、伊春森工的森林面积分别是多少？"

    prompt_str = f"""
    [AVAILABLE_TOOLS] {tools_str}[/AVAILABLE_TOOLS][INST] {query_str} [/INST]

    """

    # Building Hybrid Retrieval with Chunk Embedding + Parent Embedding
    from llama_index.llms.openai_like import OpenAILike
    llm = OpenAILike(
        # model='Mistral-7B-Instruct-v0.2',
        # api_base="http://192.168.100.21:8000/v1",

        model='Mistral-7B-Instruct-v0.3',
        api_base="http://192.168.100.21:9000/v1",
        api_key='EMPTY',
        temperature=0.,
        max_tokens=2048,
    )

    response = llm.complete(prompt_str, formatted=True)
    print(response)


if __name__ == '__main__':

    # completion()
    completion_mistral03()
