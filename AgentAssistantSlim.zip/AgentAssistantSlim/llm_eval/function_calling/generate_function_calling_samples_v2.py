from llama_index.core import VectorStoreIndex, SimpleDirectoryReader, Settings
# from llama_index.llms.vllm import Vllm
from llama_index.llms.vllm import VllmServer
from llama_index.llms.openai_like import OpenAILike

from llama_index.core import PromptTemplate
from router.llm_program import CustomLLMTextCompletionProgram
import re
import json


QUERY_GENERATE_TEMPLATE = """
你是一个文本数据合成方面的专家，现在你需要从一个接口描述信息中学习这个接口的具体用途，然后模拟人的提问方式，提出一些使用过程中可能出现的问题。
现在举例：
------------------------
下面是一个处理加法操作的接口信息：
{
    "action": "add", 
    "args": {
        "a": a: int, 
        "b": b: int
     }
}
用户提问：
1. 请问8+3的答案是什么？
2. 1+2等于几？
3. 告诉我100+200的结果？
...
------------------------
举例结束，现在给你如下接口信息：
{ACTION_API}
用户提问：
"""


class GenerateSamples:
    def __init__(self, llm):
        self.llm = llm

    def generate_questions(self, action_api):
        action_str = json.dumps(action_api, indent=4, ensure_ascii=False)
        prompt = QUERY_GENERATE_TEMPLATE.replace("{ACTION_API", action_str)
        print(prompt)
        response = self.llm.complete(prompt)
        print(response)
        questions = [s.split('.')[1].strip() for s in response.text.split('\n')]
        print(questions)
        return questions[0:-1]

    def parse_args(self, query, action_api):
        api_list = [action_api]
        from mistral_common.protocol.instruct.tool_calls import Function, Tool
        tools = [
            Tool(
                function=Function(
                    name=t['action'],
                    description=t['action_description'],
                    parameters={
                        "type": "object",
                        "properties": {
                            p_name: {
                                "type": "string",
                                "enum": ["sengong", "linyeju", "linchang", "xiaoban"],
                                "description": p_desc,
                            } if p_name == 'regionType' else {
                                "type": "string",
                                "description": p_desc,
                            }
                            for p_name, p_desc in t['args'].items()
                        },
                        # "required": ["dateSign", "regionType"],
                        # "required": [],
                    },
                )
            )
            for t in api_list
        ]

        tools_str = json.dumps([t.model_dump() for t in tools], ensure_ascii=False)
        # print(tools_str)

        prompt_str = f"""
            [AVAILABLE_TOOLS] {tools_str}[/AVAILABLE_TOOLS][INST] {query} [/INST]

            """
        response = self.llm.complete(prompt_str, formatted=True)
        # print(response)
        actions = []
        for line in response.text.split('\n'):
            if not ('name' in line and 'arguments' in line):
                continue
            _actions = json.loads(line.strip())

            actions.extend(_actions)
        actions_in_json = {json.dumps(d, sort_keys=True) for d in actions}
        actions = [json.loads(t) for t in actions_in_json]
        return actions


def main():

    llm = OpenAILike(
        model='Mistral-7B-Instruct-v0.3',
        api_base="http://192.168.100.21:9000/v1",
        api_key='EMPTY',
        temperature=0,
        max_tokens=1000,
    )

    api_list = [
        {
            "action": "蓄积量及变化",
            "action_description": "森林资源数量模块, 输入任意地区类型和编号查询对应的蓄积量及变化",
            "args": {
                "dateSign": "二调数据年份，默认值是2019。数据类型为string, 可选参数，若不存在则输出2019。",
                "regionCode": "任意地区对应的编号。数据类型为string, 可选参数，若不存在则返回null。",
                "regionType": "任意地区类型枚举，分别为【伊春森工：sengong，林业局：linyeju，林场：linchang,小班：xiaoban】。数据类型为string, 可选参数，若不存在则不需要解析。",
            }
        },
        {
            "action": "全市面积",
            "action_description": "森林资源数量模块, 输入任意地区类型和编号查询对应的林地面积，森林面积数值",
            "args": {
                "dateSign": "二调数据年份，默认值是2019。数据类型为string, 可选参数，若不存在则输出2019。",
                "regionCode": "任意地区对应的编号。数据类型为string, 可选参数，若不存在则不需要解析。",
                "regionType": "任意地区类型枚举，分别为【伊春森工：sengong，林业局：linyeju，林场：linchang,小班：xiaoban】。数据类型为string, 可选参数，若不存在则不需要解析。",
            }
        },
        {
            "action": "森林覆盖率排行",
            "action_description": "森林资源数量模块, 输入任意地区类型和编号查询对应的森林覆盖率排行",
            "args": {
                "dateSign": "二调数据年份，默认值是2019。数据类型为string, 可选参数，若不存在则输出2019。",
                "regionCode": "任意地区对应的编号。数据类型为string, 可选参数，若不存在则不需要解析。",
                "regionType": "任意地区类型枚举，分别为【伊春森工：sengong，林业局：linyeju，林场：linchang,小班：xiaoban】。数据类型为string, 可选参数，若不存在则不需要解析。",
            }
        },
        {
            "action": "森林植物总生物量",
            "action_description": "森林资源数量模块, 输入任意地区类型和编号查询对应的森林植物总生物量",
            "args": {
                "dateSign": "二调数据年份，默认值是2019。数据类型为string, 可选参数，若不存在则输出2019。",
                "regionCode": "任意地区对应的编号。数据类型为string, 可选参数，若不存在则不需要解析。",
                "regionType": "任意地区类型枚举，分别为【伊春森工：sengong，林业局：linyeju，林场：linchang,小班：xiaoban】。数据类型为string, 可选参数，若不存在则不需要解析。",
            }
        }
    ]

    '''
    {
        "action": "蓄积量及变化", 
        "action_description": 森林资源数量模块, 输入任意地区类型和编号查询对应的蓄积量及变化, 
        "args": {
            "dateSign": 二调数据年份，默认值是2019。数据类型为string, 可选参数，若不存在则输出2019。
            "regionCode": 任意地区对应的编号。数据类型为string, 可选参数，若不存在则返回null。
            "regionType": 任意地区类型枚举，分别为【伊春森工：sengong，林业局：linyeju，林场：linchang,小班：xiaoban】。数据类型为string, 可选参数，若不存在则不需要解析。
        }
    }
    '''

    gen_tool = GenerateSamples(llm=llm)
    gen_results = []
    for api in api_list:
        questions = gen_tool.generate_questions(action_api=api)[0:20]
        # questions = ["请问2019年伊春森工的蓄积量是多少？"]
        for i, q in enumerate(questions):
            print(f'--------------- {i} ---------------')
            actions = gen_tool.parse_args(query=q, action_api=api)
            print(f'QEURY: {q}')
            print(f'ANSWER: {actions}')
            gen_results.append(dict(query=q, answer=actions))

    ############### write to csv file ##############
    import pandas as pd
    df = pd.DataFrame(
        {
            'query': [r['query'] for r in gen_results],
            'answer': [r['answer'] for r in gen_results],
        }
    )
    df.to_csv('function_calling_samples_v2.csv', index=False)


    # from llama_index.core.llms import ChatMessage, MessageRole, ChatResponse
    # message = [
    #     ChatMessage(role=MessageRole.SYSTEM,
    #                 content="You are a helpful assistant. can answer all questions from human."),
    #     ChatMessage(role=MessageRole.USER, content="麻婆豆腐的制作方法？"),
    #     # ChatMessage(role=MessageRole.USER, content="Hello"),
    #     #     ChatMessage(role=MessageRole.TOOL, content="""
    #     #     麻婆豆腐
    #     #
    #     # 先將碎豬肉用醃料醃10分鐘
    #     # 豆腐切粒
    #     # 下油爆香蒜加入碎豬肉炒香
    #     # 再加入豆辦醬、糖及鹽炒香
    #     # 加入水及豆腐煮2-3分鐘
    #     # 最後加入麻油，再用生粉水煮到醬汁杰身即可""")
    # ]
    # response = llm.chat(message)
    #
    # print(response.message)




if __name__ == '__main__':

    main()

