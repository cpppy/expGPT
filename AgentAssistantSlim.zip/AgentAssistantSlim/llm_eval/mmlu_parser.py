
from router_agent.custom_qp import CustomQueryPipeline as QueryPipeline
from llama_index.core.bridge.pydantic import Field, BaseModel
from llama_index.core import PromptTemplate

from router.parser import CustomPydanticOutputParser

from loguru import logger


class Answer(BaseModel):
    """Evaluation of whether the response has an error."""

    has_error: bool = Field(
        ..., description="Whether the response has an error."
    )
    selection: str = Field(
        ..., description="which selection you should choose? it must be one of ['A', 'B', 'C', 'D').")
    explanation: str = Field(
        ...,
        description=(
            "The explanation for the error as well as for the selection you choose."
            "Can include the direct stack trace as well."
        ),
    )


class MMLUParser:

    def __init__(self, llm, prompt_str):
        self.llm = llm
        self.prompt_str = prompt_str
        self.qp = self.build_pipeline()



    def build_pipeline(self):
        ### add output parser
        TEMPLATE = """
           Here's a JSON schema to follow:
           {schema}
    
           Output a valid JSON object but do not repeat the schema.
           """

        # 'Just output only one schema.'

        output_parser = CustomPydanticOutputParser(output_cls=Answer,
                                                   pydantic_format_tmpl=TEMPLATE)

        # ## query template
        # json_prompt_str = """
        #        analyse the request content and give suggestion of the next step about this topic.
        #        there are several choices of the next step: \n
        #        1. RAG: 如果客户是在询问一些问题，该问题关系到黄河或者水文站的工作安排、记录，或者相关机构下发的通知内容。以及关于伊春的林业生态规划。请选择此接口。\n
        #        2. BackendSearch: 如果客户的请求内容是查询一些信息，比如：森林的蓄积量及变化、城市面积、森林覆盖率排行、森林植物总生物量等，请选择此接口。\n
        #        3. WebSearch: 如果客户请求的内容无法通过前面RAG或者Backend提供的功能解决，同时你认为通过互联网可以查询相关信息完成回答的时候，请选择此接口。\n
        #
        #        you should select only one from the choices above.
        #        \n Now, the request content is: {request}.
        #        \n Output with the following JSON format:
        #    """

        # json_prompt_str = """
        #            analyse the request content and give suggestion of the next step about this topic.
        #            there are several choices of the next step: \n
        #            1. RAG: 如果用户是在询问问题，该问题关系到黄河或者水文站的工作安排、记录或通知内容, 以及关于伊春的林业生态规划。请选择此接口。\n
        #            2. BackendSearch: 如果用户的请求内容是查询一些信息，比如：森林的蓄积量及变化、城市面积、森林覆盖率排行、森林植物总生物量等，请选择此接口。\n
        #            3. WebSearch: 如果客户请求的内容无法通过前面RAG或者Backend提供的功能解决，同时你认为通过互联网可以查询相关信息完成回答的时候，请选择此接口。\n
        #
        #            you should select only one from the choices above.
        #            \n Now, the request content is: {request}.
        #            \n Output with the following JSON format:
        #            """
        json_prompt_str = output_parser.format(self.prompt_str)
        json_prompt_tmpl = PromptTemplate(json_prompt_str)
        logger.info(f'[PROMPT TEMPLATE] {json_prompt_tmpl}')
        qp_cls = QueryPipeline(chain=[json_prompt_tmpl, self.llm, output_parser])
        # qp_router = QueryPipeline(chain=[router_c, qp_cls])
        # output = qp_router.run("which kind of fruit is benefit for human's hair ?")
        # print('----------------- final output --------------------')
        # print(output)
        return qp_cls

    def __call__(self, inputs):
        assert isinstance(inputs, dict)
        cls_response = self.qp.run_component(**inputs)
        logger.info(f'cls_response: {cls_response}')
        return cls_response['output']

