from llama_index.llms.openai_like import OpenAILike
import logging


def main():

    # https://docs.llamaindex.ai/en/stable/examples/llm/vllm/
    llm = OpenAILike(
        # model="Qwen1.5-0.5B-Chat",
        # api_base="http://192.168.150.181:8000/v1",
        # model='Mistral-7B-Instruct-v0.2',
        # api_base="http://192.168.100.21:8000/v1",
        # api_key='EMPTY',

        # model="mock-gpt-model",
        model="gpt-1337-turbo-pro-max",
        api_base="http://localhost:8001",
        # api_base="http://47.237.0.195:8001",
        api_key="fake-api-key",

        # model='Mistral-7B-Instruct-v0.3',
        # api_base="http://192.168.100.21:9000/v1",
        # api_key='EMPTY',


        temperature=0.7,
        max_tokens=1000,
        is_chat_model=True
    )
    # llm.is_chat_model = True

    # response = llm.complete(prompt='what is query engine ?')
    # print(f'response: {response}')

    from llama_index.core.llms import ChatMessage, MessageRole, ChatResponse
    message = [
        ChatMessage(role=MessageRole.SYSTEM,
                    content="You are a helpful assistant. can answer all questions from human."),
        ChatMessage(role=MessageRole.USER, content="麻婆豆腐的制作方法？"),
    ]

    response = llm.chat(message)
    # print(response.message)
    print(response.raw)



def llamaindex_openai_api_test():

    from llama_index.llms.openai import OpenAI
    from llm_backend.qwen2.qwen2_system_prompt import messages_to_prompt, completion_to_prompt
    llm = OpenAI(
        # model="Qwen1.5-0.5B-Chat",
        # api_base="http://192.168.150.181:8000/v1",
        # model='Mistral-7B-Instruct-v0.2',
        # api_base="http://192.168.100.21:8000/v1",
        # api_key='EMPTY',

        model="gpt-4",
        # model="gpt-1337-turbo-pro-max",
        api_base="http://localhost:8001",
        # api_base="http://47.237.0.195:8001",
        api_key="fake-api-key",

        # model='Mistral-7B-Instruct-v0.3',
        # api_base="http://192.168.100.21:9000/v1",
        # api_key='EMPTY',


        temperature=0.7,
        max_tokens=1000,

        # messages_to_prompt=messages_to_prompt,
        # completion_to_prompt=completion_to_prompt,
    )

    # response = llm.complete(prompt='what is query engine ?')
    # print(f'response: {response}')

    from llama_index.core.llms import ChatMessage, MessageRole, ChatResponse
    message = [
        ChatMessage(role=MessageRole.SYSTEM,
                    content="You are a helpful assistant. can answer all questions from human."),
        ChatMessage(role=MessageRole.USER, content="麻婆豆腐的制作方法？"),
    ]

    response = llm.chat(message)
    # print(response.message)
    print(response.raw)




def openai_api_test():
    from openai import OpenAI

    # init client and connect to localhost server
    client = OpenAI(
        api_key="fake-api-key",
        base_url="http://localhost:8001"  # change the default port if needed
    )

    # call API
    chat_completion = client.chat.completions.create(
        messages=[
            {
                "role": "user",
                "content": "how to make a cake?",
            }
        ],
        model="gpt-1337-turbo-pro-max",
    )

    # print the top "choice"
    print(chat_completion.choices[0].message.content)

if __name__=='__main__':

    logging.basicConfig(level=logging.DEBUG)

    # main()
    # llamaindex_openai_api_test()
    openai_api_test()

