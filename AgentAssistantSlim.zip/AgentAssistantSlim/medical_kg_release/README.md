

### step1: parse triplets from chunks
python parse_medical_triplets.py

### step2: insert triplets to neo4j
set main_func to add_data_to_neo4j    
python query_kg_custom.py

### step3: query_from_kg
set main_func to main    
python query_kg_custom.py


















