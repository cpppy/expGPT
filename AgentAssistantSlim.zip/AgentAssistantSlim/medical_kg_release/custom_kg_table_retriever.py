from llama_index.core.indices.knowledge_graph.retrievers import (
    KGRetrieverMode,
    KGTableRetriever,
    QueryBundle,
    NodeWithScore,
    print_text,
    GLOBAL_EXPLORE_NODE_LIMIT,
    defaultdict,
    get_top_k_embeddings,
    DEFAULT_NODE_SCORE,
    TextNode,
    truncate_text,
    MetadataMode,
)

from llama_index.core.indices.keyword_table.utils import (
    extract_keywords_given_response,
)

from typing import Any, Callable, Dict, List, Optional, Set, Tuple
import re
import json

import logging

logger = logging.getLogger(__name__)

MEDICAL_QUERY_EXTRACT_KEYWORDS_TEMPLATE = '''
下面给你的内容是关于一个知识图谱的实体定义以及实体直接关系的定义。
    实体定义：
        "疾病"
            定义：由于多种原因引起的机体功能和结构失调，表现为特定的症状和体征。疾病可分为急性和慢性，可能影响一个或多个系统。
            例如：感冒、糖尿病、高血压、冠心病

        "别名"
            定义：疾病的其他名称或俗称，便于不同地区、文化或专业领域进行识别。
            例如：高血压的别名是“血压高”，糖尿病的别名是“甜尿病”

        "症状"
            定义：患者因疾病或损伤表现出的异常感觉或体征，包括主观症状（如疼痛）和客观症状（如发热）。
            例如：疲劳、咳嗽、眩晕、呕吐、疼痛、呼吸困难

        "发病部位"
            定义：疾病主要影响的身体部位或器官，一定是人体的身体部位或器官。
            例如：心脏、肺、肝脏、肾脏

        "所属科室"
            定义：负责特定疾病诊疗的医院科室。
            例如：内科、外科、皮肤科、骨科

        "疗法"
            定义：用于治疗疾病的具体方法，包括药物治疗、手术、物理治疗、心理治疗等，旨在缓解症状、治疗疾病或改善健康状况。
            例如：抗生素治疗、物理治疗、认知行为疗法、手术

        "风险因素"
            定义：增加患某种疾病可能性的因素，包括生活习惯、遗传因素和生理条件。
            子类：
                生活习惯：抽烟、饮酒、久坐
                遗传因素：家族病史
                生理条件：高血压、高血糖
            例如：抽烟、饮酒、肥胖、遗传病史

        "生理指标"
            定义：通过常规检查获得的数值，用于监测和评估健康状况。
            例如：心率、血压、血糖水平、血氧饱和度、体温

        "病原体"
            定义：引发疾病的微生物或其他有害生物，能够通过不同途径传播并引起感染。
            例如：细菌、病毒、真菌、寄生虫

        "并发症"
            定义：由原发疾病引起的其他健康问题，使病情复杂化并影响治疗效果。
            例如：糖尿病并发视网膜病变，高血压并发肾脏病

    关系描述：
        "别名是"
            定义：两个疾病实体之间的关系，表示它们是同一种疾病的不同名称。
            可能构成的三元组关系举例：
                (感冒, 别名是, 上呼吸道感染)
                (高血压, 别名是, 血压高)

        "症状是"
            定义：疾病与其临床表现之间的关系，有助于诊断和患者自我监测。
            可能构成的三元组关系举例：
                (流感, 症状是, 发热)
                (高血压, 症状是, 头痛)

        "发病部位是"
            定义：疾病与其主要影响的部位或器官之间的关系，发病部位一定是人体的身体部位或器官。
            可能构成的三元组关系举例：
                (肺炎, 发病部位是, 肺)
                (肝硬化, 发病部位是, 肝脏)

        "所属科室是"
            定义：疾病与负责其诊疗的医院科室之间的关系。
            可能构成的三元组关系举例：
                (糖尿病, 所属科室是, 内分泌科)
                (皮肤过敏, 所属科室是, 皮肤科)

        "引发"
            可能构成的三元组关系举例：
                1. 风险因素与其可能导致的疾病之间的关系，有助于健康管理和疾病预防。
                2. 病原体与其引发的疾病之间的因果关系，有助于疾病预防和针对性治疗。
                3. 生理指标与其反映或影响的疾病之间的关系，有助于监测和评估治疗效果。
            请注意"引发"的对象一般为"疾病"类型的实体。
            可能构成的三元组关系举例：
                (抽烟, 引发, 肺癌)
                (高糖饮食, 引发, 糖尿病)
                (流感病毒, 引发, 流感)
                (幽门螺杆菌, 引发, 胃溃疡)
                (高血压, 引发, 心脏病)
                (高血糖, 引发, 糖尿病)

        "伴随"
            定义：两个常同时发生或相互关联的疾病之间的关系。
            可能构成的三元组关系举例：
                (高血压, 伴随, 心脏病)
                (哮喘, 伴随, 过敏性鼻炎)

        "治疗"
            定义：疗法与其用于治疗的疾病之间的关系，有助于制定个性化治疗方案。
            可能构成的三元组关系举例：
                (物理治疗, 治疗, 腰痛)
                (抗生素, 治疗, 细菌感染)
                (三九感冒颗粒, 治疗, 感冒)

        "并发"
            定义：一个疾病可能导致的并发症之间的关系，有助于全面评估和管理病情。
            可能构成的三元组关系举例：
                (糖尿病, 并发, 视网膜病变)
                (高血压, 并发, 心脏病)

        "改善"
            定义：疗法与其可能改善的症状之间的关系，有助于评估治疗的有效性和选择适当的治疗方案。
            可能构成的三元组关系举例：
                (消炎药, 改善, 发热)
                (止痛药, 改善, 疼痛)

        "诊断"
            定义：检测方法与其用于诊断的疾病之间的关系，有助于早期发现和准确诊断疾病。
            可能构成的三元组关系举例：
                (血液检查, 诊断, 贫血)
                (核磁共振检查, 诊断, 脑瘤) 

对于各种实体和关系的描述结束，现在给你一段文本<TEXT>：
${raw_text}

请按照一下步骤执行分析任务：
    Step1. 按照上面的实体和关系的描述，请先提取其中的实体，实体的类别必须存在于下面的列表中：
        ["疾病", "别名", "症状", "发病部位", "所属科室", "疗法", "风险因素", "生理指标", "病原体", "并发症"]

    Step2. 请结合知识图谱对于关系的定义，以及上一部获得的实体信息，文本中可能存在的关系。
        关系(predicate) 必须存在于下面的列表中：
            ["别名是", "症状是", "发病部位是", "所属科室是", "引发", "伴随", "治疗", "并发", "改善", "诊断"]

    Step3. 将提取到的 实体或者关系 按照JSON格式输出，JSON格式的构成可以模型下面的例子。
        如果实体对应的关系不存在，则关系(predicate)一项为""。
        JSON格式输出举例如下：
        ```json
        [
            {
                "entity_name": "感冒",
                "entity_type": "疾病",
                "predicate": "症状是",
            },
            {
                "entity_name": "感冒",
                "entity_type": "疾病",
                "predicate": "",
            }
        ]
        ```

请按照JSON格式准确输出这些结果。输出结果请不要重复。
'''


class CustomKGTableRetriever(KGTableRetriever):

    def _get_keywords(self, query_str: str) -> List[str]:
        """Extract keywords."""
        # response = self._llm.predict(
        #     self.query_keyword_extract_template,
        #     max_keywords=self.max_keywords_per_query,
        #     question=query_str,
        # )
        query = MEDICAL_QUERY_EXTRACT_KEYWORDS_TEMPLATE.replace('${raw_text}', query_str)

        from llama_index.core.llms import ChatMessage, MessageRole, ChatResponse
        message = [
            ChatMessage(role=MessageRole.SYSTEM,
                        content="你是一个医学知识图谱专家，你很善于根据知识图谱的三元组设计从文本中提取对应的实体和关系信息。"),
            ChatMessage(role=MessageRole.USER, content=query),
        ]

        response = self._llm.chat(message)
        # response_str = response.message.content
        # print(f'TEXT: {text}')
        # logger.debug(f'===============================')
        # print(f'RAW TEXT:\n{text}\n')
        logger.debug(f'RESPONSE:\n{response.message.content}\n')
        pattern = r'```json(.*?)```'
        match = re.search(pattern, response.message.content, re.DOTALL | re.MULTILINE | re.I)
        logger.debug(f'match: {match}')
        try:
            entities = json.loads(match.group(1).strip())
            logger.debug(f'TRIPLETS:\n {entities}')
            logger.debug(json.dumps(entities, indent=4, ensure_ascii=False))
        except Exception as e:
            logger.error(e)
            entities = []

        keywords = [x['entity_name'] for x in entities]

        # exit(0)
        # logger.debug(f'[RESPONSE] {response}')
        # keywords = extract_keywords_given_response(
        #     response, start_token="KEYWORDS:", lowercase=False
        # )
        return list(keywords)

    def _extract_rel_text_keywords(self, rel_texts: List[str]) -> List[str]:
        """Find the keywords for given rel text triplets."""
        keywords = []

        for rel_text in rel_texts:
            splited_texts = rel_text.split(",")

            if len(splited_texts) <= 0:
                continue
            keyword = splited_texts[0]
            if keyword:
                keywords.append(keyword.strip("(\"'"))

            # Return the Object as well
            if len(splited_texts) <= 2:
                continue
            keyword = splited_texts[2]
            if keyword:
                keywords.append(keyword.strip(" ()\"'"))
        return keywords

    def _retrieve(
            self,
            query_bundle: QueryBundle,
    ) -> List[NodeWithScore]:
        """Get nodes for response."""
        node_visited = set()
        keywords = self._get_keywords(query_bundle.query_str)

        # TODO: use entity and predicate list as fuzzy matching targets, the search the neo4j by more exact conditions.

        if self._verbose:
            print_text(f"Extracted keywords: {keywords}\n", color="green")
        rel_texts = []
        cur_rel_map = {}
        chunk_indices_count: Dict[str, int] = defaultdict(int)

        search_result = []
        # ------------------- hybrid search --------------------
        GLOBAL_EXPLORE_NODE_LIMIT = 5
        for keyword in keywords:
            subjs = {keyword}
            ### search nodes by keyword in query string. ###
            node_ids = self._index_struct.search_node_by_keyword(keyword)
            logger.debug(f'query_keyword: {keyword}, node_ids: {node_ids}')
            for node_id in node_ids[:GLOBAL_EXPLORE_NODE_LIMIT]:
                if node_id in node_visited:
                    continue

                if self._include_text:
                    chunk_indices_count[node_id] += 1

                node_visited.add(node_id)
                if self.use_global_node_triplets:  # default=False
                    # Get nodes from keyword search, and add them to the subjs
                    # set. This helps introduce more global knowledge into the
                    # query. While it's more expensive, thus to be turned off
                    # by default, it can be useful for some applications.

                    # TODO: we should a keyword-node_id map in IndexStruct, so that
                    # node-keywords extraction with LLM will be called only once
                    # during indexing.
                    extended_subjs = self._get_keywords(
                        self._docstore.get_node(node_id).get_content(
                            metadata_mode=MetadataMode.LLM
                        )
                    )
                    subjs.update(extended_subjs)

            ### search triplets from kg ###
            rel_map = self._graph_store.get_rel_map(
                list(subjs), self.graph_store_query_depth
            )

            if not rel_map:
                continue
            # _rel_texts = [
            #         str(rel_obj)
            #         for rel_objs in rel_map.values()
            #         for rel_obj in rel_objs
            #     ]
            _rel_texts = [
                str(tuple([key] + rel_obj))
                for key, rel_objs in rel_map.items()
                for rel_obj in rel_objs
            ]

            rel_texts.extend(_rel_texts)
            cur_rel_map.update(rel_map)

            logger.debug(f"rel_map from kg: {rel_map}")
            logger.debug(f"rel_texts from kg: {_rel_texts}")

        node_texts = '\n'.join([f'-- NodeID: {node_id}\n    Chunk: {repr(self._docstore.get_node(node_id).text)}'
                                for node_id in node_visited])
        print_text(f"Chunks_RelatedTo_QueryKeywords: {keywords}\n {node_texts}\n", color="gray")

        search_result.append(dict(
            data_source='query_keywords_and_chunks',
            key_names=('query_keywords', 'nodes_related_to_query_keywords'),
            query_keywords=keywords,
            nodes_related_to_query_keywords=[self._docstore.get_node(node_id) for node_id in node_visited]
        ))

        ### search triplet_str by embedding similarity ###
        if (
                self._retriever_mode != KGRetrieverMode.KEYWORD
                and len(self._index_struct.embedding_dict) > 0
        ):
            query_embedding = self._embed_model.get_text_embedding(
                query_bundle.query_str
            )
            all_rel_texts = list(self._index_struct.embedding_dict.keys())
            logger.debug(f'all_rel_texts: {all_rel_texts}')
            # exit(0)

            rel_text_embeddings = [
                self._index_struct.embedding_dict[_id] for _id in all_rel_texts
            ]
            similarities, top_rel_texts = get_top_k_embeddings(
                query_embedding,
                rel_text_embeddings,
                similarity_top_k=self.similarity_top_k,
                embedding_ids=all_rel_texts,
            )
            logger.debug(
                f"Found the following rel_texts+query similarites: {similarities!s}"
            )

            topk_triplet_str = '\n'.join(
                [f'-- Similarity: {score}, Triplet_str: {triplet_str}' for score, triplet_str in
                 zip(similarities, top_rel_texts)])
            print_text(f"TripletStr_Matched(Embedding)_Query: {query_bundle.query_str}\n{topk_triplet_str}\n",
                       color="gray")

            # logger.debug(f"Found the following top_k rel_texts: {rel_texts!s}")
            rel_texts.extend(top_rel_texts)

            search_result.append(dict(
                data_source='triplet_str_by_embedding_with_query',
                key_names=('similarity_and_triplet_str',),
                similarity_and_triplet_str=[
                    dict(score=score, triplet_str=triplet_str)
                    for score, triplet_str in zip(similarities, top_rel_texts)
                ],
            ))

        elif len(self._index_struct.embedding_dict) == 0:
            logger.warning(
                "Index was not constructed with embeddings, skipping embedding usage..."
            )

        # remove any duplicates from keyword + embedding queries
        if self._retriever_mode == KGRetrieverMode.HYBRID:
            rel_texts = list(set(rel_texts))

            # remove shorter rel_texts that are substrings of longer rel_texts
            rel_texts.sort(key=len, reverse=True)
            for i in range(len(rel_texts)):
                for j in range(i + 1, len(rel_texts)):
                    if rel_texts[i] == "" or rel_texts[j] == "":
                        continue
                    if rel_texts[j][1:-1] in rel_texts[i][1:-1]:
                        rel_texts[j] = ""
            rel_texts = [rel_text for rel_text in rel_texts if rel_text != ""]
            rel_texts_str = "\n".join(rel_texts)
            logger.debug(f'rel_texts (before truncated): \n{rel_texts_str}')

            # truncate rel_texts
            rel_texts = rel_texts[: 10]
            rel_texts_str = "\n".join(rel_texts)
            logger.debug(f'rel_texts (after truncated): \n{rel_texts_str}')

        # When include_text = True just get the actual content of all the nodes
        # (Nodes with actual keyword match, Nodes which are found from the depth search and Nodes founnd from top_k similarity)
        if self._include_text:
            keywords = self._extract_rel_text_keywords(
                rel_texts
            )  # rel_texts will have all the Triplets retrieved with respect to the Query
            logger.debug(f'keywords_from_all_rel_texts: {keywords}')
            nested_node_ids = [
                self._index_struct.search_node_by_keyword(keyword)
                for keyword in keywords
            ]
            node_ids = [_id for ids in nested_node_ids for _id in ids]
            logger.debug(f'node_ids for chunk_indices_count: {node_ids}')
            for node_id in node_ids:
                chunk_indices_count[node_id] += 1

        sorted_chunk_indices = sorted(
            chunk_indices_count.keys(),
            key=lambda x: chunk_indices_count[x],
            reverse=True,
        )
        sorted_chunk_indices = sorted_chunk_indices[: self.num_chunks_per_query]
        sorted_nodes = self._docstore.get_nodes(sorted_chunk_indices)

        # TMP/TODO: also filter rel_texts as nodes until we figure out better
        # abstraction
        # TODO(suo): figure out what this does
        # rel_text_nodes = [Node(text=rel_text) for rel_text in rel_texts]
        # for node_processor in self._node_postprocessors:
        #     rel_text_nodes = node_processor.postprocess_nodes(rel_text_nodes)
        # rel_texts = [node.get_content() for node in rel_text_nodes]

        sorted_nodes_with_scores = []
        for chunk_idx, node in zip(sorted_chunk_indices, sorted_nodes):
            # nodes are found with keyword mapping, give high conf to avoid cutoff
            sorted_nodes_with_scores.append(
                NodeWithScore(node=node, score=DEFAULT_NODE_SCORE)
            )
            logger.debug(f'NODE: {node.node_id}, {node.text}')
            logger.debug(
                f"> Querying with idx: {chunk_idx}: "
                f"{truncate_text(node.get_content(), 80)}"
            )

        node_texts = '\n'.join([f'-- NodeID: {node.node_id}\n    Chunk: {repr(node.text)}'
                                for node in sorted_nodes])
        print_text(f"Chunks_RelatedTo_KeywordsInTriplets: {list(set(keywords))}\n {node_texts}\n", color="gray")

        search_result.append(dict(
            data_source='nodes_related_to_keys_from_triplets',
            key_names=('nodes_related_to_triplet_keys',),
            nodes_related_to_triplet_keys=sorted_nodes,
        ))

        # if no relationship is found, return the nodes found by keywords
        if not rel_texts:
            logger.info("> No relationships found, returning nodes found by keywords.")
            if len(sorted_nodes_with_scores) == 0:
                logger.info("> No nodes found by keywords, returning empty response.")
                return [
                    NodeWithScore(
                        node=TextNode(text="No relationship founded."), score=1.0
                    )
                ]
            # In else case the sorted_nodes_with_scores is not empty
            # thus returning the nodes found by keywords
            return sorted_nodes_with_scores

        # print chunk w triplet
        triplet_node_pairs = []
        for rel_text in rel_texts:
            chain = rel_text[2:-2].split("', '")
            node_ids = []
            for i in range(len(chain) // 2):
                triplet = tuple(chain[i * 2: i * 2 + 3])
                _node_ids = self._index_struct.search_node_by_keyword(str(triplet))

                logger.debug(f'triplet_str: {str(triplet)}, _node_ids: {_node_ids}')
                node_ids.extend(_node_ids)
            node_ids = list(set(node_ids))
            _nodes = self._docstore.get_nodes(node_ids)
            print_text(f'TripletChain: {rel_text}\n', color='green')
            node_texts = '\n'.join([f'-- NodeID: {node.node_id}\n    Chunk: {repr(node.text)}'
                                    for node in _nodes])
            print_text(f'{node_texts}\n', color='gray')
            triplet_node_pairs.append(dict(
                chain_str=rel_text,
                chain=chain,
                nodes=_nodes
            ))
        search_result.append(dict(
            data_source='triplet_and_chunks_related',
            key_names=('triplet_node_pairs',),
            triplet_node_pairs=triplet_node_pairs,
        ))

        # ===================== Build Output TextNode ===================
        # add relationships as Node
        # TODO: make initial text customizable
        rel_initial_text = (
            f"The following are knowledge sequence in max depth"
            f" {self.graph_store_query_depth} "
            f"in the form of directed graph like:\n"
            f"`subject -[predicate]->, object, <-[predicate_next_hop]-,"
            f" object_next_hop ...`"
        )
        rel_info = [rel_initial_text, *rel_texts]
        rel_node_info = {
            "kg_rel_texts": rel_texts,
            "kg_rel_map": cur_rel_map,
        }
        if self._graph_schema != "":
            rel_node_info["kg_schema"] = {"schema": self._graph_schema}
        rel_info_text = "\n".join(
            [
                str(item)
                for sublist in rel_info
                for item in (sublist if isinstance(sublist, list) else [sublist])
            ]
        )

        if self._verbose:
            print_text(f"KG context:\n{rel_info_text}\n", color="blue")
        rel_text_node = TextNode(
            text=rel_info_text,
            metadata=rel_node_info,
            excluded_embed_metadata_keys=["kg_rel_map", "kg_rel_texts"],
            excluded_llm_metadata_keys=["kg_rel_map", "kg_rel_texts"],
        )
        # this node is constructed from rel_texts, give high confidence to avoid cutoff
        sorted_nodes_with_scores.append(
            NodeWithScore(node=rel_text_node, score=DEFAULT_NODE_SCORE)
        )

        # return sorted_nodes_with_scores
        # =============================================================

        logger.debug(f'====================== llamaindex kg output =====================')
        logger.debug(f'n_data_source: {len(search_result)}')
        result_nodes = []
        for r in search_result:
            # print(r)
            if r['data_source'] == 'query_keywords_and_chunks':
                result_nodes.extend(r['nodes_related_to_query_keywords'])
            if r['data_source'] == 'triplet_str_by_embedding_with_query':
                for tr in r['similarity_and_triplet_str']:
                    result_nodes.append(
                        TextNode(
                            text=tr['triplet_str'],
                        ))
            if r['data_source'] == 'nodes_related_to_keys_from_triplets':
                result_nodes.extend(r['nodes_related_to_triplet_keys'])
            if r['data_source'] == 'triplet_and_chunks_related':
                for pair in r['triplet_node_pairs']:
                    result_nodes.append(
                        TextNode(
                            text=pair['chain_str'],
                        ))
                    result_nodes.extend(pair['nodes'])

        unique_node_ids = []
        unique_nodes = []
        for n in result_nodes:
            if n.id_ not in unique_node_ids:
                unique_node_ids.append(n.id_)
                unique_nodes.append(n)
            else:
                continue
        result_nodes = unique_nodes

        # print(f'n_nodes: {len(result_nodes)}')
        # for i, node in enumerate(result_nodes):
        #     print(f'{i}, {node.id_}, {repr(node.text)}')

        return [
            NodeWithScore(node=n, score=DEFAULT_NODE_SCORE)
            for n in result_nodes
        ]


"""
        if self._retriever_mode != KGRetrieverMode.EMBEDDING:
            for keyword in keywords:
                subjs = {keyword}
                node_ids = self._index_struct.search_node_by_keyword(keyword)
                logger.debug(f'query_keyword: {keyword}, node_ids: {node_ids}')
                for node_id in node_ids[:GLOBAL_EXPLORE_NODE_LIMIT]:
                    if node_id in node_visited:
                        continue

                    if self._include_text:
                        chunk_indices_count[node_id] += 1

                    node_visited.add(node_id)
                    if self.use_global_node_triplets:
                        # Get nodes from keyword search, and add them to the subjs
                        # set. This helps introduce more global knowledge into the
                        # query. While it's more expensive, thus to be turned off
                        # by default, it can be useful for some applications.

                        # TODO: we should a keyword-node_id map in IndexStruct, so that
                        # node-keywords extraction with LLM will be called only once
                        # during indexing.
                        extended_subjs = self._get_keywords(
                            self._docstore.get_node(node_id).get_content(
                                metadata_mode=MetadataMode.LLM
                            )
                        )
                        subjs.update(extended_subjs)

                rel_map = self._graph_store.get_rel_map(
                    list(subjs), self.graph_store_query_depth
                )

                logger.debug(f"rel_map from kg: {rel_map}")

                if not rel_map:
                    continue
                rel_texts.extend(
                    [
                        str(rel_obj)
                        for rel_objs in rel_map.values()
                        for rel_obj in rel_objs
                    ]
                )
                cur_rel_map.update(rel_map)
        logger.debug(f'len_embedding_dict: {len(self._index_struct.embedding_dict)}')
        if (
                self._retriever_mode != KGRetrieverMode.KEYWORD
                and len(self._index_struct.embedding_dict) > 0
        ):
            query_embedding = self._embed_model.get_text_embedding(
                query_bundle.query_str
            )
            all_rel_texts = list(self._index_struct.embedding_dict.keys())
            logger.debug(f'all_rel_texts: {all_rel_texts}')
            # exit(0)

            rel_text_embeddings = [
                self._index_struct.embedding_dict[_id] for _id in all_rel_texts
            ]
            similarities, top_rel_texts = get_top_k_embeddings(
                query_embedding,
                rel_text_embeddings,
                similarity_top_k=self.similarity_top_k,
                embedding_ids=all_rel_texts,
            )
            logger.debug(
                f"Found the following rel_texts+query similarites: {similarities!s}"
            )
            logger.debug(f"Found the following top_k rel_texts: {rel_texts!s}")
            rel_texts.extend(top_rel_texts)

        elif len(self._index_struct.embedding_dict) == 0:
            logger.warning(
                "Index was not constructed with embeddings, skipping embedding usage..."
            )

        # remove any duplicates from keyword + embedding queries
        if self._retriever_mode == KGRetrieverMode.HYBRID:
            rel_texts = list(set(rel_texts))

            # remove shorter rel_texts that are substrings of longer rel_texts
            rel_texts.sort(key=len, reverse=True)
            for i in range(len(rel_texts)):
                for j in range(i + 1, len(rel_texts)):
                    if rel_texts[j] in rel_texts[i]:
                        rel_texts[j] = ""
            rel_texts = [rel_text for rel_text in rel_texts if rel_text != ""]

            # truncate rel_texts
            rel_texts = rel_texts[: self.max_knowledge_sequence]

        # When include_text = True just get the actual content of all the nodes
        # (Nodes with actual keyword match, Nodes which are found from the depth search and Nodes founnd from top_k similarity)
        if self._include_text:
            keywords = self._extract_rel_text_keywords(
                rel_texts
            )  # rel_texts will have all the Triplets retrieved with respect to the Query
            nested_node_ids = [
                self._index_struct.search_node_by_keyword(keyword)
                for keyword in keywords
            ]
            node_ids = [_id for ids in nested_node_ids for _id in ids]
            for node_id in node_ids:
                chunk_indices_count[node_id] += 1

        sorted_chunk_indices = sorted(
            chunk_indices_count.keys(),
            key=lambda x: chunk_indices_count[x],
            reverse=True,
        )
        sorted_chunk_indices = sorted_chunk_indices[: self.num_chunks_per_query]
        sorted_nodes = self._docstore.get_nodes(sorted_chunk_indices)

        # TMP/TODO: also filter rel_texts as nodes until we figure out better
        # abstraction
        # TODO(suo): figure out what this does
        # rel_text_nodes = [Node(text=rel_text) for rel_text in rel_texts]
        # for node_processor in self._node_postprocessors:
        #     rel_text_nodes = node_processor.postprocess_nodes(rel_text_nodes)
        # rel_texts = [node.get_content() for node in rel_text_nodes]

        sorted_nodes_with_scores = []
        for chunk_idx, node in zip(sorted_chunk_indices, sorted_nodes):
            # nodes are found with keyword mapping, give high conf to avoid cutoff
            sorted_nodes_with_scores.append(
                NodeWithScore(node=node, score=DEFAULT_NODE_SCORE)
            )
            logger.debug(f'NODE: {node.node_id}, {node.text}')
            logger.info(
                f"> Querying with idx: {chunk_idx}: "
                f"{truncate_text(node.get_content(), 80)}"
            )
        # if no relationship is found, return the nodes found by keywords
        if not rel_texts:
            logger.info("> No relationships found, returning nodes found by keywords.")
            if len(sorted_nodes_with_scores) == 0:
                logger.info("> No nodes found by keywords, returning empty response.")
                return [
                    NodeWithScore(
                        node=TextNode(text="No relationships found."), score=1.0
                    )
                ]
            # In else case the sorted_nodes_with_scores is not empty
            # thus returning the nodes found by keywords
            return sorted_nodes_with_scores

        # add relationships as Node
        # TODO: make initial text customizable
        rel_initial_text = (
            f"The following are knowledge sequence in max depth"
            f" {self.graph_store_query_depth} "
            f"in the form of directed graph like:\n"
            f"`subject -[predicate]->, object, <-[predicate_next_hop]-,"
            f" object_next_hop ...`"
        )
        rel_info = [rel_initial_text, *rel_texts]
        rel_node_info = {
            "kg_rel_texts": rel_texts,
            "kg_rel_map": cur_rel_map,
        }
        if self._graph_schema != "":
            rel_node_info["kg_schema"] = {"schema": self._graph_schema}
        rel_info_text = "\n".join(
            [
                str(item)
                for sublist in rel_info
                for item in (sublist if isinstance(sublist, list) else [sublist])
            ]
        )

        if self._verbose:
            print_text(f"KG context:\n{rel_info_text}\n", color="blue")
        rel_text_node = TextNode(
            text=rel_info_text,
            metadata=rel_node_info,
            excluded_embed_metadata_keys=["kg_rel_map", "kg_rel_texts"],
            excluded_llm_metadata_keys=["kg_rel_map", "kg_rel_texts"],
        )
        # this node is constructed from rel_texts, give high confidence to avoid cutoff
        sorted_nodes_with_scores.append(
            NodeWithScore(node=rel_text_node, score=DEFAULT_NODE_SCORE)
        )

        return sorted_nodes_with_scores
"""

'''
    def _retrieve_org(
            self,
            query_bundle: QueryBundle,
    ) -> List[NodeWithScore]:
        """Get nodes for response."""
        node_visited = set()
        keywords = self._get_keywords(query_bundle.query_str)
        if self._verbose:
            print_text(f"Extracted keywords: {keywords}\n", color="green")
        rel_texts = []
        cur_rel_map = {}
        chunk_indices_count: Dict[str, int] = defaultdict(int)
        if self._retriever_mode != KGRetrieverMode.EMBEDDING:
            for keyword in keywords:
                subjs = {keyword}
                node_ids = self._index_struct.search_node_by_keyword(keyword)
                logger.debug(f'query_keyword: {keyword}, node_ids: {node_ids}')
                for node_id in node_ids[:GLOBAL_EXPLORE_NODE_LIMIT]:
                    if node_id in node_visited:
                        continue

                    if self._include_text:
                        chunk_indices_count[node_id] += 1

                    node_visited.add(node_id)
                    if self.use_global_node_triplets:
                        # Get nodes from keyword search, and add them to the subjs
                        # set. This helps introduce more global knowledge into the
                        # query. While it's more expensive, thus to be turned off
                        # by default, it can be useful for some applications.

                        # TODO: we should a keyword-node_id map in IndexStruct, so that
                        # node-keywords extraction with LLM will be called only once
                        # during indexing.
                        extended_subjs = self._get_keywords(
                            self._docstore.get_node(node_id).get_content(
                                metadata_mode=MetadataMode.LLM
                            )
                        )
                        subjs.update(extended_subjs)

                rel_map = self._graph_store.get_rel_map(
                    list(subjs), self.graph_store_query_depth
                )

                logger.debug(f"rel_map from kg: {rel_map}")

                if not rel_map:
                    continue
                rel_texts.extend(
                    [
                        str(rel_obj)
                        for rel_objs in rel_map.values()
                        for rel_obj in rel_objs
                    ]
                )
                cur_rel_map.update(rel_map)
        logger.debug(f'len_embedding_dict: {len(self._index_struct.embedding_dict)}')
        if (
                self._retriever_mode != KGRetrieverMode.KEYWORD
                and len(self._index_struct.embedding_dict) > 0
        ):
            query_embedding = self._embed_model.get_text_embedding(
                query_bundle.query_str
            )
            all_rel_texts = list(self._index_struct.embedding_dict.keys())
            logger.debug(f'all_rel_texts: {all_rel_texts}')
            # exit(0)

            rel_text_embeddings = [
                self._index_struct.embedding_dict[_id] for _id in all_rel_texts
            ]
            similarities, top_rel_texts = get_top_k_embeddings(
                query_embedding,
                rel_text_embeddings,
                similarity_top_k=self.similarity_top_k,
                embedding_ids=all_rel_texts,
            )
            logger.debug(
                f"Found the following rel_texts+query similarites: {similarities!s}"
            )
            logger.debug(f"Found the following top_k rel_texts: {rel_texts!s}")
            rel_texts.extend(top_rel_texts)

        elif len(self._index_struct.embedding_dict) == 0:
            logger.warning(
                "Index was not constructed with embeddings, skipping embedding usage..."
            )

        # remove any duplicates from keyword + embedding queries
        if self._retriever_mode == KGRetrieverMode.HYBRID:
            rel_texts = list(set(rel_texts))

            # remove shorter rel_texts that are substrings of longer rel_texts
            rel_texts.sort(key=len, reverse=True)
            for i in range(len(rel_texts)):
                for j in range(i + 1, len(rel_texts)):
                    if rel_texts[j] in rel_texts[i]:
                        rel_texts[j] = ""
            rel_texts = [rel_text for rel_text in rel_texts if rel_text != ""]

            # truncate rel_texts
            rel_texts = rel_texts[: self.max_knowledge_sequence]

        # When include_text = True just get the actual content of all the nodes
        # (Nodes with actual keyword match, Nodes which are found from the depth search and Nodes founnd from top_k similarity)
        if self._include_text:
            keywords = self._extract_rel_text_keywords(
                rel_texts
            )  # rel_texts will have all the Triplets retrieved with respect to the Query
            nested_node_ids = [
                self._index_struct.search_node_by_keyword(keyword)
                for keyword in keywords
            ]
            node_ids = [_id for ids in nested_node_ids for _id in ids]
            for node_id in node_ids:
                chunk_indices_count[node_id] += 1

        sorted_chunk_indices = sorted(
            chunk_indices_count.keys(),
            key=lambda x: chunk_indices_count[x],
            reverse=True,
        )
        sorted_chunk_indices = sorted_chunk_indices[: self.num_chunks_per_query]
        sorted_nodes = self._docstore.get_nodes(sorted_chunk_indices)

        # TMP/TODO: also filter rel_texts as nodes until we figure out better
        # abstraction
        # TODO(suo): figure out what this does
        # rel_text_nodes = [Node(text=rel_text) for rel_text in rel_texts]
        # for node_processor in self._node_postprocessors:
        #     rel_text_nodes = node_processor.postprocess_nodes(rel_text_nodes)
        # rel_texts = [node.get_content() for node in rel_text_nodes]

        sorted_nodes_with_scores = []
        for chunk_idx, node in zip(sorted_chunk_indices, sorted_nodes):
            # nodes are found with keyword mapping, give high conf to avoid cutoff
            sorted_nodes_with_scores.append(
                NodeWithScore(node=node, score=DEFAULT_NODE_SCORE)
            )
            logger.debug(f'NODE: {node.node_id}, {node.text}')
            logger.info(
                f"> Querying with idx: {chunk_idx}: "
                f"{truncate_text(node.get_content(), 80)}"
            )
        # if no relationship is found, return the nodes found by keywords
        if not rel_texts:
            logger.info("> No relationships found, returning nodes found by keywords.")
            if len(sorted_nodes_with_scores) == 0:
                logger.info("> No nodes found by keywords, returning empty response.")
                return [
                    NodeWithScore(
                        node=TextNode(text="No relationships found."), score=1.0
                    )
                ]
            # In else case the sorted_nodes_with_scores is not empty
            # thus returning the nodes found by keywords
            return sorted_nodes_with_scores

        # add relationships as Node
        # TODO: make initial text customizable
        rel_initial_text = (
            f"The following are knowledge sequence in max depth"
            f" {self.graph_store_query_depth} "
            f"in the form of directed graph like:\n"
            f"`subject -[predicate]->, object, <-[predicate_next_hop]-,"
            f" object_next_hop ...`"
        )
        rel_info = [rel_initial_text, *rel_texts]
        rel_node_info = {
            "kg_rel_texts": rel_texts,
            "kg_rel_map": cur_rel_map,
        }
        if self._graph_schema != "":
            rel_node_info["kg_schema"] = {"schema": self._graph_schema}
        rel_info_text = "\n".join(
            [
                str(item)
                for sublist in rel_info
                for item in (sublist if isinstance(sublist, list) else [sublist])
            ]
        )

        if self._verbose:
            print_text(f"KG context:\n{rel_info_text}\n", color="blue")
        rel_text_node = TextNode(
            text=rel_info_text,
            metadata=rel_node_info,
            excluded_embed_metadata_keys=["kg_rel_map", "kg_rel_texts"],
            excluded_llm_metadata_keys=["kg_rel_map", "kg_rel_texts"],
        )
        # this node is constructed from rel_texts, give high confidence to avoid cutoff
        sorted_nodes_with_scores.append(
            NodeWithScore(node=rel_text_node, score=DEFAULT_NODE_SCORE)
        )

        return sorted_nodes_with_scores
'''

if __name__ == '__main__':

    # rel_map = dict(a=['a1', 'a2'], b=['b1', 'b2', 'b3'])
    # result = [
    #     str(rel_obj)
    #     for rel_objs in rel_map.values()
    #     for rel_obj in rel_objs
    # ]
    # print(result)

    rel_texts = ["('高血压', '诊断', '夜间（或睡眠）血压平均值收缩压≥120mmHg和/或舒张压≥70mmHg', '类别', '生理指标')",
                 "('高血压', '诊断', '日间（或清醒）血压平均值收缩压≥135mmHg和/或舒张压≥85mmHg', '类别', '生理指标')",
                 "('高血压', '诊断', '诊室血压收缩压≥140mmHg和/或舒张压≥90mmHg', '类别', '生理指标')",
                 "('原发性高血压', '别名是', 'primary hypertension,EH', '类别', '别名')",
                 "('原发性高血压', '所属科室是', '心衰中心 首都医科大学附属北京安贞医院', '类别', '所属科室')",
                 "('高血压', '伴随', '糖尿病', '诊断', '空腹血糖:≥7.0mmml/L（126mg/dl）')",
                 "('高血压', '诊断', '24 小时平均血压 ≥ 130/80 mmHg', '类别', '生理指标')",
                 "('高血压', '诊断', '日间（或清醒）血压平均值收缩压≥135mmHg和/或舒张压≥85mmHg')",
                 "('高血压', '诊断', '夜间（或睡眠）血压平均值收缩压≥120mmHg和/或舒张压≥70mmHg')",
                 "('高血压', '诊断', '白天血压 ≥ 135/85 mmHg', '类别', '生理指标')",
                 "('高血压', '诊断', '夜间血压 ≥ 120/70 mmHg', '类别', '生理指标')",
                 "('高血压', '诊断', '家庭血压 ≥ 135/85 mmHg', '类别', '生理指标')",
                 "('高血压', '诊断', '诊室血压 ≥ 140/90 mmHg', '类别', '生理指标')", "('高血压', '诊断', '诊室血压收缩压≥140mmHg和/或舒张压≥90mmHg')",
                 "('原发性高血压', '别名是', 'primary hypertension,EH')", "('高血压', '诊断', '≥135/85 mmHg', '类别', '生理指标')",
                 "('高血压', '并发', '早发性高血压或脑血管意外', '类别', '并发症')", "('原发性高血压', '所属科室是', '心衰中心 首都医科大学附属北京安贞医院')",
                 "('高血压', '引发', '动脉粥样硬化性 CVD', '类别', '并发症')", "('高血压', '引发', '高血压介导的靶器官损伤', '类别', '并发症')",
                 "('高血压', '诊断', '24 小时平均血压 ≥ 130/80 mmHg')", "('高血压', '伴随', '糖尿病', '诊断', '餐后血糖:≥11.')",
                 "('高血压', '诊断', '诊室外血压测量', '类别', '生理指标')", "('高血压', '伴随', '糖尿病', '发病部位是', '内分泌系统')",
                 "('高血压', '并发', '充血性心力衰竭', '类别', '并发症')", "('高血压', '伴随', '糖尿病', '症状是', '微量白蛋白尿')",
                 "('高血压', '并发', '左心室肥厚', '发病部位是', '心脏')", "('高血压', '伴随', '糖尿病', '所属科室是', '内分泌科')",
                 "('高血压', '所属科室是', '内科', '类别', '所属科室')", "('高血压', '并发', '肾上腺偶发瘤', '类别', '并发症')",
                 "('高血压', '引发', '隐匿性高血压', '类别', '并发症')", "('高血压', '并发', '充血性心力衰竭', '类别', '疾病')",
                 "('高血压', '伴随', '糖尿病', '并发', '外周血管疾病')", "('高血压', '引发', '糖尿病并发症', '类别', '并发症')",
                 "('高血压', '并发', '睡眠呼吸暂停', '类别', '并发症')", "('高血压', '伴随', '糖尿病', '症状是', '口渴增加')",
                 "('高血压', '诊断', '家庭血压 ≥ 135/85 mmHg')", "('高血压', '诊断', '夜间血压 ≥ 120/70 mmHg')",
                 "('高血压', '伴随', '糖尿病', '并发', '视网膜病变')", "('高血压', '诊断', '白天血压 ≥ 135/85 mmHg')",
                 "('高血压', '诊断', '诊室血压 ≥ 140/90 mmHg')", "('高血压', '伴随', '糖尿病', '症状是', '体重下降')",
                 "('高血压', '并发', '左心室肥厚', '类别', '并发症')", "('高血压', '伴随', '糖尿病', '症状是', '频繁排尿')",
                 "('高血压', '并发', '腹主动脉瘤', '类别', '并发症')", "('高血压', '并发', '视网膜病变', '类别', '并发症')",
                 "('高血压', '症状是', '低钾血症', '类别', '症状')",
                 "('高血压', '症状是', '低钾血症', '类别', '疾病')", "('高血压', '并发', '左心室肥厚', '类别', '疾病')",
                 "('高血压', '伴随', '糖尿病', '引发', '心力衰竭')",
                 "('高血压', '伴随', '糖尿病', '伴随', '血脂异常')", "('高血压', '并发', '左室扩大', '类别', '并发症')",
                 "('高血压', '并发', '左心室肥厚', '类别', '症状')",
                 "('高血压', '引发', '心脏事件', '类别', '并发症')", "('高血压', '伴随', '糖尿病', '症状是', '多饮')",
                 "('高血压', '伴随', '合并症', '类别', '并发症')",
                 "('高血压', '并发', '心脏病', '类别', '并发症')", "('高血压', '伴随', '糖尿病', '引发', '高血压')",
                 "('高血压', '症状是', '无症状', '类别', '症状')",
                 "('高血压', '引发', '心脏病', '类别', '并发症')", "('高血压', '伴随', '糖尿病', '症状是', '多尿')",
                 "('高血压', '伴随', '慢性肾病', '类别', '疾病')",
                 "('高血压', '引发', 'CVD', '类别', '并发症')", "('高血压', '引发', '心脏病', '类别', '疾病')",
                 "('高血压', '并发', '心脏病', '类别', '疾病')",
                 "('高血压', '伴随', '糖尿病', '类别', '疾病')", "('高血压', '症状是', '头痛', '类别', '症状')",
                 "('高血压', '症状是', '眩晕', '类别', '症状')",
                 "('高血压', '伴随', '冠心病', '类别', '疾病')", "('高血压', '引发', '卒中', '类别', '并发症')",
                 "('高血压', '引发', '卒中', '类别', '疾病')",
                 "('高血压', '诊断', '≥135/85 mmHg')", "('高血压', '并发', '早发性高血压或脑血管意外')", "('高血压', '引发', '高血压介导的靶器官损伤')",
                 "('高血压', '引发', '动脉粥样硬化性 CVD')", "('环境因素', '引发', '原发性高血压')", "('高血压', '并发', '充血性心力衰竭')",
                 "('高血压', '诊断', '诊室外血压测量')",
                 "('遗传因素', '引发', '原发性高血压')", "('高血压', '并发', '肾上腺偶发瘤')", "('高血压', '并发', '睡眠呼吸暂停')",
                 "('高血压', '引发', '糖尿病并发症')",
                 "('高血压', '引发', '隐匿性高血压')", "('高血压', '并发', '视网膜病变')", "('高血压', '症状是', '低钾血症')",
                 "('高血压', '所属科室是', '内科')",
                 "('原发性高血压', '类别', '疾病')", "('高血压', '并发', '腹主动脉瘤')", "('高血压', '并发', '左心室肥厚')", "('高血压', '引发', '心脏事件')",
                 "('高血压', '症状是', '无症状')", "('高血压', '并发', '左室扩大')", "('高血压', '伴随', '慢性肾病')", "('高血压', '引发', '心脏病')",
                 "('高血压', '伴随', '冠心病')", "('高血压', '伴随', '合并症')", "('高血压', '引发', 'CVD')", "('高血压', '症状是', '眩晕')",
                 "('高血压', '症状是', '头痛')", "('高血压', '并发', '心脏病')", "('高血压', '伴随', '糖尿病')", "('高血压', '类别', '并发症')",
                 "('高血压', '类别', '疾病')", "('高血压', '引发', '卒中')"]

    rel_texts.sort(key=len, reverse=True)
    for i in range(len(rel_texts)):
        for j in range(i + 1, len(rel_texts)):
            if rel_texts[i] == "" or rel_texts[j] == "":
                continue
            if rel_texts[j][1:-1] in rel_texts[i][1:-1]:
                rel_texts[j] = ""
    rel_texts = [rel_text for rel_text in rel_texts if rel_text != ""]
    rel_texts_str = "\n".join(rel_texts)
    print(f'rel_texts (before truncated): \n{rel_texts_str}')

    # truncate rel_texts
    rel_texts = rel_texts[: 10]
    rel_texts_str = "\n".join(rel_texts)
    print(f'rel_texts (after truncated): \n{rel_texts_str}')

    # parse
    print(rel_texts[0][2:-2].split("', '"))
