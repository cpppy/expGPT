import os

os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'

import glob
from tqdm import tqdm
from llama_index.core.node_parser import SentenceSplitter

from loguru import logger
import uuid


def load_markdown_file(file_path, tag=None):
    from llama_index.core.node_parser import MarkdownNodeParser
    from llama_index.readers.file import FlatReader
    from pathlib import Path

    md_docs = FlatReader().load_data(Path(file_path))
    parser = MarkdownNodeParser()
    nodes = parser.get_nodes_from_documents(md_docs)
    for i, node in enumerate(nodes):
        nodes[i].metadata['file_path'] = file_path
        if tag is not None:
            nodes[i].metadata['tag'] = tag

    return nodes


def split_text(node):
    splitter = SentenceSplitter(
        # separator='\n\n',
        chunk_size=256,
        chunk_overlap=30,
    )
    # nodes = splitter.get_nodes_from_documents(documents)
    # logger.debug(f'raw_text: {repr(node.text)}')
    chunks = splitter.split_text(text=node.text)

    chunk_nodes = []
    from llama_index.core.schema import TextNode

    for i, chunk in enumerate(chunks):
        # if title is not None and title in chunk:
        #     continue
        _node = TextNode(
            text=chunk,
            # id_=f'{node.id_}-c{i}',
            # id_=node.id_,
            id=str(uuid.uuid4()),
            metadata=node.metadata,
        )
        chunk_nodes.append(_node)
    return chunk_nodes


def batch_load():

    file_paths = []
    for data_dir in [
        '/data/data/medical_data/drugs-dxy-cn-clinicalDecision-part1',
        '/data/data/medical_data/drugs-dxy-cn-clinicalDecision-part2',
    ]:
        _file_paths = glob.glob(f"{data_dir}/*/*.md")
        file_paths.extend(_file_paths)

    logger.info(f'n_file: {len(file_paths)}')
    tags = list(set([os.path.dirname(p).split(os.sep)[-1] for p in file_paths]))  # [1:2]
    logger.info(tags)

    tag2nodes = []
    for _tag in tqdm(tags, desc='building_textnode'):
        print(f'================= {_tag} =================')
        _file_idx = tags.index(_tag)
        _file_paths = [f for f in file_paths if _tag in f]
        _file_paths = sorted(_file_paths)
        logger.debug(f'_file_paths: {_file_paths}')

        nodes = []
        for i in range(len(_file_paths)):
            _nodes = load_markdown_file(_file_paths[i], tag=_tag)
            logger.debug(_nodes[0].metadata)
            title = _nodes[0].text.split('\n')[0]
            logger.debug(f"{i}. {title}")
            # exit(0)
            for node in _nodes:
                node.metadata['title'] = title

            nodes.extend(_nodes)

        logger.debug(f'n_node: {len(nodes)}')

        from itertools import chain
        chunk_nodes = list(chain(*[(split_text(node)) for node in nodes]))

        tag2nodes.append(dict(
            tag=_tag,
            chunk_nodes=chunk_nodes
        ))

    return tag2nodes



def load_articles():

    file_paths = []
    for data_dir in [
        '/data/data/medical_data/drugs-dxy-cn-clinicalDecision-part1',
        '/data/data/medical_data/drugs-dxy-cn-clinicalDecision-part2',
    ]:
        _file_paths = glob.glob(f"{data_dir}/*/*.md")
        file_paths.extend(_file_paths)

    # filenames = os.listdir(data_dir)
    # file_paths = [os.path.join(data_dir, fn) for fn in filenames]
    logger.info(f'n_file: {len(file_paths)}')
    tags = list(set([os.path.dirname(p).split(os.sep)[-1] for p in file_paths]))  # [1:2]
    logger.info(tags)

    tag2nodes = []
    for _tag in tqdm(tags, desc='building_textnode'):
        print(f'================= {_tag} =================')
        _file_idx = tags.index(_tag)
        _file_paths = [f for f in file_paths if _tag in f]  # [-1:]\
        # _file_paths = sorted(_file_paths, key=lambda x: int(x.split('_')[-1].split('.')[0]))
        _file_paths = sorted(_file_paths)
        logger.debug(f'_file_paths: {_file_paths}')

        nodes = []
        for i in range(len(_file_paths)):
            _nodes = load_markdown_file(_file_paths[i], tag=_tag)
            logger.debug(_nodes[0].metadata)

            nodes.extend(_nodes)

        logger.debug(f'n_node: {len(nodes)}')

        tag2nodes.append(dict(
            tag=_tag,
            article_nodes=nodes
        ))

    return tag2nodes


if __name__ == '__main__':

    import sys
    logger.remove()
    logger.add(sys.stderr, level="DEBUG")

    batch_load()
