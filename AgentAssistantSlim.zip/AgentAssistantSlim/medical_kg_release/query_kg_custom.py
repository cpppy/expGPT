import os
import glob
import hashlib
import json
import math
import random
import shutil
import time
from itertools import repeat
from multiprocessing.pool import Pool, ThreadPool
from pathlib import Path

from llama_index.core import (
    VectorStoreIndex,
    SimpleDirectoryReader,
    # KnowledgeGraphIndex,
)

from llama_index.core import StorageContext
from llama_index.graph_stores.neo4j import Neo4jGraphStore

import logging

logger = logging.getLogger(__name__)

import json
import pickle
from itertools import chain
from tqdm import tqdm

persist_dir = './medical_storage_cache'
os.makedirs(persist_dir, exist_ok=True)


def connect_neo4j(llm, embed_model):
    username = "neo4j"
    password = "123456"
    # url = "bolt://localhost:7687"
    url = "neo4j://localhost:7687"
    # url = 'neo4j://192.168.150.181:7687',
    # database = "medical"
    database = "medical2"

    graph_store = Neo4jGraphStore(
        username=username,
        password=password,
        url=url,
        database=database,
    )

    import qdrant_client
    from llama_index.vector_stores.qdrant import QdrantVectorStore
    from qdrant_client.http.models import Filter, FieldCondition, MatchValue
    client = qdrant_client.QdrantClient(
        # location=":memory:"
        path='./medical_qdrant_cache'
    )
    vector_store = QdrantVectorStore(
        client=client, collection_name="medical_kg_collection"
    )

    storage_context = StorageContext.from_defaults(vector_store=vector_store,
                                                   graph_store=graph_store,
                                                   persist_dir=persist_dir
                                                   )

    from medical_kg_release.custom_knowledge_graph_index import CustomKnowledgeGraphIndex as KnowledgeGraphIndex
    index = KnowledgeGraphIndex.from_documents(
        llm=llm,
        embed_model=embed_model,
        documents=[],
        storage_context=storage_context,
    )
    index._index_struct = storage_context.index_store.index_structs()[0]

    return index


def load_data_source():
    with open(
            f'./medicalKG_qwen2_72b_fp16_cot_triplets_part12_20240806.pkl',
            'rb') as f:
        outputs = pickle.load(f)

    from llama_index.core.schema import TextNode

    teams = []
    for x in outputs:
        _triplets = x['triplets']
        _raw_text = x['raw_text']
        node_id = x['node_id']
        metadata = x['node_metadata']
        metadata['triplets'] = _triplets

        node = TextNode(
            text=_raw_text,
            metadata=metadata,
        )
        node.id_ = node_id
        spo_tups = [(t['subject_name'], t['predicate'], t['object_name']) for t in _triplets]
        teams.append(dict(node=node, spo_tups=spo_tups))

    return teams


def parse_embedding(embed_model, team):
    tups = team['spo_tups']
    trip2emb = {}
    for tup in tups:
        triplet_str = str(tup)
        set_embedding = embed_model.get_text_embedding(triplet_str)
        trip2emb[triplet_str] = set_embedding
    return trip2emb


def add_data_to_neo4j():
    from llama_index.llms.openai_like import OpenAILike
    from llm_backend.qwen2.qwen2_system_prompt import completion_to_prompt, messages_to_prompt
    llm = OpenAILike(
        model='qwen2:72b-instruct',
        api_base="http://192.168.100.24:11434/v1",
        messages_to_prompt=messages_to_prompt,
        completion_to_prompt=completion_to_prompt,

        # model='llama3:70b-instruct',
        # api_base="http://192.168.100.24:11434/v1",

        api_key='EMPTY',
        temperature=0,
        max_tokens=2048,
        timeout=600,
    )

    from llama_index.embeddings.openai import OpenAIEmbedding
    embed_model = OpenAIEmbedding(
        # model='BAAI--bge-large-zh-v1.5',
        model="text-embedding-3-small",
        api_base="http://192.168.100.24:8002/v1",
        api_key='EMPTY')

    index = connect_neo4j(llm, embed_model)

    teams = load_data_source()  # [0:30]

    for team in tqdm(teams, desc='insert_triplet'):
        tups = team['spo_tups']
        node = team['node']

        for tup in tups:
            index.upsert_triplet_and_node(tup, node, include_embeddings=False)
    index.storage_context.persist(persist_dir=persist_dir)


def main():
    from llama_index.llms.openai_like import OpenAILike
    from llm_backend.qwen2.qwen2_system_prompt import completion_to_prompt, messages_to_prompt
    llm = OpenAILike(
        # model="Qwen1.5-0.5B-Chat",
        # api_base="http://192.168.150.181:8000/v1",

        # model='Mistral-7B-Instruct-v0.3',
        # api_base="http://192.168.100.21:9000/v1",
        # messages_to_prompt=messages_to_prompt,
        # completion_to_prompt=completion_to_prompt,

        # model='Meta-Llama-3-8B-Instruct',
        # api_base="http://192.168.100.21:9001/v1",
        # messages_to_prompt=messages_to_prompt,
        # completion_to_prompt=completion_to_prompt,

        # model='Qwen2-7B-Instruct',
        # api_base="http://192.168.100.24:9002/v1",

        # model='DeepSeek-Coder-V2-Lite-Instruct',
        # api_base="http://192.168.100.24:6006/v1",

        # model='Yi-1.5-9B-Chat',
        # api_base="http://192.168.100.24:9003/v1",

        # model='glm-4-9b-chat',
        # api_base='http://192.168.100.24:9003/v1',

        # model='mistral-nemo',
        # api_base="http://192.168.100.24:11434/v1",

        model='qwen2:72b-instruct',
        api_base="http://192.168.100.24:11434/v1",
        messages_to_prompt=messages_to_prompt,
        completion_to_prompt=completion_to_prompt,

        # model='llama3:70b-instruct',
        # api_base="http://192.168.100.24:11434/v1",

        api_key='EMPTY',
        temperature=0,
        max_tokens=2048,
        timeout=600,
    )

    from llama_index.embeddings.openai import OpenAIEmbedding
    embed_model = OpenAIEmbedding(
        # model='BAAI--bge-large-zh-v1.5',
        model="text-embedding-3-small",
        api_base="http://192.168.100.21:8003/v1",
        api_key='EMPTY')

    index = connect_neo4j(llm, embed_model)

    ################## retriever ##################
    from llama_index.core.indices.knowledge_graph.retrievers import (
        KGRetrieverMode,
        # KGTableRetriever,
    )
    from medical_kg_release.custom_kg_table_retriever import CustomKGTableRetriever as KGTableRetriever

    ENTITY_TYPES = ["疾病", "别名", "症状", "发病部位", "所属科室", "疗法", "风险因素", "生理指标", "病原体", "并发症"]
    RELATION_TYPES = ["别名是", "症状是", "发病部位是", "所属科室是", "引发", "伴随", "治疗", "并发", "改善", "诊断"]

    DEFAULT_QUERY_KEYWORD_EXTRACT_TEMPLATE_TMPL = (
        "A question is provided below. Given the question, extract up to {max_keywords} "
        "keywords from the text. Focus on extracting the keywords that we can use "
        "to best lookup answers to the question. Avoid stopwords.\n"
        "the keyword proposals will be limited in the list below:\n"
        "ENTITIES: ${entities_str}\n"
        "RELATIONSHIPS: ${relationships_str}\n"
        "---------------------\n"
        "{question}\n"
        "---------------------\n"
        "Provide keywords in the following comma-separated format: 'KEYWORDS: <keywords>'\n"
    )
    DEFAULT_QUERY_KEYWORD_EXTRACT_TEMPLATE_TMPL = DEFAULT_QUERY_KEYWORD_EXTRACT_TEMPLATE_TMPL.replace(
        '${entities_str}', f'[{", ".join(ENTITY_TYPES)}]'
    ).replace(
        '${relationships_str}', f'[{", ".join(RELATION_TYPES)}]'
    )
    from llama_index.core.prompts.base import PromptTemplate
    from llama_index.core.prompts.prompt_type import PromptType
    DEFAULT_QUERY_KEYWORD_EXTRACT_TEMPLATE = PromptTemplate(
        DEFAULT_QUERY_KEYWORD_EXTRACT_TEMPLATE_TMPL,
        prompt_type=PromptType.QUERY_KEYWORD_EXTRACT,
    )

    retriever = KGTableRetriever(
        index=index,
        llm=llm,
        embed_model=embed_model,
        # retriever_mode=retriever_mode,
        query_keyword_extract_template=DEFAULT_QUERY_KEYWORD_EXTRACT_TEMPLATE,
        max_keywords_per_query=1,
        max_knowledge_sequence=10,
        # retriever_mode=KGRetrieverMode.KEYWORD,
        retriever_mode=KGRetrieverMode.HYBRID,
        verbose=True,
        graph_store_query_depth=2,
        similarity_top_k=5,  # for triplet_embedding search
        include_text=True,
    )

    # keywords = retriever._get_keywords(query_str="告诉我原发性高血压的治疗方案？")
    # print(keywords)

    # response = retriever.retrieve(
    #     # "告诉我高血压的治疗方案？"
    #     "原发性高血压高血压的诊断标准是什么？"
    # )
    # print(f'[RESPONSE] n_nodes:{len(response)}\n{response}')
    # for elem in response:
    #     print(elem)

    return retriever


if __name__ == '__main__':
    logging.basicConfig(level=logging.WARNING,
                        format="[%(levelname)s] %(filename)s[%(levelno)s]{%(funcName)s} %(message)s")
    main()
    # add_data_to_neo4j()
