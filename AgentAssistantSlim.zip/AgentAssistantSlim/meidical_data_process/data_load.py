import os


class CheckupDataset:

    def __init__(self, cache_path):
        self.data = self._load_data(cache_path)

    def _load_data(self, cache_path):
        pass


    def get_idnum_list(self):
        pass


    def search_by_idnum(self, idnum):
        pass







