import os
import pandas as pd
import numpy as np


def process_v1():
    data_path = '/data/data/medical_data/体检样本_500samples_20240727/报表.xlsx'
    df = pd.read_excel(data_path, sheet_name=0)
    print(df.head())

    df = df['sfzh'].unique()
    print(df.shape)
    print(df)

def check_djlsh_and_tjbh(vals):
    '''
    tg0: '2012250744'
    tg1: '196160\n'
    '''
    tg0 = -1
    tg1 = -1
    for i, val in enumerate(vals):
        # print(val)
        if len(val)==10 and val.isdigit() and val.startswith('2') and tg0 == -1:
            tg0 = i
            # print(f'tg0: {i}')
            continue
        if val.endswith('\n') and val.replace('\n', '').isdigit() and len(val)==7 and tg1 < tg0:
            tg1 = i
            # print(f'tg1: {i}')
            continue
        if tg0 > 0 and tg1 > 0 and tg0 < tg1:
            if tg0 != 1:
                print(f'[INVALID INDEX]: {(tg0, tg1)}, {vals}')
            return (tg0, tg1)
    return None





def process_v2():
    data_path = '/data/data/medical_data/体检样本_500samples_20240727/0729-300000.csv'

    records = []
    col_names = ['MC', 'DJLSH', 'JG', 'TJXM', 'XH', 'TJBH']
    with open(data_path, encoding="utf-16", errors='ignore') as f:
        lines = f.readlines()[1:]
        print(f'num_lines: {len(lines)}')

        buffer = []
        for li, line in enumerate(lines):
            # n_vals = len(line.split(','))
            # if n_vals != len(col_names):
            #     print(f'# ----------------- {li} -----------------')
            #     print(repr(line))
            #     print(f'line:{li}, {n_vals}')
            buffer.extend(line.split(','))

            # # check '' in buffer
            # _buffer = []
            # for i, val in enumerate(buffer):
            #     if val == '' and buffer[i-1].endswith('\n'):
            #         continue
            #     else:
            #         _buffer.append(val)
            # buffer = _buffer

            find_valid = check_djlsh_and_tjbh(buffer)
            while find_valid is not None:
                print(f'-----------------------')
                record = buffer[find_valid[0]-1: find_valid[1]+1]
                if len(record) > len(col_names):
                    content = ''.join(record[2:-3])
                    record = record[0:2] + [content] + record[-3:]
                record[-1] = record[-1].replace('\n', '')

                if len(record) > len(col_names):
                    print(f'[INVALID ADD] {record}')

                records.append(record)
                print(f'[ADD] {find_valid}, {records[-1]}')
                buffer = buffer[find_valid[1]+1:]
                find_valid = check_djlsh_and_tjbh(buffer)
            if len(buffer) > 100:
                print(f'[INVALID BUFFER] {buffer}')
                exit(0)

    # check_dates = [x[1] for x in records]
    # for i in range(len(check_dates) // 100):
    #     print(check_dates[i*100: (i+1) * 100])

    df = pd.DataFrame(
        {
            # 'subject_name': [t['subject_name'] for t in sorted_triplets],
            # 'subject_type': [t['subject_type'] for t in sorted_triplets],
            # 'predicate': [t['predicate'] for t in sorted_triplets],
            # 'object_name': [t['object_name'] for t in sorted_triplets],
            # 'object_type': [t['object_type'] for t in sorted_triplets],
            col_name: [x[i] for x in records]
            for i, col_name in enumerate(col_names)
        }
    )
    df.to_excel(
        f'/data/data/medical_data/体检样本_500samples_20240727/0729-300000_fixed.xlsx',
        sheet_name='metrics',
        index=False,
    )
    print(f'excel file generated.')



if __name__ == '__main__':
    process_v2()

    # buffer = ['双乳钼靶', '2101190056', '（一）双乳腺体组织内多发类结节样密度影，良性病变可能大，请结合其他影像学检查，BI-RADS 3  \n', '（二）双乳散在点状及圆形钙化灶，良性钙化灶，BI-RADS 2', '070064', '17161939', '772398\n', '身高', '2101190056', 'NULL', '010001', '17161940', '772398\n', '体重', '2101190056', 'NULL', '010002', '17161940', '772398\n', '血压', '2101190056', '', '010003', '17161940', '772398\n', '脉搏(机测)', '2101190056', 'NULL', '010004', '17161940', '772398\n', '甘油三脂(TG)', '2101190056', '2.04', '060060', '17161941', '772398\n', '总胆固醇(CHOL)', '2101190056', '4.70', '060061', '17161941', '772398\n', '高密度脂蛋白(HDL)', '2101190056', '1.14', '060062', '17161941', '772398\n', '低密度脂蛋白(LDL)', '2101190056', '2.76', '060063', '17161941', '772398\n', '淋巴细胞计数', '2101190056', '3.31', '060265', '17161942', '772398\n', '中性粒细胞计数', '2101190056', '3.66', '060267', '17161942', '772398\n', '血小板压积', '2101190056', '0.25', '060269', '17161942', '772398\n', '单核细胞%', '2101190056', '4.90', '060271', '17161942', '772398\n', '嗜酸性粒细胞%', '2101190056', '0.50', '060272', '17161942', '772398\n', '嗜碱性粒细胞%', '2101190056', '0.70', '060273', '17161942', '772398\n', '嗜中性粒细胞％', '2101190056', '49.30', '060274', '17161942', '772398\n', '单核细胞计数', '2101190056', '0.36', '060275', '17161942', '772398\n']
    # print(check_djlsh_and_tjbh(buffer))
