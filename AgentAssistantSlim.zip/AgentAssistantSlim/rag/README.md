
# end to end RAG
https://medium.com/@myscale/end-to-end-rag-pipeline-development-with-myscale-and-llamaindex-ff1a9cf7ab47

# rerank
https://zhuanlan.zhihu.com/p/675269272

# retrieval evaluation
https://mp.weixin.qq.com/s?__biz=MzU2NTYyMDk5MQ==&mid=2247486199&idx=1&sn=f24175b05bdf5bc6dd42efed4d5acae8&chksm=fcb9b367cbce3a711fabd1a56bb5b9d803aba2f42964b4e1f9a4dc6e2174f0952ddb9e1d4c55&token=1977141018&lang=zh_CN&scene=21#wechat_redirect
https://github.com/percent4/embedding_rerank_retrieval




