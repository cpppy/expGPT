import os

os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'

from typing import List
from pydantic import BaseModel, Field
from llama_index.core.output_parsers import PydanticOutputParser

import glob
import logging


def load_models():
    from llama_index.llms.openai_like import OpenAILike
    llm = OpenAILike(
        # model="Qwen1.5-0.5B-Chat",
        # api_base="http://192.168.150.181:8000/v1",
        model='Mistral-7B-Instruct-v0.2',
        api_base="http://192.168.100.21:8000/v1",
        api_key='EMPTY',
        temperature=0.,
        max_tokens=1000,
    )

    from llama_index.core import Settings
    from llama_index.embeddings.huggingface import HuggingFaceEmbedding
    embed_model = HuggingFaceEmbedding(
        # model_name="BAAI/bge-small-en-v1.5",
        # model_name="BAAI/bge-small-zh-v1.5"
        # model_name="BAAI/bge-base-zh-v1.5"
        model_name="BAAI/bge-large-zh-v1.5",
        device='cpu',
    )

    Settings.llm = llm
    Settings.embed_model = embed_model
    return llm, embed_model


def load_markdown_file(file_path):
    from llama_index.core.node_parser import MarkdownNodeParser
    from llama_index.readers.file import FlatReader
    from pathlib import Path

    md_docs = FlatReader().load_data(Path(file_path))
    parser = MarkdownNodeParser()
    nodes = parser.get_nodes_from_documents(md_docs)
    for node in nodes:
        logging.debug(node)

    return nodes


from llama_index.core.node_parser import SentenceSplitter


class CustomSentenceSplitter(SentenceSplitter):
    def split_text(self, text: str) -> List[str]:
        return text.split(self.separator)


def split_text(node):
    splitter = CustomSentenceSplitter(
        separator="|\n",
        # chunk_size=1024,
    )
    # nodes = splitter.get_nodes_from_documents(documents)
    logging.debug(f'raw_text: {repr(node.text)}')
    chunks = splitter.split_text(text=node.text)
    for i in range(len(chunks)):
        chunks[i] = chunks[i].replace('|', '-')
        logging.debug(f'chunk_{i}: {chunks[i]}')

    chunk_nodes = []
    from llama_index.core.schema import TextNode
    for i, chunk in enumerate(chunks):
        _node = TextNode(text=chunk, id_=f'{node.id_}-c{i}')
        chunk_nodes.append(_node)
    return chunk_nodes


def main():
    llm, embed_model = load_models()

    data_dir = '/data/data/shuiwen_md'
    file_paths = glob.glob(f'{data_dir}/*.md')
    logging.info(f'n_file: {len(file_paths)}')

    tags = list(set([os.path.basename(f).split('_')[0].split('.')[0] for f in file_paths]))
    logging.debug(tags)

    _tag = "孙口水文站2023年测洪及报汛方案"
    _file_idx = tags.index(_tag)
    _file_paths = [f for f in file_paths if _tag in f][-1:]
    logging.debug(f'_file_paths: {_file_paths}')

    nodes = []
    for i in range(len(_file_paths)):
        _nodes = load_markdown_file(_file_paths[i])
        nodes.extend(_nodes)
    logging.debug(f'n_node: {len(nodes)}')

    from itertools import chain
    chunk_nodes = list(chain(*[(split_text(node)) for node in nodes]))

    ################ build vector store index ################
    '''
    https://docs.llamaindex.ai/en/latest/module_guides/indexing/vector_store_index/
    https://docs.llamaindex.ai/en/latest/module_guides/indexing/vector_store_guide/
    '''
    from llama_index.core import VectorStoreIndex
    index = VectorStoreIndex(
        nodes=chunk_nodes,
        embed_model=embed_model
    )

    query_engine = index.as_query_engine(
        llm=llm,
        similarity_top_k=10,
    )
    # response = query_engine.query("流量测验方案有哪些？")
    # logging.debug(response)

    response = query_engine.query("流量测验的相关人员有哪些？分别对应哪些任务？")
    logging.debug(response)

    exit(0)

    ################# parse location #################
    from agents.demo_custom_agent_v2 import load_model
    llm = load_model(with_embedding=False)

    from llama_index.core.query_pipeline import QueryPipeline
    from llama_index.core import PromptTemplate

    json_prompt_str = """
        Please parse the year number and location name in {title}.
        \nOutput with the following JSON format:
        """

    # add JSON spec to prompt template
    json_prompt_tmpl = PromptTemplate(json_prompt_str)

    p = QueryPipeline(chain=[json_prompt_tmpl, llm], verbose=True)

    for frame_title in tags[0:3]:
        logging.debug(f'------------------------------')
        output = p.run(title=frame_title)
        logging.debug(f'output: {output}')


if __name__ == '__main__':
    import sys

    logging.basicConfig(stream=sys.stdout,
                        level=logging.DEBUG,
                        format="[%(levelname)s] %(filename)s[%(levelno)s]{%(funcName)s} %(message)s")

    main()
