import os

os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'

from typing import List
from pydantic import BaseModel, Field
from llama_index.core.output_parsers import PydanticOutputParser

import glob
import logging


def load_models():
    from llama_index.llms.openai_like import OpenAILike
    llm = OpenAILike(
        # model="Qwen1.5-0.5B-Chat",
        # api_base="http://192.168.150.181:8000/v1",
        model='Mistral-7B-Instruct-v0.2',
        api_base="http://192.168.100.21:8000/v1",
        api_key='EMPTY',
        temperature=0.,
        max_tokens=1000,
    )

    from llama_index.core import Settings
    from llama_index.embeddings.huggingface import HuggingFaceEmbedding
    embed_model = HuggingFaceEmbedding(
        # model_name="BAAI/bge-small-en-v1.5",
        # model_name="BAAI/bge-small-zh-v1.5"
        # model_name="BAAI/bge-base-zh-v1.5"
        model_name="BAAI/bge-large-zh-v1.5",
        device='cpu',
    )

    Settings.llm = llm
    Settings.embed_model = embed_model
    return llm, embed_model


class ReportMeta(BaseModel):
    """Object representing a single movie."""
    year: int = Field(..., description="Year number in the given string.")
    location: str = Field(..., description="Location Name.")
    # document_type: str = Field(..., description="Document type of the sample.")
    document_type: str = Field(..., description="Document type of the sample, such as 产品调研报告 or 年度或季度升级计划 etc.")


def main():

    llm, embed_model = load_models()

    data_dir = '/data/data/shuiwen_md'
    file_paths = glob.glob(f'{data_dir}/*.md')
    print(f'n_file: {len(file_paths)}')

    tags = list(set([os.path.basename(f).split('_')[0].split('.')[0] for f in file_paths]))
    print(tags)

    ################# parse location #################
    from llama_index.core.query_pipeline import QueryPipeline
    from llama_index.core import PromptTemplate

    output_parser = PydanticOutputParser(ReportMeta)
    # json_prompt_str = """
    # Please parse the year number and location name in {title}. \nOutput with the following JSON format:
    # """

    # json_prompt_str = """
    # Please parse the year number and location name in {title}.
    #
    # I will give you an example to let you know how to execute this function, for the sample as below:
    # 2020年海宁皮革城员工工资发放情况调查表
    # \n You need to recognize that
    # the year number is 2020,
    # the location is 海宁皮革城,
    # the document type is 员工工资发放情况调查表
    #
    # \nOutput with the following JSON format:
    # """

    json_prompt_str = """
        Please parse the year number and location name in {title}.
        \nOutput with the following JSON format:
        """

    json_prompt_str = output_parser.format(json_prompt_str)

    # add JSON spec to prompt template
    json_prompt_tmpl = PromptTemplate(json_prompt_str)

    p = QueryPipeline(chain=[json_prompt_tmpl, llm, output_parser], verbose=True)

    for frame_title in tags[0:3]:
        logging.debug(f'------------------------------')
        output = p.run(title=frame_title)
        logging.debug(f'output: {output}')



if __name__=='__main__':

    import sys

    logging.basicConfig(stream=sys.stdout,
                        level=logging.DEBUG,
                        format="[%(levelname)s] %(filename)s[%(levelno)s]{%(funcName)s} %(message)s")

    main()



