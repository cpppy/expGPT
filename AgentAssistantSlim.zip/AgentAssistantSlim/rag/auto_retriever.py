from llama_index.indices.vector_store.retrievers import (
    VectorIndexAutoRetriever,
)