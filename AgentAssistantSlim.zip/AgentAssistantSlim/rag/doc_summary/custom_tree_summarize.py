import asyncio
from typing import Any, Optional, Sequence

from llama_index.core.async_utils import run_async_tasks
from llama_index.core.callbacks.base import CallbackManager
from llama_index.core.indices.prompt_helper import PromptHelper
from llama_index.core.prompts import BasePromptTemplate
from llama_index.core.prompts.default_prompt_selectors import (
    DEFAULT_TREE_SUMMARIZE_PROMPT_SEL,
)
from llama_index.core.prompts.mixin import PromptDictType
from llama_index.core.response_synthesizers.base import BaseSynthesizer
from llama_index.core.service_context import ServiceContext
from llama_index.core.service_context_elements.llm_predictor import LLMPredictorType
from llama_index.core.types import RESPONSE_TEXT_TYPE, BaseModel

import logging


'''
from llama_index.core.response_synthesizers import TreeSummarize
'''
class CustomTreeSummarize(BaseSynthesizer):
    """
    Tree summarize response builder.

    This response builder recursively merges text chunks and summarizes them
    in a bottom-up fashion (i.e. building a tree from leaves to root).

    More concretely, at each recursively step:
    1. we repack the text chunks so that each chunk fills the context window of the LLM
    2. if there is only one chunk, we give the final response
    3. otherwise, we summarize each chunk and recursively summarize the summaries.
    """

    def __init__(
            self,
            llm: Optional[LLMPredictorType] = None,
            callback_manager: Optional[CallbackManager] = None,
            prompt_helper: Optional[PromptHelper] = None,
            summary_template: Optional[BasePromptTemplate] = None,
            output_cls: Optional[BaseModel] = None,
            streaming: bool = False,
            use_async: bool = False,
            verbose: bool = False,
            # deprecated
            service_context: Optional[ServiceContext] = None,
    ) -> None:
        if service_context is not None:
            prompt_helper = service_context.prompt_helper

        super().__init__(
            llm=llm,
            callback_manager=callback_manager,
            prompt_helper=prompt_helper,
            service_context=service_context,
            streaming=streaming,
            output_cls=output_cls,
        )
        self._summary_template = summary_template or DEFAULT_TREE_SUMMARIZE_PROMPT_SEL
        self._use_async = use_async
        self._verbose = verbose

    def _get_prompts(self) -> PromptDictType:
        """Get prompts."""
        return {"summary_template": self._summary_template}

    def _update_prompts(self, prompts: PromptDictType) -> None:
        """Update prompts."""
        if "summary_template" in prompts:
            self._summary_template = prompts["summary_template"]

    async def aget_response(
            self,
            query_str: str,
            text_chunks: Sequence[str],
            **response_kwargs: Any,
    ) -> RESPONSE_TEXT_TYPE:
        """Get tree summarize response."""
        summary_template = self._summary_template.partial_format(query_str=query_str)
        # repack text_chunks so that each chunk fills the context window
        text_chunks = self._prompt_helper.repack(
            summary_template, text_chunks=text_chunks
        )

        if self._verbose:
            print(f"{len(text_chunks)} text chunks after repacking")

        # give final response if there is only one chunk
        if len(text_chunks) == 1:
            response: RESPONSE_TEXT_TYPE
            if self._streaming:
                response = self._llm.stream(
                    summary_template, context_str=text_chunks[0], **response_kwargs
                )
            else:
                if self._output_cls is None:
                    response = await self._llm.apredict(
                        summary_template,
                        context_str=text_chunks[0],
                        **response_kwargs,
                    )
                else:
                    response = await self._llm.astructured_predict(
                        self._output_cls,
                        summary_template,
                        context_str=text_chunks[0],
                        **response_kwargs,
                    )

            # return pydantic object if output_cls is specified
            return response

        else:
            # summarize each chunk
            if self._output_cls is None:
                tasks = [
                    self._llm.apredict(
                        summary_template,
                        context_str=text_chunk,
                        **response_kwargs,
                    )
                    for text_chunk in text_chunks
                ]
            else:
                tasks = [
                    self._llm.astructured_predict(
                        self._output_cls,
                        summary_template,
                        context_str=text_chunk,
                        **response_kwargs,
                    )
                    for text_chunk in text_chunks
                ]

            summary_responses = await asyncio.gather(*tasks)
            if self._output_cls is not None:
                summaries = [summary.json() for summary in summary_responses]
            else:
                summaries = summary_responses

            # recursively summarize the summaries
            return await self.aget_response(
                query_str=query_str,
                text_chunks=summaries,
                **response_kwargs,
            )

    def get_response(
            self,
            query_str: str,
            text_chunks: Sequence[str],
            **response_kwargs: Any,
    ) -> RESPONSE_TEXT_TYPE:
        """Get tree summarize response."""
        summary_template = self._summary_template.partial_format(query_str=query_str)
        # repack text_chunks so that each chunk fills the context window
        text_chunks = self._prompt_helper.repack(
            summary_template, text_chunks=text_chunks
        )

        logging.debug(f'repack chunks: {text_chunks}')

        if self._verbose:
            print(f"{len(text_chunks)} text chunks after repacking")

        # give final response if there is only one chunk
        if len(text_chunks) == 1:
            response: RESPONSE_TEXT_TYPE
            if self._streaming:
                response = self._llm.stream(
                    summary_template, context_str=text_chunks[0], **response_kwargs
                )
            else:
                if self._output_cls is None:
                    response = self._llm.predict(
                        summary_template,
                        context_str=text_chunks[0],
                        **response_kwargs,
                    )
                else:
                    response = self._llm.structured_predict(
                        self._output_cls,
                        summary_template,
                        context_str=text_chunks[0],
                        **response_kwargs,
                    )

            return response

        else:
            # summarize each chunk
            if self._use_async:
                if self._output_cls is None:
                    tasks = [
                        self._llm.apredict(
                            summary_template,
                            context_str=text_chunk,
                            **response_kwargs,
                        )
                        for text_chunk in text_chunks
                    ]
                else:
                    tasks = [
                        self._llm.astructured_predict(
                            self._output_cls,
                            summary_template,
                            context_str=text_chunk,
                            **response_kwargs,
                        )
                        for text_chunk in text_chunks
                    ]

                summary_responses = run_async_tasks(tasks)

                if self._output_cls is not None:
                    summaries = [summary.json() for summary in summary_responses]
                else:
                    summaries = summary_responses
            else:
                if self._output_cls is None:
                    summaries = [
                        self._llm.predict(
                            summary_template,
                            context_str=text_chunk,
                            **response_kwargs,
                        )
                        for text_chunk in text_chunks
                    ]
                else:
                    summaries = [
                        self._llm.structured_predict(
                            self._output_cls,
                            summary_template,
                            context_str=text_chunk,
                            **response_kwargs,
                        )
                        for text_chunk in text_chunks
                    ]
                    summaries = [summary.json() for summary in summaries]

            # recursively summarize the summaries
            return self.get_response(
                query_str=query_str, text_chunks=summaries, **response_kwargs
            )






def main():
    from llama_index.llms.openai_like import OpenAILike
    llm = OpenAILike(
        # model="Qwen1.5-0.5B-Chat",
        # api_base="http://192.168.150.181:8000/v1",
        model='Mistral-7B-Instruct-v0.2',
        api_base="http://192.168.100.21:8000/v1",
        api_key='EMPTY',
        temperature=0.,
        max_tokens=1000,
    )

    from llama_index.core.settings import (
        Settings,
        callback_manager_from_settings_or_context,
        llm_from_settings_or_context,
    )
    from llama_index.core.service_context import ServiceContext
    service_context = None
    prompt_helper = None
    from llama_index.core.prompts.default_prompt_selectors import (
        DEFAULT_REFINE_PROMPT_SEL,
        DEFAULT_TEXT_QA_PROMPT_SEL,
        DEFAULT_TREE_SUMMARIZE_PROMPT_SEL,
    )
    from llama_index.core.prompts.default_prompts import DEFAULT_SIMPLE_INPUT_PROMPT
    text_qa_template = None
    refine_template = None
    simple_template = None
    summary_template = None
    output_cls = None
    streaming = False
    use_async = False
    verbose = True

    text_qa_template = text_qa_template or DEFAULT_TEXT_QA_PROMPT_SEL
    refine_template = refine_template or DEFAULT_REFINE_PROMPT_SEL
    simple_template = simple_template or DEFAULT_SIMPLE_INPUT_PROMPT
    summary_template = summary_template or DEFAULT_TREE_SUMMARIZE_PROMPT_SEL
    callback_manager = callback_manager_from_settings_or_context(
        Settings, service_context
    )
    if service_context is not None:
        prompt_helper = service_context.prompt_helper
    else:
        prompt_helper = (
                prompt_helper
                or Settings._prompt_helper
                or PromptHelper.from_llm_metadata(
            llm.metadata,
        )
        )

    from llama_index.core.schema import (
        BaseNode,
        MetadataMode,
        NodeWithScore,
        QueryBundle,
        QueryType,
    )

    response_synthesizer = CustomTreeSummarize(
        llm=llm,
        callback_manager=callback_manager,
        prompt_helper=prompt_helper,
        summary_template=summary_template,
        output_cls=output_cls,
        streaming=streaming,
        use_async=use_async,
        verbose=verbose,
        # deprecated
        service_context=service_context,
    )

    from llama_index.core.schema import TextNode
    nodes = [
        TextNode(
            text=(
                "Michael Jordan is a retired professional basketball player,"
                " widely regarded as one of the greatest basketball players of all"
                " time."
            ),
            metadata={
                "category": "Sports",
                "country": "United States",
            },
        ),
        TextNode(
            text=(
                "Angelina Jolie is an American actress, filmmaker, and"
                " humanitarian. She has received numerous awards for her acting"
                " and is known for her philanthropic work."
            ),
            metadata={
                "category": "Entertainment",
                "country": "United States",
            },
        ),
        TextNode(
            text=(
                "Rihanna is a Barbadian singer, actress, and businesswoman. She"
                " has achieved significant success in the music industry and is"
                " known for her versatile musical style."
            ),
            metadata={
                "category": "Music",
                "country": "Barbados",
            },
        ),
        TextNode(
            text=(
                "Cristiano Ronaldo is a Portuguese professional footballer who is"
                " considered one of the greatest football players of all time. He"
                " has won numerous awards and set multiple records during his"
                " career."
            ),
            metadata={
                "category": "Sports",
                "country": "Portugal",
            },
        ),
    ]

    response_str = response_synthesizer.get_response(
        query_str='Who is Michael Jordan?',
        text_chunks=[
            # n.node.get_content(metadata_mode=MetadataMode.LLM) for n in nodes
            n.text for n in nodes
        ],
    )
    logging.debug(response_str)



if __name__ == '__main__':
    import sys

    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
    # logging.getLogger().addHandler(logging.StreamHandler(stream=sys.stdout))

    main()
