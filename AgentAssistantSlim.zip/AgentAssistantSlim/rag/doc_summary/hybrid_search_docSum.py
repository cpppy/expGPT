
'''
https://docs.llamaindex.ai/en/stable/examples/index_structs/doc_summary/DocSummary/

'''


import os

os.environ['NUMEXPR_MAX_THREADS'] = '12'
os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'

# os.environ["OPENAI_API_KEY"] = "sk-..."
# openai.api_key = os.environ["OPENAI_API_KEY"]

import logging
import sys

logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
# logging.getLogger().addHandler(logging.StreamHandler(stream=sys.stdout))

# # Uncomment if you want to temporarily disable logger
# logger = logging.getLogger()
# logger.disabled = True

import nest_asyncio

nest_asyncio.apply()

from llama_index.core import SimpleDirectoryReader, get_response_synthesizer
from llama_index.core import DocumentSummaryIndex
from llama_index.llms.openai import OpenAI
from llama_index.core.node_parser import SentenceSplitter

from llama_index.core.response_synthesizers import ResponseMode


# Load Datasets
from pathlib import Path

import requests


def main():

    wiki_titles = ["Toronto", "Seattle"] #, "Chicago", "Boston", "Houston"]

    # download data
    # for title in wiki_titles:
    #     response = requests.get(
    #         "https://en.wikipedia.org/w/api.php",
    #         params={
    #             "action": "query",
    #             "format": "json",
    #             "titles": title,
    #             "prop": "extracts",
    #             # 'exintro': True,
    #             "explaintext": True,
    #         },
    #     ).json()
    #     page = next(iter(response["query"]["pages"].values()))
    #     wiki_text = page["extract"]
    #
    #     data_path = Path("data")
    #     if not data_path.exists():
    #         Path.mkdir(data_path)
    #
    #     with open(data_path / f"{title}.txt", "w") as fp:
    #         fp.write(wiki_text)

    # Load all wiki documents
    city_docs = []
    for wiki_title in wiki_titles:
        docs = SimpleDirectoryReader(
            input_files=[f"/data/AgentAssistant/rag/doc_summary/data/{wiki_title}.txt"]
        ).load_data()
        docs[0].doc_id = wiki_title
        city_docs.extend(docs)
    logging.debug(f'n_city_doc: {len(city_docs)}')
    logging.debug(city_docs[0])


    # Build Document Summary Index
    # Building Hybrid Retrieval with Chunk Embedding + Parent Embedding
    from llama_index.llms.openai_like import OpenAILike
    llm = OpenAILike(
        # model="Qwen1.5-0.5B-Chat",
        # api_base="http://192.168.150.181:8000/v1",
        model='Mistral-7B-Instruct-v0.2',
        api_base="http://192.168.100.21:8000/v1",
        api_key='EMPTY',
        temperature=0.,
        max_tokens=1000,
    )
    from llama_index.embeddings.huggingface import HuggingFaceEmbedding
    embed_model = HuggingFaceEmbedding(
        model_name="BAAI/bge-base-en-v1.5",
    )

    from llama_index.core import Settings
    Settings.llm = llm
    Settings.embed_model = embed_model

    splitter = SentenceSplitter(chunk_size=1024)

    # default mode of building the index
    response_synthesizer = get_response_synthesizer(
        llm=llm,
        # response_mode="tree_summarize",
        response_mode=ResponseMode.TREE_SUMMARIZE,
        use_async=False
    )

    doc_summary_index = DocumentSummaryIndex.from_documents(
        city_docs,
        llm=llm,
        transformations=[splitter],
        response_synthesizer=response_synthesizer,
        show_progress=True,
    )

    summary_str = doc_summary_index.get_document_summary("Boston")
    logging.debug(summary_str)


if __name__=='__main__':

    main()

