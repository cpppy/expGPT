During query-time, we retrieve smaller chunks, but we follow references to bigger chunks. This allows us to have more context for synthesis.

https://docs.llamaindex.ai/en/latest/examples/retrievers/recursive_retriever_nodes/
