import os

os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'
os.environ['NUMEXPR_MAX_THREADS'] = 12

'''
https://docs.llamaindex.ai/en/stable/examples/low_level/router/?h=routerquery#define-routerqueryengine

'''



def load_data():

    from agents.demo_custom_agent_v2 import load_model
    llm = load_model()

    from llama_index.embeddings.huggingface import HuggingFaceEmbedding
    embed_model = HuggingFaceEmbedding(
        # model_name="BAAI/bge-small-en-v1.5",
        # model_name="BAAI/bge-small-zh-v1.5",
        # model_name='BAAI/bge-large-zh-v1.5',
        model_name='BAAI/bge-base-zh-v1.5',
        # device='cpu',
        trust_remote_code=True,
    )

    '''
    !mkdir data
    !wget --user-agent "Mozilla" "https://arxiv.org/pdf/2307.09288.pdf" -O "data/llama2.pdf"
    '''
    file_path = "/rag/files/CN201811440315.2_基于深度学习的水库最优调度决策模型生成方法.pdf"

    from pathlib import Path
    from llama_index.readers.file import PyMuPDFReader

    loader = PyMuPDFReader()
    documents = loader.load(file_path=file_path)

    from llama_index.core import VectorStoreIndex
    from llama_index.core import SummaryIndex
    from llama_index.core.node_parser import SentenceSplitter

    splitter = SentenceSplitter(chunk_size=1024)
    vector_index = VectorStoreIndex.from_documents(
        documents,
        transformations=[splitter],
        embed_model=embed_model,
        show_progress=True,
    )

    summary_index = SummaryIndex.from_documents(
        documents, transformations=[splitter],
        embed_model=embed_model,
        show_progress=True,
    )

    vector_query_engine = vector_index.as_query_engine()
    summary_query_engine = summary_index.as_query_engine()

    # print(f'prompts: {vector_query_engine.get_prompts()}')
    # TODO: update template to modify the query response

    # response = vector_query_engine.query("How does the Llama 2 model compare to GPT-4 in the experimental results?")
    # print(f'response: {response}')

    # response = summary_query_engine.query("How does the Llama 2 model compare to GPT-4 in the experimental results?")
    # print(f'response: {response}')

    return vector_query_engine, summary_query_engine


if __name__ == '__main__':
    import logging
    import sys

    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
    # logging.getLogger().addHandler(logging.StreamHandler(stream=sys.stdout))

    load_data()
