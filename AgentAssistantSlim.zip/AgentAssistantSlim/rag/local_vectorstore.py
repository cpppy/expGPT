'''
https://docs.llamaindex.ai/en/latest/examples/agent/lats_agent/?h=tree

'''