'''
https://docs.llamaindex.ai/en/stable/examples/vector_stores/chroma_auto_retriever/


'''

import logging

# set up OpenAI
import os

os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'

os.environ['NUMEXPR_MAX_THREADS'] = '12'

import getpass

# os.environ["OPENAI_API_KEY"] = getpass.getpass("OpenAI API Key:")
# import openai
# openai.api_key = os.environ["OPENAI_API_KEY"]

import chromadb

from loguru import logger


def main():
    #################### load model ####################
    from llama_index.llms.openai_like import OpenAILike
    llm = OpenAILike(
        # model="Qwen1.5-0.5B-Chat",
        # api_base="http://192.168.150.181:8000/v1",
        model='Mistral-7B-Instruct-v0.2',
        api_base="http://192.168.100.21:8000/v1",
        api_key='EMPTY',
        temperature=0.,
        max_tokens=1000,
    )

    # from llama_index.embeddings.huggingface import HuggingFaceEmbedding
    # embed_model = HuggingFaceEmbedding(
    #     model_name="BAAI/bge-small-en-v1.5",
    # )
    from llama_index.core.embeddings import resolve_embed_model
    embed_model = resolve_embed_model("local:BAAI/bge-small-en-v1.5")

    # from llama_index.core import Settings
    # Settings.llm = llm
    # Settings.embed_model = embed_model
    ####################################################

    chroma_client = chromadb.EphemeralClient()
    chroma_collection = chroma_client.create_collection("quickstart")

    # Defining Some Sample Data
    from llama_index.core import VectorStoreIndex, StorageContext
    from llama_index.vector_stores.chroma import ChromaVectorStore
    from llama_index.core import (
        load_index_from_storage,
        load_indices_from_storage,
        load_graph_from_storage,
    )

    from llama_index.core.schema import TextNode

    nodes = [
        TextNode(
            text=(
                "Michael Jordan is a retired professional basketball player,"
                " widely regarded as one of the greatest basketball players of all"
                " time."
            ),
            metadata={
                "category": "Sports",
                "country": "United States",
            },
        ),
        TextNode(
            text=(
                "Angelina Jolie is an American actress, filmmaker, and"
                " humanitarian. She has received numerous awards for her acting"
                " and is known for her philanthropic work."
            ),
            metadata={
                "category": "Entertainment",
                "country": "United States",
            },
        ),
        TextNode(
            text=(
                "Elon Musk is a business magnate, industrial designer, and"
                " engineer. He is the founder, CEO, and lead designer of SpaceX,"
                " Tesla, Inc., Neuralink, and The Boring Company."
            ),
            metadata={
                "category": "Business",
                "country": "United States",
            },
        ),
        TextNode(
            text=(
                "Rihanna is a Barbadian singer, actress, and businesswoman. She"
                " has achieved significant success in the music industry and is"
                " known for her versatile musical style."
            ),
            metadata={
                "category": "Music",
                "country": "Barbados",
            },
        ),
        TextNode(
            text=(
                "Cristiano Ronaldo is a Portuguese professional footballer who is"
                " considered one of the greatest football players of all time. He"
                " has won numerous awards and set multiple records during his"
                " career."
            ),
            metadata={
                "category": "Sports",
                "country": "Portugal",
            },
        ),
    ]



    # save index to disk
    index_id = "test_metadata_filter"
    persist_dir = f'/data/output/llamaindex_index_cache/{index_id}'
    from llama_index.core.vector_stores import SimpleVectorStore
    if not os.path.exists(persist_dir):
        # Build Vector Index with Chroma Vector Store
        vector_store = ChromaVectorStore(chroma_collection=chroma_collection,
                                         persist_dir=persist_dir,
                                         )
        storage_context = StorageContext.from_defaults(vector_store=vector_store)
        # index = VectorStoreIndex(nodes, embed_model=embed_model)
        index = VectorStoreIndex(nodes=nodes,
                                 embed_model=embed_model,
                                 storage_context=storage_context)
        index.set_index_id(index_id)
        index.vector_store.persist(persist_dir)
        index.storage_context.persist(persist_dir)
    else:
        from llama_index.core.storage.docstore import SimpleDocumentStore
        from llama_index.core.storage.index_store import SimpleIndexStore
        # rebuild storage context
        storage_context = StorageContext.from_defaults(
            # persist_dir=out_path
            docstore=SimpleDocumentStore.from_persist_dir(persist_dir=persist_dir),
            # vector_store=SimpleVectorStore.from_persist_dir(
            #     persist_dir=persist_dir
            # ),
            vector_store=ChromaVectorStore(
                chroma_collection=chroma_collection,
                persist_dir=persist_dir),
            index_store=SimpleIndexStore.from_persist_dir(persist_dir=persist_dir),
        )
        # load index
        index = load_index_from_storage(
            storage_context=storage_context,
            index_id=index_id,
            embed_model=embed_model
        )

    # Define VectorIndexAutoRetriever
    from llama_index.core.retrievers import VectorIndexAutoRetriever
    from llama_index.core.vector_stores.types import MetadataInfo, VectorStoreInfo

    vector_store_info = VectorStoreInfo(
        content_info="brief biography of celebrities",
        metadata_info=[
            MetadataInfo(
                name="category",
                type="str",
                description=(
                    "Category of the celebrity, one of [Sports, Entertainment,"
                    " Business, Music]"
                ),
            ),
            MetadataInfo(
                name="country",
                type="str",
                description=(
                    "Country of the celebrity, one of [United States, Barbados, Portugal]"
                ),
            ),
        ],
    )
    retriever = VectorIndexAutoRetriever(index=index,
                                         llm=llm,
                                         vector_store_info=vector_store_info)

    # Running over some sample data
    response = retriever.retrieve("Tell me about two celebrities from United States")
    logger.info(response)

    # response = retriever.retrieve("Tell me about Sports celebrities from United States")
    # logger.info(response)


if __name__ == '__main__':
    import sys

    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
    # logging.getLogger().addHandler(logging.StreamHandler(stream=sys.stdout))

    main()
