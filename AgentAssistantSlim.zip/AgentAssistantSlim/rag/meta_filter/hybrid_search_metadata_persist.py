'''
https://docs.llamaindex.ai/en/stable/examples/vector_stores/chroma_auto_retriever/


'''

import logging

# set up OpenAI
import os

os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'
os.environ['NUMEXPR_MAX_THREADS'] = '12'

import getpass

# os.environ["OPENAI_API_KEY"] = getpass.getpass("OpenAI API Key:")
# import openai
# openai.api_key = os.environ["OPENAI_API_KEY"]

import chromadb

from loguru import logger


def main():
    #################### load model ####################
    from llama_index.llms.openai_like import OpenAILike
    llm = OpenAILike(
        # model="Qwen1.5-0.5B-Chat",
        # api_base="http://192.168.150.181:8000/v1",
        model='Mistral-7B-Instruct-v0.2',
        api_base="http://192.168.100.21:8000/v1",
        api_key='EMPTY',
        temperature=0.,
        max_tokens=1000,
    )

    # from llama_index.embeddings.huggingface import HuggingFaceEmbedding
    # embed_model = HuggingFaceEmbedding(
    #     model_name="BAAI/bge-small-en-v1.5",
    # )
    from llama_index.core.embeddings import resolve_embed_model
    embed_model = resolve_embed_model("local:BAAI/bge-small-en-v1.5")

    from llama_index.core import Settings
    Settings.llm = llm
    Settings.embed_model = embed_model
    ####################################################

    import qdrant_client
    from llama_index.vector_stores.qdrant import QdrantVectorStore
    from qdrant_client.http.models import Filter, FieldCondition, MatchValue
    client = qdrant_client.QdrantClient(
        # location=":memory:"
        path='./qdrant_cache'
    )


    # Defining Some Sample Data
    from llama_index.core import VectorStoreIndex, StorageContext
    from llama_index.vector_stores.chroma import ChromaVectorStore
    from llama_index.core import (
        load_index_from_storage,
        load_indices_from_storage,
        load_graph_from_storage,
    )

    from llama_index.core.schema import TextNode

    # nodes = [
    #     TextNode(
    #         text=(
    #             "Michael Jordan is a retired professional basketball player,"
    #             " widely regarded as one of the greatest basketball players of all"
    #             " time."
    #         ),
    #         metadata={
    #             "category": "Sports",
    #             "country": "United States",
    #         },
    #     ),
    #     TextNode(
    #         text=(
    #             "Angelina Jolie is an American actress, filmmaker, and"
    #             " humanitarian. She has received numerous awards for her acting"
    #             " and is known for her philanthropic work."
    #         ),
    #         metadata={
    #             "category": "Entertainment",
    #             "country": "United States",
    #         },
    #     ),
    #     TextNode(
    #         text=(
    #             "Elon Musk is a business magnate, industrial designer, and"
    #             " engineer. He is the founder, CEO, and lead designer of SpaceX,"
    #             " Tesla, Inc., Neuralink, and The Boring Company."
    #         ),
    #         metadata={
    #             "category": "Business",
    #             "country": "United States",
    #         },
    #     ),
    #     TextNode(
    #         text=(
    #             "Rihanna is a Barbadian singer, actress, and businesswoman. She"
    #             " has achieved significant success in the music industry and is"
    #             " known for her versatile musical style."
    #         ),
    #         metadata={
    #             "category": "Music",
    #             "country": "Barbados",
    #         },
    #     ),
    #     TextNode(
    #         text=(
    #             "Cristiano Ronaldo is a Portuguese professional footballer who is"
    #             " considered one of the greatest football players of all time. He"
    #             " has won numerous awards and set multiple records during his"
    #             " career."
    #         ),
    #         metadata={
    #             "category": "Sports",
    #             "country": "Portugal",
    #         },
    #     ),
    # ]

    nodes = []

    from llama_index.core.storage.docstore import SimpleDocumentStore
    from llama_index.core.storage.index_store import SimpleIndexStore
    from llama_index.core.vector_stores import SimpleVectorStore

    # index_id = 'simple_idx'
    # persist_dir = f'/data/output/llamaindex_index_cache/test_metadata_filter'

    # # Build Vector Index with Chroma Vector Store
    # vector_store = ChromaVectorStore(chroma_collection=chroma_collection,
    #                                  persist_dir=persist_dir,
    #                                  )
    # storage_context = StorageContext.from_defaults(vector_store=vector_store)
    # # index = VectorStoreIndex(nodes, embed_model=embed_model)
    # index = VectorStoreIndex(nodes=nodes,
    #                          embed_model=embed_model,
    #                          storage_context=storage_context)
    #
    # index.set_index_id(index_id)
    # # index.vector_store.persist(persist_dir)
    # index.storage_context.persist(persist_dir)
    #
    # # save index to disk
    # persist_dir = f'/data/output/llamaindex_index_cache/test_metadata_filter'
    # if not os.path.exists(persist_dir):
    #     # index = VectorStoreIndex(nodes, embed_model=embed_model)
    #     # index.set_index_id("simple_index")
    #     # index.storage_context.persist(persist_dir)
    #     # chroma_client = chromadb.PersistentClient(path=persist_dir, settings=Settings(
    #     #     anonymized_telemetry=False
    #     # ))
    #     #
    #     # chroma_collection = chroma_client.get_or_create_collection("quickstart")
    #
    #     vector_store = ChromaVectorStore(chroma_collection=chroma_collection,
    #                                      persist_dir=persist_dir)
    #     storage_context = StorageContext.from_defaults(vector_store=vector_store)  # <- here don't specify persist_dir
    #
    #     index = VectorStoreIndex(nodes=nodes,
    #                              embed_model=embed_model,
    #                              storage_context=storage_context,
    #                              show_progress=True
    #                              )
    #     index.set_index_id("simple_index")
    #     index.vector_store.persist(persist_path=persist_dir+'/vector_store_cache')
    #     index.storage_context.persist(persist_dir=persist_dir)
    #
    #     # # create storage context using default stores
    #     # storage_context = StorageContext.from_defaults(
    #     #     docstore=SimpleDocumentStore(),
    #     #     vector_store=SimpleVectorStore(),
    #     #     index_store=SimpleIndexStore(),
    #     # )
    #     #
    #     # # create (or load) docstore and add nodes
    #     # storage_context.docstore.add_documents(nodes)
    #     #
    #     # # build index
    #     # index = VectorStoreIndex(nodes=nodes,
    #     #                          embed_model=embed_model,
    #     #                          storage_context=storage_context)
    #     #
    #     # # save index
    #     # index.set_index_id('simple_idx')
    #     # index.storage_context.persist(persist_dir=persist_dir)
    #     # index.vector_store.persist(persist_path=persist_dir + '/vec_store_cache')
    # else:
    #     # # rebuild storage context
    #     # storage_context = StorageContext.from_defaults(
    #     #     persist_dir=persist_dir,
    #     # )
    #     # # load index
    #     # index = load_index_from_storage(
    #     #     storage_context, index_id="simple_index", embed_model=embed_model
    #     # )
    #     # chroma_client = chromadb.PersistentClient(path=persist_dir, settings=Settings(
    #     #     anonymized_telemetry=False
    #     # ))
    #     # chroma_collection = chroma_client.get_or_create_collection("quickstart")
    #     vector_store = ChromaVectorStore(chroma_collection=chroma_collection,
    #                                      persist_dir=persist_dir)
    #     storage_context = StorageContext.from_defaults(vector_store=vector_store)  # <- here you DO specify persist_dir
    #     index = load_index_from_storage(storage_context=storage_context,
    #                                     index_id='simple_index',
    #                                     persist_dir=persist_dir)
    #
    #     # # Now you can load the index
    #     # index = VectorStoreIndex([],
    #     #                          embed_model=embed_model,
    #     #                          storage_context=storage_context,
    #     #                          )
    #     # create storage context using default stores
    #     # storage_context = StorageContext.from_defaults(
    #     #     docstore=SimpleDocumentStore(),
    #     #     vector_store=SimpleVectorStore(),
    #     #     index_store=SimpleIndexStore(),
    #     # )
    #     #
    #     # index = load_index_from_storage(storage_context,
    #     #                                 index_id='simple_idx',
    #     #                                 persist_dir=persist_dir)

    vector_store = QdrantVectorStore(
        client=client, collection_name="metafilter_collection"
    )
    storage_context = StorageContext.from_defaults(vector_store=vector_store)
    index = VectorStoreIndex(nodes,
                             storage_context=storage_context)

    # Define VectorIndexAutoRetriever
    from llama_index.core.retrievers import VectorIndexAutoRetriever
    from llama_index.core.vector_stores.types import MetadataInfo, VectorStoreInfo

    vector_store_info = VectorStoreInfo(
        content_info="brief biography of celebrities",
        metadata_info=[
            MetadataInfo(
                name="category",
                type="str",
                description=(
                    "Category of the celebrity, one of [Sports, Entertainment,"
                    " Business, Music]"
                ),
            ),
            MetadataInfo(
                name="country",
                type="str",
                description=(
                    "Country of the celebrity, one of [United States, Barbados, Portugal]"
                ),
            ),
        ],
    )
    # retriever = VectorIndexAutoRetriever(index=index,
    #                                      llm=llm,
    #                                      vector_store_info=vector_store_info)

    # retriever = index.as_retriever()

    # filters = Filter(
    #     should=[
    #         Filter(
    #             must=[
    #                 FieldCondition(
    #                     key="fruit",
    #                     match=MatchValue(value="apple"),
    #                 ),
    #                 FieldCondition(
    #                     key="city",
    #                     match=MatchValue(value="Tokyo"),
    #                 ),
    #             ]
    #         ),
    #         Filter(
    #             must=[
    #                 FieldCondition(
    #                     key="fruit",
    #                     match=MatchValue(value="grape"),
    #                 ),
    #                 FieldCondition(
    #                     key="city",
    #                     match=MatchValue(value="Toronto"),
    #                 ),
    #             ]
    #         ),
    #     ]
    # )

    from llama_index.core.vector_stores import MetadataFilters, ExactMatchFilter
    filters = MetadataFilters(
        filters=[
            ExactMatchFilter(key="country", value='United States')
        ]
    )
    # filters = MetadataFilters.from_dict({"source": "24"})

    from llama_index.core.indices.vector_store.retrievers import VectorIndexRetriever
    retriever = VectorIndexRetriever(index=index,
                                     similarity_top_k=10,
                                     vector_store_info=vector_store_info,
                                     filters=filters,
                                     )

    # Running over some sample data
    response = retriever.retrieve("Tell me about two celebrities from United States")
    logger.info(response)

    for idx, node in enumerate(response):
        print(f'############# {idx} ############')
        print("node", node.score)
        print("node", node.text)
        print("node", node.metadata)
        # print(
        #         "\n----------------\n"
        #         f"[Node ID {node.node_id}] Similarity: {node.score}\n\n"
        #         f"{node.get_content(metadata_mode='all')}"
        #         "\n----------------\n\n"
        #     )

    # response = retriever.retrieve("Tell me about Sports celebrities from United States")
    # logger.info(response)

    # query_obj = VectorStoreQuery(
    #     query_embedding=query_embedding, similarity_top_k=2
    # )
    #
    # query_result = vector_store.query(query_obj)
    # for similarity, node in zip(query_result.similarities, query_result.nodes):
    #     print(
    #         "\n----------------\n"
    #         f"[Node ID {node.node_id}] Similarity: {similarity}\n\n"
    #         f"{node.get_content(metadata_mode='all')}"
    #         "\n----------------\n\n"
    #     )


if __name__ == '__main__':
    import sys

    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
    # logging.getLogger().addHandler(logging.StreamHandler(stream=sys.stdout))

    main()
