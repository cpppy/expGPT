
'''
https://docs.llamaindex.ai/en/stable/examples/agent/Chatbot_SEC/

'''


def load_data():
    from llama_index.readers.file import UnstructuredReader
    from pathlib import Path

    years = [2022, 2021, 2020, 2019]

    loader = UnstructuredReader()
    doc_set = {}
    all_docs = []
    for year in years:
        year_docs = loader.load_data(
            file=Path(f"./data/UBER/UBER_{year}.html"), split_documents=False
        )
        # insert year metadata into each year
        for d in year_docs:
            d.metadata = {"year": year}
        doc_set[year] = year_docs
        all_docs.extend(year_docs)


def get_embeddings(years, doc_set):

    from llama_index.embeddings.huggingface import HuggingFaceEmbedding

    # initialize simple vector indices
    # NOTE: don't run this cell if the indices are already loaded!
    from llama_index.core import VectorStoreIndex, StorageContext
    # from llama_index.embeddings.openai import OpenAIEmbedding
    from llama_index.llms.openai import OpenAI
    from llama_index.core import Settings

    Settings.chunk_size = 512
    Settings.chunk_overlap = 64
    Settings.llm = OpenAI(model="gpt-3.5-turbo")
    # Settings.embed_model = OpenAIEmbedding(model="text-embedding-3-small")

    from llama_index.embeddings.huggingface import HuggingFaceEmbedding
    from llama_index.core import Settings

    Settings.embed_model = HuggingFaceEmbedding(
        model_name="BAAI/bge-small-en-v1.5"
    )

    index_set = {}
    for year in years:
        storage_context = StorageContext.from_defaults()
        cur_index = VectorStoreIndex.from_documents(
            doc_set[year],
            storage_context=storage_context,
        )
        index_set[year] = cur_index
        storage_context.persist(persist_dir=f"./storage/{year}")


def load_vec_store(years):
    from llama_index.core import VectorStoreIndex, StorageContext
    # Load indices from disk
    from llama_index.core import load_index_from_storage

    index_set = {}
    for year in years:
        storage_context = StorageContext.from_defaults(
            persist_dir=f"./storage/{year}"
        )
        cur_index = load_index_from_storage(
            storage_context,
        )
        index_set[year] = cur_index



