import os

os.environ['NUMEXPR_MAX_THREADS'] = '12'
os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'

from llama_index.core.schema import IndexNode

from llama_index.core.retrievers import VectorIndexAutoRetriever
from llama_index.core.vector_stores.types import MetadataInfo, VectorStoreInfo

from llama_index.core import VectorStoreIndex, SimpleDirectoryReader

import logging
import sys
from llama_index.core import SimpleDirectoryReader
from llama_index.core import SummaryIndex


def load_model():
    #################### load model ####################
    from llama_index.llms.openai_like import OpenAILike
    llm = OpenAILike(
        # model="Qwen1.5-0.5B-Chat",
        # api_base="http://192.168.150.181:8000/v1",
        model='Mistral-7B-Instruct-v0.2',
        api_base="http://192.168.100.21:8000/v1",
        api_key='EMPTY',
        temperature=0.,
        max_tokens=4096,
    )

    # from llama_index.embeddings.huggingface import HuggingFaceEmbedding
    # embed_model = HuggingFaceEmbedding(
    #     model_name="BAAI/bge-small-en-v1.5",
    # )
    from llama_index.core.embeddings import resolve_embed_model
    embed_model = resolve_embed_model("local:BAAI/bge-small-en-v1.5")

    from llama_index.core import Settings
    Settings.llm = llm
    Settings.embed_model = embed_model
    ####################################################
    return llm, embed_model

'''
https://docs.llamaindex.ai/en/latest/examples/retrievers/auto_vs_recursive_retriever/

'''

def main():

    ############################ load data #########################
    city_names = ["Boston", "Chicago", "Seattle", "Toronto"]
    city_metadatas = {
        "Boston": {
            "type": "commerce",
            "country": "USA",
        },
        "Chicago": {
            "type": "industry",
            "country": "USA",
        },
        "Seattle": {
            "type": "tourism",
            "country": "USA",
        },
        "Toronto": {
            "type": "commerce",
            "country": "USA",
        },
    }

    from pathlib import Path

    # Load all wiki documents
    docs_dict = {}
    for city_name in city_names:
        doc = SimpleDirectoryReader(
            input_files=[f"../doc_summary/data/{city_name}.txt"]
        ).load_data()[0]

        doc.metadata.update(city_metadatas[city_name])
        docs_dict[city_name] = doc

    ##########################################################

    from llama_index.core.callbacks import LlamaDebugHandler, CallbackManager
    from llama_index.core.node_parser import SentenceSplitter

    llm, embed_model = load_model()
    callback_manager = CallbackManager([LlamaDebugHandler()])
    splitter = SentenceSplitter(chunk_size=256)


    ####################### Build Recursive Retriever over Document Summaries ######################

    # define top-level nodes and vector retrievers
    nodes = []
    vector_query_engines = {}
    vector_retrievers = {}

    for city_name in city_names:
        # build vector index
        vector_index = VectorStoreIndex.from_documents(
            [docs_dict[city_name]],
            transformations=[splitter],
            callback_manager=callback_manager,
            show_progress=True,
        )
        # define query engines
        vector_query_engine = vector_index.as_query_engine(llm=llm)
        vector_query_engines[city_name] = vector_query_engine
        vector_retrievers[city_name] = vector_index.as_retriever(similarity_top_k=5)

        # save summaries
        out_path = Path("summaries") / f"{city_name}.txt"
        if not out_path.exists():
            # use LLM-generated summary
            summary_index = SummaryIndex.from_documents(
                documents=[docs_dict[city_name]],
                callback_manager=callback_manager
            )

            summarizer = summary_index.as_query_engine(
                response_mode="tree_summarize", llm=llm
            )
            response = summarizer.query(
                f"Give me a summary of {city_name}"
            )
            logging.debug(f'summary: {response}')
            wiki_summary = response.response
            Path("summaries").mkdir(exist_ok=True)
            with open(out_path, "w") as fp:
                fp.write(wiki_summary)
        else:
            with open(out_path, "r") as fp:
                wiki_summary = fp.read()

        print(f"**Summary for {city_name}: {wiki_summary}")
        node = IndexNode(text=wiki_summary, index_id=city_name)
        nodes.append(node)

    # define top-level retriever
    top_vector_index = VectorStoreIndex(
        nodes, transformations=[splitter], callback_manager=callback_manager
    )
    top_vector_retriever = top_vector_index.as_retriever(similarity_top_k=1)

    # define recursive retriever
    from llama_index.core.retrievers import RecursiveRetriever
    from llama_index.core.query_engine import RetrieverQueryEngine
    from llama_index.core import get_response_synthesizer

    # note: can pass `agents` dict as `query_engine_dict` since every agent can be used as a query engine
    recursive_retriever = RecursiveRetriever(
        "vector",
        retriever_dict={"vector": top_vector_retriever, **vector_retrievers},
        # query_engine_dict=vector_query_engines,
        verbose=True,
    )

    # run recursive retriever
    nodes = recursive_retriever.retrieve(
        "Tell me about the city which is the capital and most populous city in Massachusetts"
    )

    print(f'############# selected node #############')
    for i, node in enumerate(nodes):
        print(f'######### nodel_{i} #########')
        print(node.node.get_content())


if __name__=='__main__':

    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)

    main()


