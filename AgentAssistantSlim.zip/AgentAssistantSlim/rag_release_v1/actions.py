from typing import (
    Dict,
    Any,
    Set,
    List,
    Tuple,NamedTuple
)

from router_qp.define_component_v3_branch import DecisionComponent


## add action
class DecisionComponent_Fruit(DecisionComponent):

    # @property
    # def _output_keys(self) -> Set[str]:
    #     """Output keys."""
    #     return {'output', 'is_done'}

    def _run_component(self, **kwargs: Any) -> Dict:
        """Run component."""
        # AgentChatResponse(response_dict["response_str"])
        print(f'[decision component] kwargs: {kwargs}')
        return {'output': dict(response_str=f'SubPath of component: {self.__class__.__name__}.', is_done=True)}

class DecisionComponent_Other(DecisionComponent):

    # @property
    # def _output_keys(self) -> Set[str]:
    #     """Output keys."""
    #     return {'output', 'is_done'}

    def _run_component(self, **kwargs: Any) -> Dict:
        """Run component."""
        print(f'[decision component] kwargs: {kwargs}')

        # return {'output': f'SubPath of component: {self.__class__.__name__}.', 'is_done': True}
        return {'output': dict(response_str=f'SubPath of component: {self.__class__.__name__}.', is_done=True)}




## add action
class ActionComponentRAG(DecisionComponent):

    # @property
    # def _output_keys(self) -> Set[str]:
    #     """Output keys."""
    #     return {'output', 'is_done'}

    def _run_component(self, **kwargs: Any) -> Dict:
        """Run component."""
        # AgentChatResponse(response_dict["response_str"])
        print(f'[decision component] kwargs: {kwargs}')
        return {'output': dict(response_str=f'SubPath of component: {self.__class__.__name__}.', is_done=True)}
