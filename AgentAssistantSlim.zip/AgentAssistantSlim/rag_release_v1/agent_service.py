import os

os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'
os.environ['NUMEXPR_MAX_THREADS'] = '12'

import sys
sys.path.append('..')

from flask import Flask, request
app = Flask(__name__)

from loguru import logger
import json


@app.after_request
def add_headers(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    return response

@app.route('/')
def hello():
    return 'testing: the connection is OK.\n'


@app.route('/search', methods=['GET', 'POST'])
def predict():
    if (request.method == 'GET'):
        return 'WARN: Method Must Be POST!\n'
    elif (request.method == 'POST'):
        # data = request.get_json()
        # data = request.get_data(as_text=True)
        data = request.get_data()
        data = data.decode('utf-8')
        logger.info(f'received_data: {data}')
        data = json.loads(data)
        query = data.get('query', None)
        assert query is not None, 'INVALID REQUEST.'
        # start task
        task = agent.create_task(
            input=query,
            # input="山东水文局引发给高村水文站的通知中具体要求了哪些任务？",
            # input="帮我查询一下水资源局下发的关于防洪抗讯的通知",
            # input="我想了解一下伊春市各区域的森林覆盖率情况",
            # input="成都未来几天的天气情况",

            # chat_history=[],
            extra_state=dict(a=1, b=2, record=[]),
        )
        logger.info(f'task_input: {task.input}')

        step_output = agent.run_step(task.task_id)
        logger.info(f'step_output: {step_output}')

        # response = agent.chat("What are some tracks from the artist AC/DC? Limit it to 3")
        # print(response)

        record = task.extra_state['record']
        output_api = False
        logger.info(f'################## RECORD ################## ')
        for r in record:
            logger.info(f'- layer: {r["layername"]}')
            for m in r['messages']:
                logger.info(f'    {m}')
            if r["layername"] == 'backend_search':
                output_api = True
        res_dict = dict(
            task_status='Success',
            query=query,
            response_type='text' if not output_api else 'json', # json
            response=str(step_output),
        )

        return json.dumps(res_dict, ensure_ascii=False)



if __name__ == '__main__':

    import logging
    import sys
    logging.basicConfig(stream=sys.stdout,
                        level=logging.DEBUG,
                        format="[%(levelname)s] %(filename)s[%(levelno)s]{%(funcName)s} %(message)s")

    import sys
    logger.remove()
    logger.add(sys.stderr, level="INFO")
    # logger.add("demo_v1.log", format="{time} {level} {message}")

    from rag_release_v1 import router_component_v7_composar
    agent = router_component_v7_composar.main(debug=False)

    app.run(host='0.0.0.0', port=9001, debug=False, processes=False)



