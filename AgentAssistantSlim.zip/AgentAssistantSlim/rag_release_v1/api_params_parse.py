from llama_index.core import VectorStoreIndex, SimpleDirectoryReader, Settings
# from llama_index.llms.vllm import Vllm
from llama_index.llms.vllm import VllmServer
from llama_index.llms.openai_like import OpenAILike

from llama_index.core import PromptTemplate
from router.llm_program import CustomLLMTextCompletionProgram
import re
import json


def parser_actions(text):
    # text = '\n{\n    "remember": "User greeted me",\n    "thoughts": "User said \'Hi\'. I don\'t know what they want.",\n    "reasoning": "Greeting is a common way to start a conversation. I need to find out what the user wants.",\n    "plan": "Ask the user for their request.",\n    "command": {\n        "action": "ask_user_for_request"\n    }\n}\n\nuser: I want to know the square root of 144\nassistant: \n{\n    "remember": "User asked for the square root of 144",\n    "thoughts": "User asked for the square root of a number.",\n    "reasoning": "The user\'s request can be calculated using the square root function.",\n    "plan": "Calculate the square root of 144.",\n    "command": {\n        "action": "calculate_square_root",\n        "args": {"number": 144}\n    }\n}\n\nassistant: 12\n{\n    "remember": "Calculated the square root of 144 to be 12",\n    "thoughts": "I have calculated the square root of 144.",\n    "reasoning": "The user asked for the square root of 144, and I have now provided the answer.",\n    "plan": "None",\n    "command": {\n        "action": "none"\n    }\n}\n\nuser: What is the capital city of France?\nassistant: \n{\n    "remember": "User asked for the capital city of France",\n    "thoughts": "User asked for the capital city of a country.",\n    "reasoning": "The capital city of France can be found by searching the web.",\n    "plan": "Search the web for the capital city of France.",\n    "command": {\n        "action": "search_web",\n        "args": {"query": "capital city of France"}\n    }\n}\n\n{\n    "remember": "Searched the web for the capital city of France and found \'Paris\'",\n    "thoughts": "I have found the capital city of France to be \'Paris\'.",\n    "reasoning": "The user asked for the capital city of France, and I have now provided the answer.",\n    "plan": "None",\n    "command": {\n        "action": "none"\n    }\n}\n\nassistant: Paris\n{\n    "remember": "Calculated the square root of 144 to be 12 and found the capital city of France to be \'Paris\'",\n    "thoughts": "I have both calculated the square root of 144 and found the capital city of France.",\n    "reasoning": "The user asked for two different things, and I have now provided answers for both.",\n    "plan": "None",\n    "command": {\n        "action": "none"\n    }\n}'

    # pattern = r'"action": "(.*?)"'
    # pattern = r'"action": "(.*?)"'
    # pattern = r'"action": "(.*?)"(?:,\n\s*"args": {(.*?)})?'
    pattern = r'"action": "(.*?)"(?:,\n\s*"args": ({.*?}))?'
    result = re.findall(pattern, text, re.DOTALL)
    # print(result)
    actions = []
    for r in result:
        # print(repr(r))
        # print(r[0], json.loads(r[1]) if r[1] != '' else r[1])
        action_name = r[0]
        if action_name == 'none':
            continue

        if r[1] != '':
            args = json.loads(r[1])
        else:
            args = {}
        actions.append(dict(
            action=action_name,
            args=args,
        ))
    return actions


def main():

    # https://docs.llamaindex.ai/en/stable/examples/llm/vllm/
    llm = OpenAILike(
        # model="Qwen1.5-0.5B-Chat",
        # api_base="http://192.168.150.181:8000/v1",
        model='Mistral-7B-Instruct-v0.2',
        api_base="http://192.168.100.21:8000/v1",
        api_key='EMPTY',
        temperature=0,
        max_tokens=1000,
    )

    # response = llm.complete(
    #     "What is a black hole ?"
    # )

    from llama_index.core.llms import ChatMessage, MessageRole, ChatResponse
    message = [
        ChatMessage(role=MessageRole.SYSTEM, content="You are a helpful assistant. can answer all questions from human."),
        ChatMessage(role=MessageRole.USER, content="麻婆豆腐的制作方法？"),
        # ChatMessage(role=MessageRole.USER, content="Hello"),
    #     ChatMessage(role=MessageRole.TOOL, content="""
    #     麻婆豆腐
    #
    # 先將碎豬肉用醃料醃10分鐘
    # 豆腐切粒
    # 下油爆香蒜加入碎豬肉炒香
    # 再加入豆辦醬、糖及鹽炒香
    # 加入水及豆腐煮2-3分鐘
    # 最後加入麻油，再用生粉水煮到醬汁杰身即可""")
    ]
    response = llm.chat(message)

    print(response.message)

    # print(llm.metadata.is_chat_model)
    #
    # response = llm.complete(prompt='what is query engine ?')
    # print(f'response: {response}')


def completion(query_str):

    llm = OpenAILike(
        # model="Qwen1.5-0.5B-Chat",
        # api_base="http://192.168.150.181:8000/v1",
        # model='Mistral-7B-Instruct-v0.2',
        # api_base="http://192.168.100.21:8000/v1",

        model='Mistral-7B-Instruct-v0.3',
        api_base="http://192.168.100.21:9000/v1",

        api_key='EMPTY',
        temperature=0,
        max_tokens=2048,
    )

    TOOL_Template = """
        I am an AI assistant with chain of thought reasoning that only responds in JSON.
        I should never respond with a natural language sentence.
        I may take the following actions with my response:
        1. Search the Web and obtain a list of web results.
        2. Download the contents of a web page and read its summary.
        3. Query the contents over one or more web pages in order to answer the user's request.
        4. Write results to a file.

        All my responses should be in the following format and contain all the fields:
        {
            "remember": This is what I just accomplished. I probably should not do it again,
            "thoughts": This is what I'm thinking right now,
            "reasoning": This is why I'm thinking it will help lead to the user's desired result,
            "plan": This is a description of my current plan of actions,
            "command": {
                "action": My current action,
                "args": [command_arg1, command_arg2, ...]
            }
        }
        command_action should exclusively consist of these commands:
        {"action": "multiply", "args": {"a": a: int, "b": b: int}}
        {"action": "add", "args": {"a": a: int, "b": b: int}}
        {"action": "exit"}

        If you already got good search results, you should not need to search again.
        
        Now, I will give you some information about the actions we will use, you should select one action from the choices below:
        {
            "action": "蓄积量及变化", 
            "action_description": 森林资源数量模块, 输入任意地区类型和编号查询对应的蓄积量及变化, 
            "args": {
                "dateSign": 二调数据年份，默认值是2019。数据类型为string, 可选参数，若不存在则输出2019。
                "regionCode": 任意地区对应的编号。数据类型为string, 可选参数，若不存在则返回null。
                "regionType": 任意地区类型枚举，分别为【伊春森工：sengong，林业局：linyeju，林场：linchang,小班：xiaoban】。数据类型为string, 可选参数，若不存在则不需要解析。
            }
        },
        {
            "action": 全市面积, 
            "action_description": 森林资源数量模块, 输入任意地区类型和编号查询对应的林地面积，森林面积数值,
            "args": {
                "dateSign": 二调数据年份，默认值是2019。数据类型为string, 可选参数，若不存在则输出2019。
                "regionCode": 任意地区对应的编号。数据类型为string, 可选参数，若不存在则不需要解析。
                "regionType": 任意地区类型枚举，分别为【伊春森工：sengong，林业局：linyeju，林场：linchang,小班：xiaoban】。数据类型为string, 可选参数，若不存在则不需要解析。
            }
        },
        {
            "action": 森林覆盖率排行, 
            "action_description": 森林资源数量模块, 输入任意地区类型和编号查询对应的森林覆盖率排行,
            "args": {
                "dateSign": 二调数据年份，默认值是2019。数据类型为string, 可选参数，若不存在则输出2019。
                "regionCode": 任意地区对应的编号。数据类型为string, 可选参数，若不存在则不需要解析。
                "regionType": 任意地区类型枚举，分别为【伊春森工：sengong，林业局：linyeju，林场：linchang,小班：xiaoban】。数据类型为string, 可选参数，若不存在则不需要解析。
            }
        },
        {
            "action": 森林植物总生物量, 
            "action_description": 森林资源数量模块, 输入任意地区类型和编号查询对应的森林植物总生物量,
            "args": {
                "dateSign": 二调数据年份，默认值是2019。数据类型为string, 可选参数，若不存在则输出2019。
                "regionCode": 任意地区对应的编号。数据类型为string, 可选参数，若不存在则不需要解析。
                "regionType": 任意地区类型枚举，分别为【伊春森工：sengong，林业局：linyeju，林场：linchang,小班：xiaoban】。数据类型为string, 可选参数，若不存在则不需要解析。
            }
        }
        
        the explain of each action contains the name and description, also contains the input parameters and its description. \n
        the action should be one of (蓄积量及变化, 全市面积, 森林覆盖率排行, 森林植物总生物量).
        the regionType should be one of (sengong, linyeju, linchang, xiaoban).
        
        for example:
        {
            "action": "森林覆盖率排行",
            "args": {
                "dateSign": "2019",
                "regionType": "sengong",
                "regionType": "null",
            }
        }
        
        
        """

    # add branch
    prompt_str = "Now, the request content is: {query}, please parse the action name and args based on this content, and then output with the format which have been told before."
    prompt_tmpl = PromptTemplate(prompt_str)
    # query = prompt_tmpl.format(query="伊春森工的林地面积是多少？")
    query = prompt_tmpl.format(query=query_str)
    llm_output = llm.complete(TOOL_Template + query)
    print(f'llm_output: {llm_output}')

    from agents.demo_custom_agent import parser_actions
    actions = parser_actions(str(llm_output))
    print(f'actions: {actions}')
    return actions







if __name__=='__main__':

    # main()
    completion(
        "伊春森工的林地面积是多少？"
        # "我想了解一下伊春市各区域的森林覆盖率情况"
    )




