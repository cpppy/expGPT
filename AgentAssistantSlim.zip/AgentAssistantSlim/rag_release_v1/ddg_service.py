import requests
import json


'''
https://github.com/deedy5/duckduckgo_search

'''

class DuckDuckGoSearchAPI:
    '''
    https://stackoverflow.com/questions/37012469/duckduckgo-api-getting-search-results
    '''

    def __init__(self):
        self.search_url = 'http://www.autounit.cn:8002/duckduckgo_api'
        self.api_key = 'cdfw5dfs53ej8f2s55624702dfp'

    def __call__(self, query):
        data = dict(
            query=query,
            api_key=self.api_key,
        )
        # print(data)
        data = str(json.dumps(data))
        aheaders = {'Content-Type': 'application/json'}
        response = requests.post(self.search_url, headers=aheaders, data=data)
        print(f'seach_response: {response.text}')
        results = json.loads(response.text)

        print('---------------------- web search START ------------------')
        print(f'[QUERY] {query}')
        for i, x in enumerate(results):
            print(f'    [RESULT {i}], {x}')
        print('---------------------- web search END ------------------')
        return results


    def call_for_agent(self, query):
        results = self.__call__(query)
        result_arr = []
        result_str = ""
        for item in results:
            title = item["title"]
            description = item["body"]
            item_str = f"{title}: {description}"
            result_arr = result_arr + [item_str]
        if len(result_arr) > 0:
            result_str = "\n".join(result_arr)
        return result_str

    def search(self, query):
        return self.call_for_agent(query)

    def search_v2(self, query):
        results = self.__call__(query)
        result_arr = []
        result_str = ""
        for item in results:
            title = item["title"]
            description = item["body"]
            item_str = f"{title}: {description}"
            result_arr = result_arr + [item_str]
        if len(result_arr) > 0:
            result_str = "\n".join(result_arr)
        # return result_str

        # result_display
        result_vis = []
        result_vis.append('--------------------- web search ------------------')
        result_vis.append(f'[QUERY] {query}')
        for i, x in enumerate(results):
            result_vis.append(f'    [RESULT {i}], {x}')
        result_vis_str = '\n'.join(result_vis)

        return dict(result_raw=results,
                    result_str=result_str,
                    result_vis_str=result_vis_str)



if __name__ == '__main__':

    search_api = DuckDuckGoSearchAPI()

    query = "duckduckgo"
    response = search_api.search_v2(query)
    print(response['result_vis_str'])



