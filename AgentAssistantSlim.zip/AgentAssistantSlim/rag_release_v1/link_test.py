import requests
import json
import sys
sys.path.append('../')


def link_test():

    data = dict(
        # query="高村水文站流量测验的相关人员有哪些？分别对应哪些任务？",
        query='泺口水文站的水沙特性是什么样的？',
        # query="山东水文局引发给高村水文站的通知中具体要求了哪些任务？",
        # query="帮我查询一下水资源局下发的关于防洪抗讯的通知",
        # query="我想了解一下伊春市各区域的森林覆盖率情况",
        # query="伊春森工的林地面积是多少？",
        # query="成都火车站到机场有没有地铁直达?",
        # query="成都明天的天气情况怎么样？",
        # query="伊春林区将来会使用哪些措施提升林区生态？",
        # query="伊春林业白皮书中提到了哪些措施来提升林区生态？",
        # query="伊春林业生态规划包含哪些内容？",
        # query='伊春森工的林地面积是多少？'
    )
    print(f'<-- [Request] {data}')
    data = json.dumps(data, ensure_ascii=False).encode('utf-8')

    aheaders = {'Content-Type': 'application/json'}
    url = 'http://127.0.0.1:9001/search'
    # url = 'http://192.168.100.24:9009/search'
    response = requests.post(url, headers=aheaders, data=data)
    print(f'--> [Response] {response.text}')



def link_test_sensitive_words():

    data = dict(
        text="高村水文站流量测验的相关人员有哪些", #？分别对应哪些任务？"
    )
    print(f'<-- [Request] {data}')
    # data = json.dumps(data)
    data = json.dumps(data, ensure_ascii=False).encode('utf-8')

    aheaders = {'Content-Type': 'application/json'}
    url = 'http://192.168.100.24:5252/filter'
    response = requests.post(url, headers=aheaders, data=data)
    print(f'--> [Response] {response.json()}')


if __name__ == '__main__':

    # link_test()
    link_test_sensitive_words()

