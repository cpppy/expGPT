


def load_model():
    from llama_index.core import Settings
    if Settings._llm is not None:
        llm = Settings._llm
    else:
        # Building Hybrid Retrieval with Chunk Embedding + Parent Embedding
        from llama_index.llms.openai_like import OpenAILike
        llm = OpenAILike(
            # model="Qwen1.5-0.5B-Chat",
            # api_base="http://192.168.150.181:8000/v1",
            # model='Mistral-7B-Instruct-v0.2',
            # api_base="http://192.168.100.21:8000/v1",

            model='Mistral-7B-Instruct-v0.3',
            api_base="http://192.168.100.21:9000/v1",

            api_key='EMPTY',
            temperature=0.,
            max_tokens=2048,
        )
        Settings._llm = llm

    if Settings._embed_model is not None:
        embed_model = Settings._embed_model
    else:
        from llama_index.embeddings.huggingface import HuggingFaceEmbedding
        embed_model = HuggingFaceEmbedding(
            model_name="BAAI/bge-large-zh-v1.5",
            device='cpu',
        )
        Settings._embed_model = embed_model
    return llm, embed_model

