from llama_index.core.vector_stores.types import VectorStore
from llama_index.core.vector_stores import (
    VectorStoreQuery,
    VectorStoreQueryResult,
)
from typing import List, Any, Optional, Dict
from llama_index.core.schema import TextNode, BaseNode
import os
from tqdm import tqdm
import pickle

from llama_index.core.vector_stores import MetadataFilters
from llama_index.core.schema import BaseNode
from typing import cast


class BaseVectorStore(VectorStore):
    """Simple custom Vector Store.

    Stores documents in a simple in-memory dict.

    """
    stores_text: bool = True

    def get(self, text_id: str) -> List[float]:
        """Get embedding."""
        pass

    def add(self,
            nodes: List[BaseNode],
            ) -> List[str]:
        """Add nodes to index."""
        pass

    def delete(self, ref_doc_id: str, **delete_kwargs: Any) -> None:
        """
        Delete nodes using with ref_doc_id.

        Args:
            ref_doc_id (str): The doc_id of the document to delete.

        """
        pass

    def query(
            self,
            query: VectorStoreQuery,
            **kwargs: Any,
    ) -> VectorStoreQueryResult:
        """Get nodes for response."""
        pass

    def persist(self, persist_path, fs=None) -> None:
        """Persist the SimpleVectorStore to a directory.

        NOTE: we are not implementing this for now.

        """
        pass


class CustomVectorStore(BaseVectorStore):
    """VectorStore2 (add/get/delete implemented)."""

    stores_text: bool = True

    def __init__(self) -> None:
        """Init params."""
        self.node_dict: Dict[str, BaseNode] = {}

    def get(self, text_id: str) -> List[float]:
        """Get embedding."""
        return self.node_dict[text_id]

    def add(
            self,
            nodes: List[BaseNode],
    ) -> List[str]:
        """Add nodes to index."""
        for node in nodes:
            self.node_dict[node.node_id] = node

    def delete(self, node_id: str, **delete_kwargs: Any) -> None:
        """
        Delete nodes using with node_id.

        Args:
            node_id: str

        """
        del self.node_dict[node_id]

    def persist(self, persist_path, fs=None):
        with open(persist_path, 'wb') as f:
            pickle.dump(self.node_dict, f)
        print(f'dataset persisted in {persist_path}')

    def restore(self, persist_path, fs=None):
        node_dict = []
        with open(persist_path, 'rb') as f:
            node_dict = pickle.load(f)
        self.node_dict = node_dict
        print(f'dataset persisted in {persist_path}')


from typing import Tuple
import numpy as np


def get_top_k_embeddings(
        query_embedding: List[float],
        doc_embeddings: List[List[float]],
        doc_ids: List[str],
        similarity_top_k: int = 5,
) -> Tuple[List[float], List]:
    """Get top nodes by similarity to the query."""
    # dimensions: D
    qembed_np = np.array(query_embedding)
    # dimensions: N x D
    dembed_np = np.array(doc_embeddings)
    # dimensions: N
    dproduct_arr = np.dot(dembed_np, qembed_np)
    # dimensions: N
    norm_arr = np.linalg.norm(qembed_np) * np.linalg.norm(
        dembed_np, axis=1, keepdims=False
    )
    # dimensions: N
    cos_sim_arr = dproduct_arr / norm_arr

    # now we have the N cosine similarities for each document
    # sort by top k cosine similarity, and return ids
    tups = [(cos_sim_arr[i], doc_ids[i]) for i in range(len(doc_ids))]
    sorted_tups = sorted(tups, key=lambda t: t[0], reverse=True)

    sorted_tups = sorted_tups[:similarity_top_k]

    result_similarities = [s for s, _ in sorted_tups]
    result_ids = [n for _, n in sorted_tups]
    return result_similarities, result_ids


def filter_nodes(nodes: List[BaseNode], filters: MetadataFilters):
    filtered_nodes = []
    for node in nodes:
        matches = True
        for f in filters.filters:
            if f.key not in node.metadata:
                matches = False
                continue
            if f.value != node.metadata[f.key]:
                matches = False
                continue
        if matches:
            filtered_nodes.append(node)
    return filtered_nodes


def dense_search(query: VectorStoreQuery, nodes: List[BaseNode]):
    """Dense search."""
    query_embedding = cast(List[float], query.query_embedding)
    doc_embeddings = [n.embedding for n in nodes]
    doc_ids = [n.node_id for n in nodes]
    return get_top_k_embeddings(
        query_embedding,
        doc_embeddings,
        doc_ids,
        similarity_top_k=query.similarity_top_k,
    )


class HybridSearchVectorStore(CustomVectorStore):
    """Implements Metadata Filtering."""
    def __init__(self, llm):
        super(HybridSearchVectorStore, self).__init__()
        self.llm = llm

    def query(
            self,
            query: VectorStoreQuery,
            **kwargs: Any,
    ) -> VectorStoreQueryResult:
        """Get nodes for response."""
        # 1. First filter by metadata
        nodes = self.node_dict.values()
        if query.filters is not None:
            nodes = filter_nodes(nodes, query.filters)
        else:
            # build filter
            from rag_release_v1.analyze_meta_parse import ExtractShuiwenMetadata
            extract_meta_func = ExtractShuiwenMetadata(llm=self.llm)
            meta_info = extract_meta_func(query.query_str)
            print(f'meta_info from query: {meta_info}')
            # meta_data = dict(
            #     year=meta_info.year,
            #     location=meta_info.location,
            #     document_type=meta_info.document_type
            # )
            filters = MetadataFilters.from_dict({"location": meta_info.location})
            nodes = filter_nodes(nodes, filters)

        if len(nodes) == 0:
            result_nodes = []
            similarities = []
            node_ids = []
        else:
            # 2. Then perform semantic search
            similarities, node_ids = dense_search(query, nodes)
            result_nodes = [self.node_dict[node_id] for node_id in node_ids]
            # result_nodes = []
            # for score, node_id in zip(similarities, node_ids):
            #     node = self.node_dict[node_id]
            #     node.score = score
            #     result_nodes.append(node)

        return VectorStoreQueryResult(
            nodes=result_nodes, similarities=similarities, ids=node_ids
        )


def main(debug=False):
    from rag_release_v1.load_model import load_model
    llm, embed_model = load_model()

    # test_node = TextNode(id_="id1", text="hello world")
    # test_node2 = TextNode(id_="id2", text="foo bar")
    # test_nodes = [test_node, test_node2]

    # vector_store = CustomVectorStore()
    vector_store = HybridSearchVectorStore(llm=llm)
    # vector_store.llm = llm

    # persist_path = 'test_custom_vectorstore_cache_v2.pkl'
    persist_path = '/data/AgentAssistant/rag_release_v1/metafilter/test_custom_vectorstore_cache_v2.pkl'
    if os.path.exists(persist_path):
        vector_store.restore(persist_path)
    else:
        from rag_release_v1.metafilter import load_chunks
        nodes = load_chunks.main()

        # generate embedding
        for node in tqdm(nodes, desc='get_embedding'):
            # print(node.get_content(metadata_mode="all"))
            # print(f'content: {node.get_content()}')
            # exit(0)
            node_embedding = embed_model.get_text_embedding(
                # node.get_content(metadata_mode="all")
                node.get_content(),
            )
            node.embedding = node_embedding
        vector_store.add(nodes)
        vector_store.persist(persist_path=persist_path)

    # node = vector_store.get("id1")
    # print(str(node))

    # -------------------------------------------------
    # from llama_index.core.vector_stores import MetadataFilters, ExactMatchFilter
    # filters = MetadataFilters(
    #     filters=[
    #         ExactMatchFilter(key="location", value='艾山水文站')
    #     ]
    # )
    # filters = MetadataFilters.from_dict({"source": "24"})

    # query_str = "艾山水文站流量测验的相关人员有哪些？分别对应哪些任务？"
    # query_str = "高村水文站流量测验的相关人员有哪些？分别对应哪些任务？"
    # query_str = "孙口水文站流量测验的相关人员有哪些？分别对应哪些任务？"
    # query_str = "伊春水文站流量测验的相关人员有哪些？分别对应哪些任务？"
    query_str = '泺口水文站 的水沙特性是什么样的？'

    if debug:
        query_embedding = embed_model.get_query_embedding(query_str)
        query_obj = VectorStoreQuery(
            query_embedding=query_embedding,
            similarity_top_k=10,
            query_str=query_str,
            # filters=filters
        )

        query_result = vector_store.query(query_obj)
        print('##################### query result ######################')
        # for similarity, node in zip(query_result.similarities, query_result.nodes):
        #     print(
        #         "\n----------------\n"
        #         f"[Node ID {node.node_id}] Similarity: {similarity}\n\n"
        #         f"{node.get_content(metadata_mode='all')}"
        #         "\n----------------\n\n"
        #     )

        for idx, (score, node) in enumerate(zip(query_result.similarities, query_result.nodes)):
            print(f'############# {idx} ############')
            print("node", node.node_id)
            print("node", score)
            print("node", node.text)
            print("node", node.metadata)


    # pack as query engine
    print(f'\n # ---------------------- query engine ----------------------')
    from llama_index.core import VectorStoreIndex
    index = VectorStoreIndex.from_vector_store(vector_store)
    query_engine = index.as_query_engine(similarity_top_k=10)

    if debug:
        response = query_engine.query(query_str)
        print(f'response: {response}')

    return query_engine


    # vector_store = HybridSearchVectorStore()
    # # load data into the vector stores
    # vector_store.add(nodes)
    #
    # query_str = "Can you tell me about the key concepts for safety finetuning"
    # query_embedding = embed_model.get_query_embedding(query_str)
    # query_obj = VectorStoreQuery(
    #     query_embedding=query_embedding,
    #     similarity_top_k=10
    # )
    #
    # query_result = vector_store.query(query_obj)
    # for similarity, node in zip(query_result.similarities, query_result.nodes):
    #     print(
    #         "\n----------------\n"
    #         f"[Node ID {node.node_id}] Similarity: {similarity}\n\n"
    #         f"{node.get_content(metadata_mode='all')}"
    #         "\n----------------\n\n"
    #     )
    #
    # from llama_index.core import VectorStoreIndex
    #
    # index = VectorStoreIndex.from_vector_store(vector_store)
    #
    # query_engine = index.as_query_engine()
    #
    # query_str = "Can you tell me about the key concepts for safety finetuning"
    #
    # response = query_engine.query(query_str)
    #
    # print(str(response))


if __name__ == '__main__':

    import sys
    import logging
    logging.basicConfig(stream=sys.stdout,
                        level=logging.DEBUG,
                        format="[%(levelname)s] %(filename)s[%(levelno)s]{%(funcName)s} %(message)s")
    main(debug=True)
