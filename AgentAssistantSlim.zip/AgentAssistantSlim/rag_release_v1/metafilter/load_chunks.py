import os

os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'

from typing import List
from pydantic import BaseModel, Field
from llama_index.core.output_parsers import PydanticOutputParser

import glob
from tqdm import tqdm
from llama_index.core.node_parser import SentenceSplitter

from loguru import logger
import uuid


def load_markdown_file(file_path):
    from llama_index.core.node_parser import MarkdownNodeParser
    from llama_index.readers.file import FlatReader
    from pathlib import Path

    md_docs = FlatReader().load_data(Path(file_path))
    parser = MarkdownNodeParser()
    nodes = parser.get_nodes_from_documents(md_docs)
    for node in nodes:
        logger.debug(node)

    return nodes


class CustomSentenceSplitter(SentenceSplitter):
    def split_text(self, text: str) -> List[str]:
        return text.split(self.separator)


def split_text(node):
    splitter = CustomSentenceSplitter(
        separator="|\n",
        # chunk_size=1024,
    )
    # nodes = splitter.get_nodes_from_documents(documents)
    logger.debug(f'raw_text: {repr(node.text)}')
    chunks = splitter.split_text(text=node.text)
    # print(chunks[0:3])
    # exit(0)

    title = None
    for i in range(len(chunks)):
        if '|---|' in chunks[i]:
            title = chunks[i].split('|---|')[0]
            logger.debug(f'[title] {title}')
        else:
            chunks[i] = chunks[i].replace('|', '-')
            # if isinstance(title, str):
            #     chunks[i] = title + '|' + chunks[i]
            # logger.debug(f'chunk_{i}: {chunks[i]}')
            continue

    chunk_nodes = []
    from llama_index.core.schema import TextNode

    for i, chunk in enumerate(chunks):
        if title is not None and title in chunk:
            continue
        _node = TextNode(
            text=chunk,
            # id_=f'{node.id_}-c{i}',
            # id_=node.id_,
            id=str(uuid.uuid4()),
        )
        chunk_nodes.append(_node)
    return chunk_nodes


def main():

    from rag_release_v1.load_model import load_model
    llm, embed_model = load_model()

    data_dir = '/data/data/shuiwen_p1_data'
    file_paths = glob.glob(f'{data_dir}/*output*.md')
    logger.info(f'n_file: {len(file_paths)}')

    tags = list(set([os.path.basename(f).split('_')[0].split('.')[0] for f in file_paths]))#[1:2]
    logger.debug(tags)

    # tags = []

    from rag_release_v1.analyze_meta_parse import ExtractShuiwenMetadata
    extract_meta_func = ExtractShuiwenMetadata(llm=llm)

    # _tag = "孙口水文站2023年测洪及报汛方案"
    all_chunks = []
    for _tag in tqdm(tags, desc='building_textnode'):
        _file_idx = tags.index(_tag)
        _file_paths = [f for f in file_paths if _tag in f] #[-1:]\
        _file_paths = sorted(_file_paths, key=lambda x: int(x.split('_')[-1].split('.')[0]))
        logger.debug(f'_file_paths: {_file_paths}')


        ############# extract meta properties #############
        meta_info = extract_meta_func(_tag)
        print(type(meta_info))
        meta_data = dict(
            year=meta_info.year,
            location=meta_info.location,
            document_type=meta_info.document_type
        )

        nodes = []
        for i in range(len(_file_paths)):
            _nodes = load_markdown_file(_file_paths[i])
            nodes.extend(_nodes)
        logger.debug(f'n_node: {len(nodes)}')

        from itertools import chain
        chunk_nodes = list(chain(*[(split_text(node)) for node in nodes]))

        for chunk_node in chunk_nodes:
            chunk_node.metadata = meta_data

        print(chunk_nodes[0:3])

        all_chunks.extend(chunk_nodes)

    logger.info(f'n_all_chunks: {len(all_chunks)}')
    return all_chunks


if __name__ == '__main__':

    import sys
    logger.remove()
    logger.add(sys.stderr, level="DEBUG")

    main()
