from llama_index.core.bridge.pydantic import Field, BaseModel


class ResponseClassify(BaseModel):
    """Evaluation of whether the response has an error."""

    has_error: bool = Field(
        ..., description="Whether the response has an error."
    )
    # new_question: str = Field(..., description="The suggested new question.")
    to_fruit_shop: bool = Field(...,
                                description="based on the response text, whether the user will go to a fruit shop at next step ?")
    explanation: str = Field(
        ...,
        description=(
            "The explanation for the error as well as for the new question."
            "Can include the direct stack trace as well."
        ),
    )


class ActionSelected(BaseModel):
    """Evaluation of whether the response has an error."""

    # has_error: bool = Field(
    #     ..., description="Whether the response has an error."
    # )
    step: str = Field(
        ..., description="which step we should choose? the answer must be one of (RAG, BackendSearch, WebSearch).")
    explanation: str = Field(
        ...,
        description=(
            "The explanation for the error as well as for the step you choose."
            "Can include the direct stack trace as well."
        ),
    )

