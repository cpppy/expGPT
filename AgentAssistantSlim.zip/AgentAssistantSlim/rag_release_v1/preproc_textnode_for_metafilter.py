import os

os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'

from typing import List
from pydantic import BaseModel, Field
from llama_index.core.output_parsers import PydanticOutputParser

import glob
import logging
from tqdm import tqdm


def load_models():
    from llama_index.llms.openai_like import OpenAILike
    llm = OpenAILike(
        # model="Qwen1.5-0.5B-Chat",
        # api_base="http://192.168.150.181:8000/v1",
        model='Mistral-7B-Instruct-v0.2',
        api_base="http://192.168.100.21:8000/v1",
        api_key='EMPTY',
        temperature=0.,
        max_tokens=2048,
    )

    from llama_index.core import Settings
    from llama_index.embeddings.huggingface import HuggingFaceEmbedding
    embed_model = HuggingFaceEmbedding(
        # model_name="BAAI/bge-small-en-v1.5",
        # model_name="BAAI/bge-small-zh-v1.5"
        # model_name="BAAI/bge-base-zh-v1.5",
        # device='cuda:0',
        model_name="BAAI/bge-large-zh-v1.5",
        device='cpu',
    )

    Settings.llm = llm
    Settings.embed_model = embed_model
    return llm, embed_model


def load_markdown_file(file_path):
    from llama_index.core.node_parser import MarkdownNodeParser
    from llama_index.readers.file import FlatReader
    from pathlib import Path

    md_docs = FlatReader().load_data(Path(file_path))
    parser = MarkdownNodeParser()
    nodes = parser.get_nodes_from_documents(md_docs)
    for node in nodes:
        logging.debug(node)

    return nodes


from llama_index.core.node_parser import SentenceSplitter


class CustomSentenceSplitter(SentenceSplitter):
    def split_text(self, text: str) -> List[str]:
        return text.split(self.separator)


def split_text(node):
    splitter = CustomSentenceSplitter(
        separator="|\n",
        # chunk_size=1024,
    )
    # nodes = splitter.get_nodes_from_documents(documents)
    logging.debug(f'raw_text: {repr(node.text)}')
    chunks = splitter.split_text(text=node.text)
    # print(chunks[0:3])
    # exit(0)

    title = None
    for i in range(len(chunks)):
        if '|---|' in chunks[i]:
            title = chunks[i].split('|---|')[0]
            logging.debug(f'[title] {title}')
        else:
            # chunks[i] = chunks[i].replace('|', '-')
            # if isinstance(title, str):
            #     chunks[i] = title + '|' + chunks[i]
            logging.debug(f'chunk_{i}: {chunks[i]}')

    chunk_nodes = []
    from llama_index.core.schema import TextNode
    for i, chunk in enumerate(chunks):
        _node = TextNode(
            text=chunk,
            # id_=f'{node.id_}-c{i}',
            id_=node.id_,
        )
        chunk_nodes.append(_node)
    return chunk_nodes


def main(debug=False):
    llm, embed_model = load_models()

    data_dir = '/data/data/shuiwen_p1_data'
    file_paths = glob.glob(f'{data_dir}/*output*.md')
    logging.info(f'n_file: {len(file_paths)}')

    tags = list(set([os.path.basename(f).split('_')[0].split('.')[0] for f in file_paths]))
    logging.debug(tags)

    tags = []

    from rag_release_v1.analyze_meta_parse import ExtractShuiwenMetadata
    extract_meta_func = ExtractShuiwenMetadata(llm=llm)

    # _tag = "孙口水文站2023年测洪及报汛方案"
    all_chunks = []
    for _tag in tqdm(tags, desc='building_textnode'):
        _file_idx = tags.index(_tag)
        _file_paths = [f for f in file_paths if _tag in f] #[-1:]\
        _file_paths = sorted(_file_paths, key=lambda x: int(x.split('_')[-1].split('.')[0]))
        logging.debug(f'_file_paths: {_file_paths}')


        ############# extract meta properties #############
        meta_info = extract_meta_func(_tag)
        print(type(meta_info))
        meta_data = dict(
            year=meta_info.year,
            location=meta_info.location,
            document_type=meta_info.document_type
        )

        nodes = []
        for i in range(len(_file_paths)):
            _nodes = load_markdown_file(_file_paths[i])
            nodes.extend(_nodes)
        logging.debug(f'n_node: {len(nodes)}')

        from itertools import chain
        chunk_nodes = list(chain(*[(split_text(node)) for node in nodes]))

        for chunk_node in chunk_nodes:
            chunk_node.metadata = meta_data

        print(chunk_nodes[0:3])

        all_chunks.extend(chunk_nodes)

    ####################################################

    logging.info(f'n_all_chunks: {len(all_chunks)}')

    import qdrant_client
    from llama_index.vector_stores.qdrant import QdrantVectorStore
    from llama_index.core import VectorStoreIndex, StorageContext
    from qdrant_client.http.models import Filter, FieldCondition, MatchValue
    client = qdrant_client.QdrantClient(
        # location=":memory:"
        path='./qdrant_cache'
    )
    vector_store = QdrantVectorStore(
        client=client, collection_name="shuiwen_part1"
    )
    storage_context = StorageContext.from_defaults(vector_store=vector_store)
    index = VectorStoreIndex(nodes=all_chunks,
                             embed_model=embed_model,
                             storage_context=storage_context,
                             show_progress=True)


    # ################ build vector store index ################
    # '''
    # https://docs.llamaindex.ai/en/latest/module_guides/indexing/vector_store_index/
    # https://docs.llamaindex.ai/en/latest/module_guides/indexing/vector_store_guide/
    # '''
    # from llama_index.core import VectorStoreIndex
    # index = VectorStoreIndex(
    #     nodes=chunk_nodes,
    #     embed_model=embed_model
    # )

    # query_engine = index.as_query_engine(
    #     llm=llm,
    #     similarity_top_k=10,
    # )
    # response = query_engine.query("流量测验方案有哪些？")
    # logging.debug(response)

    from llama_index.core.vector_stores.types import MetadataInfo, VectorStoreInfo
    vector_store_info = VectorStoreInfo(
        content_info="水文站的测试工作安排或记录",
        metadata_info=[
            # MetadataInfo(
            #     name="year",
            #     type='int',
            #     description=(
            #         "Year number in the given string, maybe one of [2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026...]"
            #     ),
            # ),
            MetadataInfo(
                name="location",
                type='str',
                description=(
                    "Location Name, for example: xxx 水文站 or xxx 水文局 or other organizations."
                ),
            ),
        ],
    )

    from llama_index.core.indices.vector_store.retrievers import VectorIndexRetriever
    retriever = VectorIndexRetriever(index=index,
                                     similarity_top_k=10,
                                     vector_store_info=vector_store_info,
                                     # filters=filters,
                                     # alpha=0,
                                     # hybrid_topk=10,
                                     verbose=True,
                                     )

    if debug:
        # Running over some sample data
        # query_str = "高村水文站流量测验的相关人员有哪些？分别对应哪些任务？"
        query_str = "伊春水文站流量测验的相关人员有哪些？分别对应哪些任务？"
        response = retriever.retrieve(query_str)

        logging.info(response)

        for idx, node in enumerate(response):
            print(f'############# {idx} ############')
            print("node", node.node_id)
            print("node", node.score)
            print("node", node.text)
            print("node", node.metadata)

    # query_engine = index.as_query_engine()
    # response = query_engine.query("高村水文站流量测验的相关人员有哪些？分别对应哪些任务？")
    # logging.debug(response)

    # ################# parse location #################
    # from agents.demo_custom_agent_v2 import load_model
    # llm = load_model(with_embedding=False)
    #
    # from llama_index.core.query_pipeline import QueryPipeline
    # from llama_index.core import PromptTemplate
    #
    # json_prompt_str = """
    #     Please parse the year number and location name in {title}.
    #     \nOutput with the following JSON format:
    #     """
    #
    # # add JSON spec to prompt template
    # json_prompt_tmpl = PromptTemplate(json_prompt_str)
    #
    # p = QueryPipeline(chain=[json_prompt_tmpl, llm], verbose=True)
    #
    # for frame_title in tags[0:3]:
    #     logging.debug(f'------------------------------')
    #     output = p.run(title=frame_title)
    #     logging.debug(f'output: {output}')

    from llama_index.core.query_engine import RetrieverQueryEngine
    query_engine = RetrieverQueryEngine.from_args(retriever=retriever, llm=llm)
    if debug:
        response = query_engine.query("高村水文站流量测验的相关人员有哪些？分别对应哪些任务？")
        print(response)

    return query_engine


if __name__ == '__main__':
    import sys

    logging.basicConfig(stream=sys.stdout,
                        level=logging.INFO,
                        format="[%(levelname)s] %(filename)s[%(levelno)s]{%(funcName)s} %(message)s")

    main(debug=True)
