
import os

os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'
os.environ['NUMEXPR_MAX_THREADS'] = '12'

import openai
import qdrant_client
from IPython.display import Markdown, display
from llama_index.core import VectorStoreIndex
from llama_index.core import StorageContext
from llama_index.vector_stores.qdrant import QdrantVectorStore
from qdrant_client.http.models import Filter, FieldCondition, MatchValue


'''
https://docs.llamaindex.ai/en/stable/examples/vector_stores/Qdrant_using_qdrant_filters/?h=qdrant

'''

import openai
import qdrant_client
from IPython.display import Markdown, display
from llama_index.core import VectorStoreIndex
from llama_index.core import StorageContext
from llama_index.vector_stores.qdrant import QdrantVectorStore
from qdrant_client.http.models import Filter, FieldCondition, MatchValue


def main():
    #################### load model ####################
    from llama_index.llms.openai_like import OpenAILike
    llm = OpenAILike(
        # model="Qwen1.5-0.5B-Chat",
        # api_base="http://192.168.150.181:8000/v1",
        model='Mistral-7B-Instruct-v0.2',
        api_base="http://192.168.100.21:8000/v1",
        api_key='EMPTY',
        temperature=0.,
        max_tokens=4096,
    )

    # from llama_index.embeddings.huggingface import HuggingFaceEmbedding
    # embed_model = HuggingFaceEmbedding(
    #     model_name="BAAI/bge-small-en-v1.5",
    # )
    from llama_index.core.embeddings import resolve_embed_model
    embed_model = resolve_embed_model("local:BAAI/bge-small-en-v1.5")

    from llama_index.core import Settings
    Settings.llm = llm
    Settings.embed_model = embed_model
    ####################################################

    client = qdrant_client.QdrantClient(
        # location=":memory:"
        path='./qdrant_cache'
    )
    from llama_index.core.schema import TextNode


    # nodes = [
    #     TextNode(
    #         text="りんごとは",
    #         metadata={"author": "Tanaka", "fruit": "apple", "city": "Tokyo"},
    #     ),
    #     TextNode(
    #         text="Was ist Apfel?",
    #         metadata={"author": "David", "fruit": "apple", "city": "Berlin"},
    #     ),
    #     TextNode(
    #         text="Orange like the sun",
    #         metadata={"author": "Jane", "fruit": "orange", "city": "Hong Kong"},
    #     ),
    #     TextNode(
    #         text="Grape is...",
    #         metadata={"author": "Jane", "fruit": "grape", "city": "Hong Kong"},
    #     ),
    #     TextNode(
    #         text="T-dot > G-dot",
    #         metadata={"author": "George", "fruit": "grape", "city": "Toronto"},
    #     ),
    #     TextNode(
    #         text="6ix Watermelons",
    #         metadata={
    #             "author": "George",
    #             "fruit": "watermelon",
    #             "city": "Toronto",
    #         },
    #     ),
    # ]

    nodes = []

    # openai.api_key = "YOUR_API_KEY"
    vector_store = QdrantVectorStore(
        client=client, collection_name="fruit_collection"
    )
    storage_context = StorageContext.from_defaults(vector_store=vector_store)
    index = VectorStoreIndex(nodes, storage_context=storage_context)


    # Use filters directly from qdrant_client python library
    # View python examples here for more info https://qdrant.tech/documentation/concepts/filtering/

    filters = Filter(
        should=[
            Filter(
                must=[
                    FieldCondition(
                        key="fruit",
                        match=MatchValue(value="apple"),
                    ),
                    FieldCondition(
                        key="city",
                        match=MatchValue(value="Tokyo"),
                    ),
                ]
            ),
            Filter(
                must=[
                    FieldCondition(
                        key="fruit",
                        match=MatchValue(value="grape"),
                    ),
                    FieldCondition(
                        key="city",
                        match=MatchValue(value="Toronto"),
                    ),
                ]
            ),
        ]
    )

    # retriever = index.as_retriever(vector_store_kwargs={"qdrant_filters": filters})
    # retriever = index.as_retriever()
    # response = retriever.retrieve("Who makes grapes?")
    # for node in response:
    #     print("node", node.score)
    #     print("node", node.text)
    #     print("node", node.metadata)

    query_engine = index.as_query_engine(llm=llm, similarity_top_k=2)
    response = query_engine.retrieve('who makes grapes ?')
    # print(response)
    for node in response:
        print("node", node.score)
        print("node", node.text)
        print("node", node.metadata)





if __name__=='__main__':

    main()



