import os
os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'
os.environ['NUMEXPR_MAX_THREADS'] = '12'

from llama_index.core.tools import QueryEngineTool
from llama_index.core.query_engine import RouterQueryEngine
from llama_index.core.selectors import LLMSingleSelector, LLMMultiSelector
from llama_index.core.selectors import (
    PydanticMultiSelector,
    PydanticSingleSelector,
)

from router.llm_selector_rel import CustomLLMSingleSelector


def main():

    from rag_release_v1.load_model import load_model
    llm, embed_model = load_model()

    # load query engines
    # from rag_release_v1 import preproc_textnode_for_metafilter
    # shuiwenP1_query_engine = preproc_textnode_for_metafilter.main(debug=False)
    from rag_release_v1.metafilter import custom_vectorstore_v2
    shuiwenP1_query_engine = custom_vectorstore_v2.main()

    from rag_release_v1 import hybrid_search_docW
    shuiwenNotice_query_engine = hybrid_search_docW.main(debug=False)

    from rag_release_v1.remote_query_engine import RemoteQueryEngine
    raptor_query_engine = RemoteQueryEngine(callback_manager=None)

    # pack engine tool
    shuiwenFrame_tool = QueryEngineTool.from_defaults(
        query_engine=shuiwenP1_query_engine,
        name="水文站测洪和报汛信息查询",
        description=(
            "提供各水文站的测洪及测汛方案的具体内容查询，"
            "包括具体的工作安排、相关人员及工作分配、工作内容描述等。"
        ),
    )

    shuiwenNotice_tool = QueryEngineTool.from_defaults(
        query_engine=shuiwenNotice_query_engine,
        name="水文水资源局通知内容查询",
        description=(
            "提供各地水文水资源局印发给各水文站任务书的通知，"
            "通知内容包含对水文站的总体任务安排或规划。"
        ),
    )

    raptor_tool = QueryEngineTool.from_defaults(
        query_engine=raptor_query_engine,
        name="伊春林区生态信息查询",
        description=(
            "关于伊春林区的林业生态规划，"
            "林地质量评价、国土空间规划和林业发展区分类、天然更新等级评价、森林覆被类型连片面积评价、森林覆被类型变化原因、林地保护等级、权属分类."
            "伊春市政府对于森林资源的配置情况和改造方案等。"
        ),
    )

    # combine multi engines
    query_engine = RouterQueryEngine(
        # selector=PydanticSingleSelector.from_defaults(),
        selector=CustomLLMSingleSelector.from_defaults(),
        query_engine_tools=[
            shuiwenFrame_tool,
            shuiwenNotice_tool,
            raptor_tool,
        ],
        verbose=True,
    )


    # from llama_index.core import SimpleDirectoryReader
    # # load documents
    # documents = SimpleDirectoryReader("../documents/data/pdf/").load_data()
    #
    # from llama_index.core import Settings
    # # initialize settings (set chunk size)
    # Settings.chunk_size = 1024
    # nodes = Settings.node_parser.get_nodes_from_documents(documents)
    #
    # from llama_index.core import StorageContext
    #
    # # initialize storage context (by default it's in-memory)
    # storage_context = StorageContext.from_defaults()
    # storage_context.docstore.add_documents(nodes)
    #
    # from llama_index.core import SummaryIndex
    # from llama_index.core import VectorStoreIndex
    #
    # summary_index = SummaryIndex(nodes, storage_context=storage_context)
    # vector_index = VectorStoreIndex(nodes, storage_context=storage_context)
    #
    # list_query_engine = summary_index.as_query_engine(
    #     response_mode="tree_summarize",
    #     use_async=True,
    # )
    # vector_query_engine = vector_index.as_query_engine()

    # response = query_engine.query("高村水文站流量测验的相关人员有哪些？分别对应哪些任务？")
    # response = query_engine.query("山东水文局引发给高村水文站的通知中具体要求了哪些任务？")
    # response = query_engine.query("伊春林业生态规划包含哪些内容？")
    # response = query_engine.query(
    #     '泺口水文站 的水沙特性是什么样的？',
    #     # '泺口水文站的历史最高水位是哪一年？'
    # )
    # print(str(response))

    return query_engine


if __name__=='__main__':
    import logging
    import sys

    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
    # logging.getLogger().addHandler(logging.StreamHandler(stream=sys.stdout))
    main()

