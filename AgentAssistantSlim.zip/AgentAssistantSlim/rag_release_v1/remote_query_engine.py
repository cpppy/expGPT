
from typing import Any, Dict, List, Optional, Sequence


from llama_index.core.base.response.schema import RESPONSE_TYPE
from llama_index.core.schema import NodeWithScore, QueryBundle, QueryType
from llama_index.core.instrumentation.events.query import (
    QueryEndEvent,
    QueryStartEvent,
)

from llama_index.core.callbacks.schema import CBEventType, EventPayload
from llama_index.core.prompts.mixin import PromptMixinType
from llama_index.core.callbacks.base import CallbackManager

from llama_index.core.base.base_query_engine import BaseQueryEngine

from llama_index.core.base.response.schema import Response

import llama_index.core.instrumentation as instrument
dispatcher = instrument.get_dispatcher(__name__)
import requests
import json

class RemoteQueryEngine(BaseQueryEngine):

    def ___init__(self, callback_manager: Optional[CallbackManager] = None,):
        super().__init__(callback_manager=callback_manager)

    # def query(self, str_or_query_bundle: QueryType) -> RESPONSE_TYPE:
    #     dispatch_event = dispatcher.get_dispatch_event()
    #
    #     dispatch_event(QueryStartEvent())
    #     with self.callback_manager.as_trace("query"):
    #         if isinstance(str_or_query_bundle, str):
    #             str_or_query_bundle = QueryBundle(str_or_query_bundle)
    #         query_result = self._query(str_or_query_bundle)
    #     dispatch_event(QueryEndEvent())
    #     return query_result

    def _get_prompt_modules(self) -> PromptMixinType:
        """Get prompt sub-modules."""
        return {"response_synthesizer": None}

    def _query(self, query_bundle: QueryBundle) -> RESPONSE_TYPE:
        """Answer a query."""
        # with self.callback_manager.event(
        #         CBEventType.QUERY, payload={EventPayload.QUERY_STR: query_bundle.query_str}
        # ) as query_event:
        #     nodes = self.retrieve(query_bundle)
        #     response = self._response_synthesizer.synthesize(
        #         query=query_bundle,
        #         nodes=nodes,
        #     )
        #     query_event.on_end(payload={EventPayload.RESPONSE: response})

        try:
            url = 'http://192.168.100.24:9005/raptor_answer'
            response = requests.get(url, params={'query': query_bundle.query_str})
            # print(response.text)
            result = json.loads(response.text)['response']
            print(result)
        except Exception as e:
            print(e)
            result = 'fail to connect to raptor search engine.'
        return Response(response=result)

    async def _aquery(self, query_bundle: QueryBundle) -> RESPONSE_TYPE:
        """Answer a query."""
        # with self.callback_manager.event(
        #         CBEventType.QUERY, payload={EventPayload.QUERY_STR: query_bundle.query_str}
        # ) as query_event:
        #     nodes = await self.aretrieve(query_bundle)
        #
        #     response = await self._response_synthesizer.asynthesize(
        #         query=query_bundle,
        #         nodes=nodes,
        #     )
        #
        #     query_event.on_end(payload={EventPayload.RESPONSE: response})
        # return response
        response_str = 'result from remote'
        return Response(response=response_str)


def main():

    query_engine = RemoteQueryEngine(None)
    response = query_engine.query("伊春林业生态规划包含哪些内容？")
    print(response)




if __name__=='__main__':

    main()



