from llama_index.core import PromptTemplate
from llama_index.core.bridge.pydantic import Field, BaseModel
# from llama_index.core.query_pipeline import QueryPipeline
# from llama_index.core.query_pipeline import RouterComponent
from llama_index.core.llms import ChatMessage, MessageRole

from llama_index.core.agent.react.types import (
    ObservationReasoningStep,
)
from llama_index.core.agent import Task
from llama_index.core.query_pipeline import (
    AgentInputComponent,
    AgentFnComponent,
    ToolRunnerComponent
)
from llama_index.core.agent import AgentChatResponse
from typing import (
    Dict,
    Any,
    Set,
    List,
    Tuple,
)

from router_agent.custom_qp import CustomQueryPipeline as QueryPipeline


class ResponseClassify(BaseModel):
    """Evaluation of whether the response has an error."""

    has_error: bool = Field(
        ..., description="Whether the response has an error."
    )
    # new_question: str = Field(..., description="The suggested new question.")
    to_fruit_shop: bool = Field(...,
                                description="based on the response text, whether the user will go to a fruit shop at next step ?")
    explanation: str = Field(
        ...,
        description=(
            "The explanation for the error as well as for the new question."
            "Can include the direct stack trace as well."
        ),
    )


def condition_fn(x):
    logging.debug(f'condition_fn x: {x}')
    return x['to_fruit_shop']


## Agent Input Component
## This is the component that produces agent inputs to the rest of the components
## Can also put initialization logic here.
def agent_input_fn(task: Task, state: Dict[str, Any]) -> Dict[str, Any]:
    """Agent input function.

    Returns:
        A Dictionary of output keys and values. If you are specifying
        src_key when defining links between this component and other
        components, make sure the src_key matches the specified output_key.

    """
    # initialize current_reasoning
    if "current_reasoning" not in state:
        state["current_reasoning"] = []
    reasoning_step = ObservationReasoningStep(observation=task.input)
    state["current_reasoning"].append(reasoning_step)

    # add record
    task.extra_state['record'].append(dict(layername='input', messages=[('user', task.input)]))

    return {"input": task.input}


def run_component_fn(
        task: Task, state: Dict[str, Any], llm, flow_params,  # reasoning_step: ActionReasoningStep
):
    logging.debug(f'[chat_component task_memory] {task.memory}')
    logging.debug(f'[chat_component task_extra_state] {task.extra_state}')
    logging.debug(f'[chat_component state] {state}')
    logging.debug(f'[chat_component flow_params: {flow_params}')

    # from agents.demo_custom_agent_v2 import load_model
    # llm = load_model(with_embedding=False)

    from router_agent.define_component_v4_chat import ChatCustomQueryComponent
    chat_component = ChatCustomQueryComponent(
        llm=llm,
        prompt_str="Please generate answer to question: {query_str}",
    )
    chat_history = task.memory.get() + state["memory"].get_all()
    logging.debug(f'[chat_component chat_history] {chat_history}')
    component_output = chat_component.run_component(
        query_str=task.input,
        chat_history=chat_history,
    )
    chat_response_text = component_output['output']['llm_output']

    # TODO: update response to memory.chat_history & state or extra_state
    task.memory.put(ChatMessage(role=MessageRole.USER, content=task.input))
    task.memory.put(ChatMessage(role=MessageRole.ASSISTANT, content=chat_response_text))
    task.extra_state['record'].append(
        dict(layername='chat',
             messages=[
                 ('user', task.input),
                 ('assistant', chat_response_text)
             ])
    )

    return {"response_str": chat_response_text, "is_done": True}


def router_component_fn(
        task: Task, state: Dict[str, Any], llm, flow_params,
):
    logging.debug(f'[router_component task_memory] {task.memory}')
    logging.debug(f'[router_component task_extra_state] {task.extra_state}')
    logging.debug(f'[router_component state] {state}')
    logging.debug(f'[router_component flow_params: {flow_params}')

    ################## ROUTER COMPONENT ################
    prompt_str = "[Movie] please answer the user's question about movie, Question: {query_str}"
    prompt_tmpl = PromptTemplate(prompt_str)

    action_1 = QueryPipeline(chain=[prompt_tmpl, llm])
    # response = action_1.run(query_str='select a movie with a happy ending for the weekend rest time.')
    # logging.debug(f'response: {response}')
    # exit(0)

    prompt_str = "[Fruit] please answer the user's question about fruit, Question: {query_str}"
    prompt_tmpl = PromptTemplate(prompt_str)

    action_2 = QueryPipeline(chain=[prompt_tmpl, llm])
    # response = qp2.run(query_str='Can I eat some orange when headache ?')
    # logging.debug(f'response: {response}')

    choices = [
        'if user ask something about movie, choose this action.',
        'if user ask something about fruit, choose this action.',
    ]

    from router.llm_selector_rel import CustomLLMSingleSelector
    selector = CustomLLMSingleSelector.from_defaults(llm=llm)
    from router_agent.custom_router_component import CustomRouterComponent as RouterComponent
    router_c = RouterComponent(
        selector=selector,
        choices=choices,
        components=[action_1, action_2],
        verbose=True,
    )
    query = flow_params['response_str']
    # query = 'can you give me some advice about watching a moive at weekend ?'
    router_output, log_str = router_c.run_component(query=query)
    print(f'router_output: {router_output}')
    component_output = router_output['output'].text
    # exit(0)
    logging.debug(f'component_output: {component_output}')

    # update record
    task.extra_state['record'].append(
        dict(layername='router',
             messages=[
                 ('user', query),
                 ('action', log_str),
                 ('assistant', component_output)
             ])
    )
    print(f'[router component] output: {component_output}')
    return {"response_str": component_output, "is_done": True}


def cls_component_fn(
        task: Task, state: Dict[str, Any], llm, flow_params,
):
    logging.debug(f'[cls_component task_memory] {task.memory}')
    logging.debug(f'[cls_component task_extra_state] {task.extra_state}')
    logging.debug(f'[cls_component state] {state}')
    logging.debug(f'[cls_component flow_params: {flow_params}')

    print(f'task_input: {task.input}')
    response_last_stage = flow_params['response_str']

    ### add output parser
    TEMPLATE = """
       Here's a JSON schema to follow:
       {schema}

       Output a valid JSON object but do not repeat the schema.
       """

    from router.parser import CustomPydanticOutputParser
    output_parser = CustomPydanticOutputParser(output_cls=ResponseClassify,
                                               pydantic_format_tmpl=TEMPLATE)

    json_prompt_str = """
           analyse the response from llm, give suggestion of the next step about this topic.
           \n Response: {response_str}. 
           \n Output with the following JSON format: 
           """
    json_prompt_str = output_parser.format(json_prompt_str)
    json_prompt_tmpl = PromptTemplate(json_prompt_str)
    qp_cls = QueryPipeline(chain=[json_prompt_tmpl, llm, output_parser])
    # qp_router = QueryPipeline(chain=[router_c, qp_cls])
    # output = qp_router.run("which kind of fruit is benefit for human's hair ?")
    # print('----------------- final output --------------------')
    # print(output)
    cls_response = qp_cls.run_component(response_str=response_last_stage)
    print(f'cls_response: {cls_response}')
    return {
            "cls_response": cls_response['output'],
            "to_fruit_shop": cls_response['output'].to_fruit_shop,
            "is_done": True
        }


def process_agent_response_fn(
        task: Task, state: Dict[str, Any], response_dict: dict
):
    """Process agent response."""
    # return (
    #     AgentChatResponse(response_dict["response_str"]),
    #     response_dict["is_done"],
    # )

    # update record
    task.extra_state['record'].append(
        dict(layername='output',
             messages=[
                 ('assistant', response_dict["response_str"])
             ])
    )

    return (
        AgentChatResponse(response_dict["response_str"]),
        True,
    )


def main():
    from agents.demo_custom_agent_v2 import load_model
    llm = load_model(with_embedding=False)

    from functools import partial
    chat_component = AgentFnComponent(fn=partial(run_component_fn, llm=llm))
    # chat_component = AgentFnComponent(run_component_fn)

    router_component = AgentFnComponent(fn=partial(router_component_fn, llm=llm))

    cls_component = AgentFnComponent(fn=partial(cls_component_fn, llm=llm))

    # qp_router = QueryPipeline(chain=[router_c])
    # output = qp_router.run("which kind of fruit is benefit for human's hair ?")
    # print('----------------- final output --------------------')
    # print(output)

    # add branch
    # prompt_str = "analyse the response from llm, then generate a new question about this topic, Response: {response_str}"
    # prompt_tmpl = PromptTemplate(prompt_str)
    # llm_program = CustomLLMTextCompletionProgram.from_defaults(
    #     # output_parser=PydanticOutputParser(output_cls=ResponseEval),
    #     # output_parser=CustomPydanticOutputParser(output_cls=ResponseEval),
    #     output_parser=CustomPydanticOutputParser(output_cls=ResponseClassify),
    #     prompt=prompt_tmpl,
    #     llm=llm,
    #     verbose=True,
    # )
    # # test llm_program
    # llm_p_output = llm_program(
    #     response_str='orange is good for human"s health.',
    # )
    # logging.debug(f'llm_p_output: {llm_p_output}')



    ## add action
    from router_qp.define_component_v3_branch import DecisionComponent
    from typing import Any, Dict
    class DecisionComponent_Fruit(DecisionComponent):

        # @property
        # def _output_keys(self) -> Set[str]:
        #     """Output keys."""
        #     return {'output', 'is_done'}

        def _run_component(self, **kwargs: Any) -> Dict:
            """Run component."""
            # AgentChatResponse(response_dict["response_str"])
            print(f'[decision component] kwargs: {kwargs}')
            exit(0)
            return {'output': dict(response_str=f'SubPath of component: {self.__class__.__name__}.', is_done=True)}

    class DecisionComponent_Other(DecisionComponent):

        # @property
        # def _output_keys(self) -> Set[str]:
        #     """Output keys."""
        #     return {'output', 'is_done'}

        def _run_component(self, **kwargs: Any) -> Dict:
            """Run component."""
            print(f'[decision component] kwargs: {kwargs}')
            exit(0)

            # return {'output': f'SubPath of component: {self.__class__.__name__}.', 'is_done': True}
            return {'output': dict(response_str=f'SubPath of component: {self.__class__.__name__}.', is_done=True)}

    # from llama_index.core.query_pipeline import InputComponent
    # input = InputComponent()
    qp_router = QueryPipeline(verbose=True)
    agent_input_component = AgentInputComponent(fn=agent_input_fn)
    agent_output_component = AgentFnComponent(fn=process_agent_response_fn)
    qp_router.add_modules(
        {
            'input': agent_input_component,
            'chat': chat_component,
            'router': router_component,
            'qp_cls': cls_component,
            'subpath_0': DecisionComponent_Fruit(),
            'subpath_1': DecisionComponent_Other(),
            'output': agent_output_component,
        }
    )
    # qp_router.add_chain(['input', 'actions', 'qp_cls'])
    # qp_router.add_link(src='qp_cls', dest='subpath_0',
    #                    # condition_fn=condition_fn,
    #                    condition_fn=lambda x: x.to_fruit_shop,
    #                    input_fn=lambda x: x)
    # qp_router.add_link(src='qp_cls', dest='subpath_1',
    #                    # condition_fn=condition_fn,
    #                    condition_fn=lambda x: not x.to_fruit_shop,
    #                    input_fn=lambda x: x)
    # qp_router.add_link(src='subpath_0', dest='output')
    # qp_router.add_link(src='subpath_1', dest='output')

    qp_router.add_chain(['input', 'chat', 'router', 'qp_cls'])
    qp_router.add_link(src='qp_cls', dest='subpath_0',
                       # condition_fn=condition_fn,
                       condition_fn=lambda x: x['to_fruit_shop'],
                       input_fn=lambda x: x)
    qp_router.add_link(src='qp_cls', dest='subpath_1',
                       # condition_fn=condition_fn,
                       condition_fn=lambda x: not x['to_fruit_shop'],
                       input_fn=lambda x: x)
    qp_router.add_link(src='subpath_0', dest='output')
    qp_router.add_link(src='subpath_1', dest='output')

    # output = qp_router.run("which kind of fruit is benefit for human's hair ?")
    # # output = qp_router.run('recommend a movie with a happy ending for the weekend.')
    # print('----------------- final output --------------------')
    # print(output)

    ###################### AGENT ###################
    from llama_index.core.agent import QueryPipelineAgentWorker, AgentRunner
    from llama_index.core.callbacks import CallbackManager
    # agent_worker = QueryPipelineAgentWorker(qp_router)
    from router_agent.custom_qp_agent_worker import CustomQueryPipelineAgentWorker
    agent_worker = CustomQueryPipelineAgentWorker(qp_router)
    agent = AgentRunner(
        agent_worker=agent_worker,
        chat_history=[
            ChatMessage(role=MessageRole.SYSTEM,
                        content="You are a helpful assistant. can answer all questions from human."),
            # ChatMessage(role=MessageRole.USER, content="麻婆豆腐的制作方法？"),
        ],
        callback_manager=CallbackManager([]),
        verbose=True
    )

    # start task
    task = agent.create_task(
        input="What are some tracks from the artist AC/DC? Limit it to 3",
        # chat_history=[],
        extra_state=dict(a=1, b=2, record=[]),
    )
    logging.debug(f'task_input: {task.input}')
    # response = agent_input_component._run_component(task=task, state={})
    # logging.debug(f'response: {response}')
    # exit(0)

    # # chat history in task.memory
    # print(f'[task memory] {task.memory}')
    # print(f'[task extra_state] {task.extra_state}')
    # exit(0)

    step_output = agent.run_step(task.task_id)
    logging.info(f'step_output: {step_output}')

    # response = agent.chat("What are some tracks from the artist AC/DC? Limit it to 3")
    # print(response)

    record = task.extra_state['record']
    print(f'################## RECORD ################## ')
    for r in record:
        print(f'- layer: {r["layername"]}')
        for m in r['messages']:
            print(f'    {m}')


if __name__ == '__main__':
    import logging
    import sys

    logging.basicConfig(stream=sys.stdout,
                        level=logging.DEBUG,
                        format="[%(levelname)s] %(filename)s[%(levelno)s]{%(funcName)s} %(message)s")

    main()
