import os

os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'
os.environ['NUMEXPR_MAX_THREADS'] = '12'

from llama_index.core import PromptTemplate
from llama_index.core.bridge.pydantic import Field, BaseModel
# from llama_index.core.query_pipeline import QueryPipeline
# from llama_index.core.query_pipeline import RouterComponent
from llama_index.core.llms import ChatMessage, MessageRole

from llama_index.core.agent.react.types import (
    ObservationReasoningStep,
)
from llama_index.core.agent import Task
from llama_index.core.query_pipeline import (
    AgentInputComponent,
    AgentFnComponent,
    ToolRunnerComponent
)
from llama_index.core.agent import AgentChatResponse
from typing import (
    Dict,
    Any,
    Set,
    List,
    Tuple, NamedTuple
)

from functools import partial

from router_agent.custom_qp import CustomQueryPipeline as QueryPipeline

from rag_release_v1.actions import DecisionComponent_Fruit, DecisionComponent_Other
from rag_release_v1.parse_format import ResponseClassify, ActionSelected

from loguru import logger
import json
import logging


def condition_fn(x):
    logger.debug(f'condition_fn x: {x}')
    return x['to_fruit_shop']


## Agent Input Component
## This is the component that produces agent inputs to the rest of the components
## Can also put initialization logic here.
def agent_input_fn(task: Task, state: Dict[str, Any]) -> Dict[str, Any]:
    """Agent input function.

    Returns:
        A Dictionary of output keys and values. If you are specifying
        src_key when defining links between this component and other
        components, make sure the src_key matches the specified output_key.

    """
    # initialize current_reasoning
    if "current_reasoning" not in state:
        state["current_reasoning"] = []
    reasoning_step = ObservationReasoningStep(observation=task.input)
    state["current_reasoning"].append(reasoning_step)

    # add record
    task.extra_state['record'].append(dict(layername='input', messages=[('user', task.input)]))

    return {"input": task.input}


def run_component_fn(
        task: Task, state: Dict[str, Any], llm, flow_params,  # reasoning_step: ActionReasoningStep
):
    logger.debug(f'[chat_component task_memory] {task.memory}')
    logger.debug(f'[chat_component task_extra_state] {task.extra_state}')
    logger.debug(f'[chat_component state] {state}')
    logger.debug(f'[chat_component flow_params: {flow_params}')

    # from agents.demo_custom_agent_v2 import load_model
    # llm = load_model(with_embedding=False)

    from router_agent.define_component_v4_chat import ChatCustomQueryComponent
    chat_component = ChatCustomQueryComponent(
        llm=llm,
        prompt_str="Please generate answer to question: {query_str}",
    )
    chat_history = task.memory.get() + state["memory"].get_all()
    logger.debug(f'[chat_component chat_history] {chat_history}')
    component_output = chat_component.run_component(
        query_str=task.input,
        chat_history=chat_history,
    )
    chat_response_text = component_output['output']['llm_output']

    # TODO: update response to memory.chat_history & state or extra_state
    task.memory.put(ChatMessage(role=MessageRole.USER, content=task.input))
    task.memory.put(ChatMessage(role=MessageRole.ASSISTANT, content=chat_response_text))
    task.extra_state['record'].append(
        dict(layername='chat',
             messages=[
                 ('user', task.input),
                 ('assistant', chat_response_text)
             ])
    )

    return {"response_str": chat_response_text, "is_done": True}


def router_component_fn(
        task: Task, state: Dict[str, Any], llm, flow_params,
):
    logger.debug(f'[router_component task_memory] {task.memory}')
    logger.debug(f'[router_component task_extra_state] {task.extra_state}')
    logger.debug(f'[router_component state] {state}')
    logger.debug(f'[router_component flow_params: {flow_params}')

    ################## ROUTER COMPONENT ################
    prompt_str = "[Movie] please answer the user's question about movie, Question: {query_str}"
    prompt_tmpl = PromptTemplate(prompt_str)

    action_1 = QueryPipeline(chain=[prompt_tmpl, llm])
    # response = action_1.run(query_str='select a movie with a happy ending for the weekend rest time.')
    # logging.debug(f'response: {response}')
    # exit(0)

    prompt_str = "[Fruit] please answer the user's question about fruit, Question: {query_str}"
    prompt_tmpl = PromptTemplate(prompt_str)

    action_2 = QueryPipeline(chain=[prompt_tmpl, llm])
    # response = qp2.run(query_str='Can I eat some orange when headache ?')
    # logging.debug(f'response: {response}')

    choices = [
        'if user ask something about movie, choose this action.',
        'if user ask something about fruit, choose this action.',
    ]

    from router.llm_selector_rel import CustomLLMSingleSelector
    selector = CustomLLMSingleSelector.from_defaults(llm=llm)
    from router_agent.custom_router_component import CustomRouterComponent as RouterComponent
    router_c = RouterComponent(
        selector=selector,
        choices=choices,
        components=[action_1, action_2],
        verbose=True,
    )
    query = flow_params['response_str']
    # query = 'can you give me some advice about watching a moive at weekend ?'
    router_output, log_str = router_c.run_component(query=query)
    logger.debug(f'router_output: {router_output}')
    component_output = router_output['output'].text
    # exit(0)
    logger.debug(f'component_output: {component_output}')

    # update record
    task.extra_state['record'].append(
        dict(layername='router',
             messages=[
                 ('user', query),
                 ('action', log_str),
                 ('assistant', component_output)
             ])
    )
    print(f'[router component] output: {component_output}')
    return {"response_str": component_output, "is_done": True}


def action_cls_component_fn(
        task: Task, state: Dict[str, Any], llm, flow_params,
):
    logger.debug(f'[cls_component task_memory] {task.memory}')
    logger.debug(f'[cls_component task_extra_state] {task.extra_state}')
    logger.debug(f'[cls_component state] {state}')
    logger.debug(f'[cls_component flow_params: {flow_params}')

    logger.debug(f'task_input: {task.input}')
    # response_last_stage = flow_params['response_str']
    request_str = task.input

    ### add output parser
    TEMPLATE = """
       Here's a JSON schema to follow:
       {schema}

       Output a valid JSON object but do not repeat the schema.
       """

    from router.parser import CustomPydanticOutputParser
    output_parser = CustomPydanticOutputParser(output_cls=ActionSelected,
                                               pydantic_format_tmpl=TEMPLATE)

    ## query template
    json_prompt_str = """
           analyse the request content and give suggestion of the next step about this topic.
           there are several choices of the next step: \n
           1. RAG: 如果客户是在询问一些问题，该问题关系到黄河或者水文站的工作安排、记录，或者相关机构下发的通知内容。以及关于伊春的林业生态规划。请选择此接口。\n
           2. BackendSearch: 如果客户的请求内容是查询一些信息，比如：森林的蓄积量及变化、城市面积、森林覆盖率排行、森林植物总生物量等，请选择此接口。\n
           3. WebSearch: 如果客户请求的内容无法通过前面RAG或者Backend提供的功能解决，同时你认为通过互联网可以查询相关信息完成回答的时候，请选择此接口。\n

           you should select only one from the choices above.
           \n Now, the request content is: {request}.
           \n Output with the following JSON format:
           """

    # json_prompt_str = """
    #            analyse the request content and give suggestion of the next step about this topic.
    #            there are several choices of the next step: \n
    #            1. RAG: 如果用户是在询问问题，该问题关系到黄河或者水文站的工作安排、记录或通知内容, 以及关于伊春的林业生态规划。请选择此接口。\n
    #            2. BackendSearch: 如果用户的请求内容是查询一些信息，比如：森林的蓄积量及变化、城市面积、森林覆盖率排行、森林植物总生物量等，请选择此接口。\n
    #            3. WebSearch: 如果客户请求的内容无法通过前面RAG或者Backend提供的功能解决，同时你认为通过互联网可以查询相关信息完成回答的时候，请选择此接口。\n
    #
    #            you should select only one from the choices above.
    #            \n Now, the request content is: {request}.
    #            \n Output with the following JSON format:
    #            """
    json_prompt_str = output_parser.format(json_prompt_str)
    json_prompt_tmpl = PromptTemplate(json_prompt_str)
    qp_cls = QueryPipeline(chain=[json_prompt_tmpl, llm, output_parser])
    # qp_router = QueryPipeline(chain=[router_c, qp_cls])
    # output = qp_router.run("which kind of fruit is benefit for human's hair ?")
    # print('----------------- final output --------------------')
    # print(output)
    cls_response = qp_cls.run_component(request=request_str)
    logger.info(f'cls_response: {cls_response}')
    # exit(0)

    ret_response = {
        'task_input': request_str,
        "cls_response": cls_response['output'],
        "step": cls_response['output'].step,
        "is_done": True
    }

    # update record
    task.extra_state['record'].append(
        dict(layername='action_cls',
             messages=[
                 ('assistant', json.dumps({
                     "step": cls_response['output'].step,
                 }, indent=4, ensure_ascii=True))
             ])
    )

    return ret_response


def rag_component_fn(
        task: Task, state: Dict[str, Any], query_engine, flow_params,
):
    query_str = task.input

    # from rag_release_v1 import query_engine_multi
    # query_engine = query_engine_multi.main()

    response = query_engine.query(query_str)

    ret_response = {
        'response_str': str(response),
        'action_type': 'RAG',
        'is_done': True
    }

    # update record
    task.extra_state['record'].append(
        dict(layername='RAG',
             messages=[
                 ('assistant', json.dumps(ret_response, indent=4, ensure_ascii=False))
             ])
    )

    return ret_response


def backend_search_component_fn(
        task: Task, state: Dict[str, Any], llm, flow_params,
):
    query_str = task.input
    from rag_release_v1 import api_params_parse
    actions = api_params_parse.completion(query_str=query_str)
    actions = actions[0:1]

    ret_response = {
        "response_str": json.dumps(actions,
                                   # indent=4
                                   ensure_ascii=False),
        'action_type': 'BackendSearch',
        "is_done": True
    }

    # update record
    task.extra_state['record'].append(
        dict(layername='backend_search',
             messages=[
                 ('assistant', json.dumps(ret_response,
                                          # indent=4,
                                          ensure_ascii=False))
             ])
    )
    return ret_response


def web_search_component_fn(
        task: Task, state: Dict[str, Any], llm, flow_params,
):
    try:
        query_str = task.input
        from rag_release_v1.ddg_service import DuckDuckGoSearchAPI
        search_api = DuckDuckGoSearchAPI()
        context = search_api.call_for_agent(query_str)

        # add branch
        prompt_str = """Answer the question based only on the following context:
                {context}
    
                Question: {question}
                """
        prompt_tmpl = PromptTemplate(prompt_str)
        prompt = prompt_tmpl.format(context=context, question=query_str)
        llm_output = llm.complete(prompt)
        logger.debug(f'llm_output: {llm_output}')
        response_str = str(llm_output)
    except Exception as e:
        logger.error(e)
        response_str = 'WebSearchAPI INVALID.'

    ret_response = {
        "response_str": response_str,
        'action_type': 'WebSearch',
        "is_done": True
    }
    # update record
    task.extra_state['record'].append(
        dict(layername='web_search',
             messages=[
                 ('assistant', json.dumps(ret_response, indent=4, ensure_ascii=False))
             ])
    )
    return ret_response


def unknown_action_component_fn(
        task: Task, state: Dict[str, Any], llm, flow_params,
):
    # query_str = task.input
    ret_response = {
        "response_str": 'Can not get valid action content.',
        'action_type': 'None',
        "is_done": False
    }

    # update record
    task.extra_state['record'].append(
        dict(layername='unknown_action',
             messages=[
                 ('assistant', json.dumps(ret_response, indent=4, ensure_ascii=True))
             ])
    )
    return ret_response


def process_agent_response_fn(
        task: Task, state: Dict[str, Any], response_dict: dict
):
    """Process agent response."""
    # return (
    #     AgentChatResponse(response_dict["response_str"]),
    #     response_dict["is_done"],
    # )

    # update record
    task.extra_state['record'].append(
        dict(layername='output',
             messages=[
                 ('assistant', response_dict["response_str"])
             ])
    )

    return (
        AgentChatResponse(response_dict["response_str"]),
        True,
    )


def main(debug=True):
    from rag_release_v1.load_model import load_model
    llm, embed_model = load_model()

    input_component = AgentInputComponent(fn=agent_input_fn)

    action_cls_component = AgentFnComponent(fn=partial(action_cls_component_fn, llm=llm))

    from rag_release_v1 import query_engine_multi
    query_engine = query_engine_multi.main()
    rag_component = AgentFnComponent(fn=partial(rag_component_fn, query_engine=query_engine))

    backend_search_component = AgentFnComponent(fn=partial(backend_search_component_fn, llm=llm))

    web_search_component = AgentFnComponent(fn=partial(web_search_component_fn, llm=llm))

    unknown_action_component = AgentFnComponent(fn=partial(unknown_action_component_fn, llm=llm))

    output_component = AgentFnComponent(fn=process_agent_response_fn)

    # from llama_index.core.query_pipeline import InputComponent
    # input = InputComponent()
    qp_router = QueryPipeline(verbose=True)
    qp_router.add_modules(
        {
            'Input': input_component,
            'ActionClassify': action_cls_component,
            'RAG': rag_component,
            'BackendSearch': backend_search_component,
            'WebSearch': web_search_component,
            'UnknownAction': unknown_action_component,
            'Output': output_component,

        }
    )
    qp_router.add_chain(['Input', 'ActionClassify'])
    qp_router.add_link(src='ActionClassify', dest='RAG',
                       condition_fn=lambda x: x['step'] == 'RAG',
                       input_fn=lambda x: x)
    qp_router.add_link(src='ActionClassify', dest='BackendSearch',
                       condition_fn=lambda x: x['step'] == 'BackendSearch',
                       input_fn=lambda x: x)
    qp_router.add_link(src='ActionClassify', dest='WebSearch',
                       condition_fn=lambda x: x['step'] == 'WebSearch',
                       input_fn=lambda x: x)
    qp_router.add_link(src='ActionClassify', dest='UnknownAction',
                       condition_fn=lambda x: x['step'] not in ['RAG', 'BackendSearch', 'WebSearch'],
                       input_fn=lambda x: x)
    qp_router.add_link(src='RAG', dest='Output')
    qp_router.add_link(src='BackendSearch', dest='Output')
    qp_router.add_link(src='WebSearch', dest='Output')
    qp_router.add_link(src='UnknownAction', dest='Output')

    ###################### AGENT ###################
    from llama_index.core.agent import QueryPipelineAgentWorker, AgentRunner
    from llama_index.core.callbacks import CallbackManager
    # agent_worker = QueryPipelineAgentWorker(qp_router)
    from router_agent.custom_qp_agent_worker import CustomQueryPipelineAgentWorker
    agent_worker = CustomQueryPipelineAgentWorker(qp_router)
    agent = AgentRunner(
        agent_worker=agent_worker,
        chat_history=[
            ChatMessage(role=MessageRole.SYSTEM,
                        content="You are a helpful assistant. can answer all questions from human beings."),
            # ChatMessage(role=MessageRole.USER, content="麻婆豆腐的制作方法？"),
        ],
        callback_manager=CallbackManager([]),
        verbose=True
    )

    if debug:

        # start task
        task = agent.create_task(
            input="山东水文局引发给高村水文站的通知中具体要求了哪些任务？",
            # input="帮我查询一下水资源局下发的关于防洪抗讯的通知",
            # input="我想了解一下伊春市各区域的森林覆盖率情况",
            # input="成都未来几天的天气情况",

            # chat_history=[],
            extra_state=dict(a=1, b=2, record=[]),
        )
        logging.debug(f'task_input: {task.input}')
        # response = agent_input_component._run_component(task=task, state={})
        # logging.debug(f'response: {response}')
        # exit(0)

        # # chat history in task.memory
        # print(f'[task memory] {task.memory}')
        # print(f'[task extra_state] {task.extra_state}')
        # exit(0)

        step_output = agent.run_step(task.task_id)
        logging.info(f'step_output: {step_output}')

        # response = agent.chat("What are some tracks from the artist AC/DC? Limit it to 3")
        # print(response)

        record = task.extra_state['record']
        print(f'################## RECORD ################## ')
        for r in record:
            print(f'- layer: {r["layername"]}')
            for m in r['messages']:
                print(f'    {m}')

    return agent


if __name__ == '__main__':
    import sys

    logging.basicConfig(stream=sys.stdout,
                        level=logging.INFO,
                        format="[%(levelname)s] %(filename)s[%(levelno)s]{%(funcName)s} %(message)s")

    import sys

    logger.remove()
    logger.add(sys.stderr, level="INFO")

    main()
