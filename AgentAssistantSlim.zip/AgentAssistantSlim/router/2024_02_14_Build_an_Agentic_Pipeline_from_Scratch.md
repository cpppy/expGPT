# Building an Agent around a Query Pipeline

In this cookbook we show you how to build an agent around a query pipeline.

Agents offer the ability to do complex, sequential reasoning on top of any query DAG that you have setup. Conceptually this is also one of the ways you can add a "loop" to the graph.

In this tutorial we show you how to build a full ReAct agent that can do tool picking from scratch.

We will be using LlamaIndex v0.10 - https://blog.llamaindex.ai/llamaindex-v0-10-838e735948f8


```python
!CMAKE_ARGS='-DLLAMA_CUBLAS=on' pip install --force-reinstall --no-cache-dir llama-cpp-python
```

    Collecting llama-cpp-python
      Downloading llama_cpp_python-0.2.44.tar.gz (36.6 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m36.6/36.6 MB[0m [31m3.0 MB/s[0m eta [36m0:00:00[0m
    [?25h  Installing build dependencies ... [?25l[?25hdone
      Getting requirements to build wheel ... [?25l[?25hdone
      Installing backend dependencies ... [?25l[?25hdone
      Preparing metadata (pyproject.toml) ... [?25l[?25hdone
    Collecting typing-extensions>=4.5.0 (from llama-cpp-python)
      Downloading typing_extensions-4.9.0-py3-none-any.whl (32 kB)
    Collecting numpy>=1.20.0 (from llama-cpp-python)
      Downloading numpy-1.26.4-cp310-cp310-manylinux_2_17_x86_64.manylinux2014_x86_64.whl (18.2 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m18.2/18.2 MB[0m [31m2.9 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting diskcache>=5.6.1 (from llama-cpp-python)
      Downloading diskcache-5.6.3-py3-none-any.whl (45 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m45.5/45.5 kB[0m [31m5.6 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting jinja2>=2.11.3 (from llama-cpp-python)
      Downloading Jinja2-3.1.3-py3-none-any.whl (133 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m133.2/133.2 kB[0m [31m3.8 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting MarkupSafe>=2.0 (from jinja2>=2.11.3->llama-cpp-python)
      Downloading MarkupSafe-2.1.5-cp310-cp310-manylinux_2_17_x86_64.manylinux2014_x86_64.whl (25 kB)
    Building wheels for collected packages: llama-cpp-python
      Building wheel for llama-cpp-python (pyproject.toml) ... [?25l[?25hdone
      Created wheel for llama-cpp-python: filename=llama_cpp_python-0.2.44-cp310-cp310-manylinux_2_35_x86_64.whl size=20531697 sha256=b1fca6c40bc11c78a665370099fb963d9691fddea15751df63a4f7fb2e1d73e4
      Stored in directory: /tmp/pip-ephem-wheel-cache-lzxcn0cz/wheels/6e/f0/52/1716aa7fefc7eb2a9b76775b0a61fc131b7dcc961e310a048a
    Successfully built llama-cpp-python
    Installing collected packages: typing-extensions, numpy, MarkupSafe, diskcache, jinja2, llama-cpp-python
      Attempting uninstall: typing-extensions
        Found existing installation: typing_extensions 4.9.0
        Uninstalling typing_extensions-4.9.0:
          Successfully uninstalled typing_extensions-4.9.0
      Attempting uninstall: numpy
        Found existing installation: numpy 1.25.2
        Uninstalling numpy-1.25.2:
          Successfully uninstalled numpy-1.25.2
      Attempting uninstall: MarkupSafe
        Found existing installation: MarkupSafe 2.1.5
        Uninstalling MarkupSafe-2.1.5:
          Successfully uninstalled MarkupSafe-2.1.5
      Attempting uninstall: jinja2
        Found existing installation: Jinja2 3.1.3
        Uninstalling Jinja2-3.1.3:
          Successfully uninstalled Jinja2-3.1.3
    Successfully installed MarkupSafe-2.1.5 diskcache-5.6.3 jinja2-3.1.3 llama-cpp-python-0.2.44 numpy-1.26.4 typing-extensions-4.9.0



```python
!wget https://huggingface.co/TheBloke/Mistral-7B-Instruct-v0.2-GGUF/resolve/main/mistral-7b-instruct-v0.2.Q4_K_M.gguf
```

    --2024-02-21 12:44:28--  https://huggingface.co/TheBloke/Mistral-7B-Instruct-v0.2-GGUF/resolve/main/mistral-7b-instruct-v0.2.Q4_K_M.gguf
    Resolving huggingface.co (huggingface.co)... 65.8.49.38, 65.8.49.2, 65.8.49.24, ...
    Connecting to huggingface.co (huggingface.co)|65.8.49.38|:443... connected.
    HTTP request sent, awaiting response... 302 Found
    Location: https://cdn-lfs-us-1.huggingface.co/repos/72/62/726219e98582d16c24a66629a4dec1b0761b91c918e15dea2625b4293c134a92/3e0039fd0273fcbebb49228943b17831aadd55cbcbf56f0af00499be2040ccf9?response-content-disposition=attachment%3B+filename*%3DUTF-8%27%27mistral-7b-instruct-v0.2.Q4_K_M.gguf%3B+filename%3D%22mistral-7b-instruct-v0.2.Q4_K_M.gguf%22%3B&Expires=1708777998&Policy=eyJTdGF0ZW1lbnQiOlt7IkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTcwODc3Nzk5OH19LCJSZXNvdXJjZSI6Imh0dHBzOi8vY2RuLWxmcy11cy0xLmh1Z2dpbmdmYWNlLmNvL3JlcG9zLzcyLzYyLzcyNjIxOWU5ODU4MmQxNmMyNGE2NjYyOWE0ZGVjMWIwNzYxYjkxYzkxOGUxNWRlYTI2MjViNDI5M2MxMzRhOTIvM2UwMDM5ZmQwMjczZmNiZWJiNDkyMjg5NDNiMTc4MzFhYWRkNTVjYmNiZjU2ZjBhZjAwNDk5YmUyMDQwY2NmOT9yZXNwb25zZS1jb250ZW50LWRpc3Bvc2l0aW9uPSoifV19&Signature=YXZVGypUFWX9zxgbXGxEKJmYKD8Xjdtmb7fOg6dra8DYNUm037udKH8stVTKk3Un7tSEATXAymFLtApPO6A0uPCyiRn7puB8p8gJKv7xFBApC6FnYSJcBeEbPCWXPh8CJnZVFlbCEIEmxWq6mJYtTdPmVfbytepHH703egK7SywkCN2H4H-zUFfutcT%7Eo3695V456FIRLaiq6j981VLQXZr0btKmLGl9E1cnTUuHk2lQHubgQ5ywAxAZJ1GaYkLHDseMx53m46Ynp3etJEIepwLDQq5be6l%7E2YJZMicecQx%7EEm7pLhaMtVh6GrpOHU5dd82ustLtzbkhAaVlfCbKTg__&Key-Pair-Id=KCD77M1F0VK2B [following]
    --2024-02-21 12:44:28--  https://cdn-lfs-us-1.huggingface.co/repos/72/62/726219e98582d16c24a66629a4dec1b0761b91c918e15dea2625b4293c134a92/3e0039fd0273fcbebb49228943b17831aadd55cbcbf56f0af00499be2040ccf9?response-content-disposition=attachment%3B+filename*%3DUTF-8%27%27mistral-7b-instruct-v0.2.Q4_K_M.gguf%3B+filename%3D%22mistral-7b-instruct-v0.2.Q4_K_M.gguf%22%3B&Expires=1708777998&Policy=eyJTdGF0ZW1lbnQiOlt7IkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTcwODc3Nzk5OH19LCJSZXNvdXJjZSI6Imh0dHBzOi8vY2RuLWxmcy11cy0xLmh1Z2dpbmdmYWNlLmNvL3JlcG9zLzcyLzYyLzcyNjIxOWU5ODU4MmQxNmMyNGE2NjYyOWE0ZGVjMWIwNzYxYjkxYzkxOGUxNWRlYTI2MjViNDI5M2MxMzRhOTIvM2UwMDM5ZmQwMjczZmNiZWJiNDkyMjg5NDNiMTc4MzFhYWRkNTVjYmNiZjU2ZjBhZjAwNDk5YmUyMDQwY2NmOT9yZXNwb25zZS1jb250ZW50LWRpc3Bvc2l0aW9uPSoifV19&Signature=YXZVGypUFWX9zxgbXGxEKJmYKD8Xjdtmb7fOg6dra8DYNUm037udKH8stVTKk3Un7tSEATXAymFLtApPO6A0uPCyiRn7puB8p8gJKv7xFBApC6FnYSJcBeEbPCWXPh8CJnZVFlbCEIEmxWq6mJYtTdPmVfbytepHH703egK7SywkCN2H4H-zUFfutcT%7Eo3695V456FIRLaiq6j981VLQXZr0btKmLGl9E1cnTUuHk2lQHubgQ5ywAxAZJ1GaYkLHDseMx53m46Ynp3etJEIepwLDQq5be6l%7E2YJZMicecQx%7EEm7pLhaMtVh6GrpOHU5dd82ustLtzbkhAaVlfCbKTg__&Key-Pair-Id=KCD77M1F0VK2B
    Resolving cdn-lfs-us-1.huggingface.co (cdn-lfs-us-1.huggingface.co)... 108.156.107.49, 108.156.107.80, 108.156.107.44, ...
    Connecting to cdn-lfs-us-1.huggingface.co (cdn-lfs-us-1.huggingface.co)|108.156.107.49|:443... connected.
    HTTP request sent, awaiting response... 200 OK
    Length: 4368439584 (4.1G) [binary/octet-stream]
    Saving to: ‘mistral-7b-instruct-v0.2.Q4_K_M.gguf’
    
    mistral-7b-instruct 100%[===================>]   4.07G   249MB/s    in 26s     
    
    2024-02-21 12:44:55 (159 MB/s) - ‘mistral-7b-instruct-v0.2.Q4_K_M.gguf’ saved [4368439584/4368439584]
    



```python
pip install llama-index==0.10.7 llama-index-llms-llama-cpp
```

    Collecting llama-index==0.10.7
      Downloading llama_index-0.10.7-py3-none-any.whl (5.6 kB)
    Collecting llama-index-llms-llama-cpp
      Downloading llama_index_llms_llama_cpp-0.1.2-py3-none-any.whl (5.3 kB)
    Collecting llama-index-agent-openai<0.2.0,>=0.1.0 (from llama-index==0.10.7)
      Downloading llama_index_agent_openai-0.1.4-py3-none-any.whl (12 kB)
    Collecting llama-index-core<0.11.0,>=0.10.0 (from llama-index==0.10.7)
      Downloading llama_index_core-0.10.10-py3-none-any.whl (15.4 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m15.4/15.4 MB[0m [31m37.3 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting llama-index-embeddings-openai<0.2.0,>=0.1.0 (from llama-index==0.10.7)
      Downloading llama_index_embeddings_openai-0.1.5-py3-none-any.whl (6.2 kB)
    Collecting llama-index-legacy<0.10.0,>=0.9.48 (from llama-index==0.10.7)
      Downloading llama_index_legacy-0.9.48-py3-none-any.whl (2.0 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m2.0/2.0 MB[0m [31m53.0 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting llama-index-llms-openai<0.2.0,>=0.1.0 (from llama-index==0.10.7)
      Downloading llama_index_llms_openai-0.1.5-py3-none-any.whl (9.6 kB)
    Collecting llama-index-multi-modal-llms-openai<0.2.0,>=0.1.0 (from llama-index==0.10.7)
      Downloading llama_index_multi_modal_llms_openai-0.1.3-py3-none-any.whl (6.0 kB)
    Collecting llama-index-program-openai<0.2.0,>=0.1.0 (from llama-index==0.10.7)
      Downloading llama_index_program_openai-0.1.3-py3-none-any.whl (4.3 kB)
    Collecting llama-index-question-gen-openai<0.2.0,>=0.1.0 (from llama-index==0.10.7)
      Downloading llama_index_question_gen_openai-0.1.2-py3-none-any.whl (3.1 kB)
    Collecting llama-index-readers-file<0.2.0,>=0.1.0 (from llama-index==0.10.7)
      Downloading llama_index_readers_file-0.1.4-py3-none-any.whl (36 kB)
    Requirement already satisfied: llama-cpp-python<0.3.0,>=0.2.32 in /usr/local/lib/python3.10/dist-packages (from llama-index-llms-llama-cpp) (0.2.44)
    Requirement already satisfied: typing-extensions>=4.5.0 in /usr/local/lib/python3.10/dist-packages (from llama-cpp-python<0.3.0,>=0.2.32->llama-index-llms-llama-cpp) (4.9.0)
    Requirement already satisfied: numpy>=1.20.0 in /usr/local/lib/python3.10/dist-packages (from llama-cpp-python<0.3.0,>=0.2.32->llama-index-llms-llama-cpp) (1.26.4)
    Requirement already satisfied: diskcache>=5.6.1 in /usr/local/lib/python3.10/dist-packages (from llama-cpp-python<0.3.0,>=0.2.32->llama-index-llms-llama-cpp) (5.6.3)
    Requirement already satisfied: jinja2>=2.11.3 in /usr/local/lib/python3.10/dist-packages (from llama-cpp-python<0.3.0,>=0.2.32->llama-index-llms-llama-cpp) (3.1.3)
    Requirement already satisfied: PyYAML>=6.0.1 in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (6.0.1)
    Requirement already satisfied: SQLAlchemy[asyncio]>=1.4.49 in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (2.0.27)
    Requirement already satisfied: aiohttp<4.0.0,>=3.8.6 in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (3.9.3)
    Collecting dataclasses-json (from llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7)
      Downloading dataclasses_json-0.6.4-py3-none-any.whl (28 kB)
    Collecting deprecated>=1.2.9.3 (from llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7)
      Downloading Deprecated-1.2.14-py2.py3-none-any.whl (9.6 kB)
    Collecting dirtyjson<2.0.0,>=1.0.8 (from llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7)
      Downloading dirtyjson-1.0.8-py3-none-any.whl (25 kB)
    Requirement already satisfied: fsspec>=2023.5.0 in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (2023.6.0)
    Collecting httpx (from llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7)
      Downloading httpx-0.26.0-py3-none-any.whl (75 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m75.9/75.9 kB[0m [31m10.4 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting llamaindex-py-client<0.2.0,>=0.1.13 (from llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7)
      Downloading llamaindex_py_client-0.1.13-py3-none-any.whl (107 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m108.0/108.0 kB[0m [31m12.7 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: nest-asyncio<2.0.0,>=1.5.8 in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (1.6.0)
    Requirement already satisfied: networkx>=3.0 in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (3.2.1)
    Requirement already satisfied: nltk<4.0.0,>=3.8.1 in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (3.8.1)
    Collecting openai>=1.1.0 (from llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7)
      Downloading openai-1.12.0-py3-none-any.whl (226 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m226.7/226.7 kB[0m [31m23.6 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: pandas in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (1.5.3)
    Requirement already satisfied: pillow>=9.0.0 in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (9.4.0)
    Requirement already satisfied: requests>=2.31.0 in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (2.31.0)
    Requirement already satisfied: tenacity<9.0.0,>=8.2.0 in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (8.2.3)
    Collecting tiktoken>=0.3.3 (from llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7)
      Downloading tiktoken-0.6.0-cp310-cp310-manylinux_2_17_x86_64.manylinux2014_x86_64.whl (1.8 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m1.8/1.8 MB[0m [31m56.3 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: tqdm<5.0.0,>=4.66.1 in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (4.66.2)
    Collecting typing-inspect>=0.8.0 (from llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7)
      Downloading typing_inspect-0.9.0-py3-none-any.whl (8.8 kB)
    Requirement already satisfied: beautifulsoup4<5.0.0,>=4.12.3 in /usr/local/lib/python3.10/dist-packages (from llama-index-readers-file<0.2.0,>=0.1.0->llama-index==0.10.7) (4.12.3)
    Collecting bs4<0.0.3,>=0.0.2 (from llama-index-readers-file<0.2.0,>=0.1.0->llama-index==0.10.7)
      Downloading bs4-0.0.2-py2.py3-none-any.whl (1.2 kB)
    Collecting pymupdf<2.0.0,>=1.23.21 (from llama-index-readers-file<0.2.0,>=0.1.0->llama-index==0.10.7)
      Downloading PyMuPDF-1.23.25-cp310-none-manylinux2014_x86_64.whl (4.4 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m4.4/4.4 MB[0m [31m54.6 MB/s[0m eta [36m0:00:00[0m
    [?25hCollecting pypdf<5.0.0,>=4.0.1 (from llama-index-readers-file<0.2.0,>=0.1.0->llama-index==0.10.7)
      Downloading pypdf-4.0.2-py3-none-any.whl (283 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m284.0/284.0 kB[0m [31m28.7 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: aiosignal>=1.1.2 in /usr/local/lib/python3.10/dist-packages (from aiohttp<4.0.0,>=3.8.6->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (1.3.1)
    Requirement already satisfied: attrs>=17.3.0 in /usr/local/lib/python3.10/dist-packages (from aiohttp<4.0.0,>=3.8.6->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (23.2.0)
    Requirement already satisfied: frozenlist>=1.1.1 in /usr/local/lib/python3.10/dist-packages (from aiohttp<4.0.0,>=3.8.6->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (1.4.1)
    Requirement already satisfied: multidict<7.0,>=4.5 in /usr/local/lib/python3.10/dist-packages (from aiohttp<4.0.0,>=3.8.6->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (6.0.5)
    Requirement already satisfied: yarl<2.0,>=1.0 in /usr/local/lib/python3.10/dist-packages (from aiohttp<4.0.0,>=3.8.6->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (1.9.4)
    Requirement already satisfied: async-timeout<5.0,>=4.0 in /usr/local/lib/python3.10/dist-packages (from aiohttp<4.0.0,>=3.8.6->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (4.0.3)
    Requirement already satisfied: soupsieve>1.2 in /usr/local/lib/python3.10/dist-packages (from beautifulsoup4<5.0.0,>=4.12.3->llama-index-readers-file<0.2.0,>=0.1.0->llama-index==0.10.7) (2.5)
    Requirement already satisfied: wrapt<2,>=1.10 in /usr/local/lib/python3.10/dist-packages (from deprecated>=1.2.9.3->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (1.14.1)
    Requirement already satisfied: MarkupSafe>=2.0 in /usr/local/lib/python3.10/dist-packages (from jinja2>=2.11.3->llama-cpp-python<0.3.0,>=0.2.32->llama-index-llms-llama-cpp) (2.1.5)
    Requirement already satisfied: pydantic>=1.10 in /usr/local/lib/python3.10/dist-packages (from llamaindex-py-client<0.2.0,>=0.1.13->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (2.6.1)
    Requirement already satisfied: anyio in /usr/local/lib/python3.10/dist-packages (from httpx->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (3.7.1)
    Requirement already satisfied: certifi in /usr/local/lib/python3.10/dist-packages (from httpx->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (2024.2.2)
    Collecting httpcore==1.* (from httpx->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7)
      Downloading httpcore-1.0.3-py3-none-any.whl (77 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m77.0/77.0 kB[0m [31m9.6 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: idna in /usr/local/lib/python3.10/dist-packages (from httpx->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (3.6)
    Requirement already satisfied: sniffio in /usr/local/lib/python3.10/dist-packages (from httpx->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (1.3.0)
    Collecting h11<0.15,>=0.13 (from httpcore==1.*->httpx->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7)
      Downloading h11-0.14.0-py3-none-any.whl (58 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m58.3/58.3 kB[0m [31m8.3 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: click in /usr/local/lib/python3.10/dist-packages (from nltk<4.0.0,>=3.8.1->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (8.1.7)
    Requirement already satisfied: joblib in /usr/local/lib/python3.10/dist-packages (from nltk<4.0.0,>=3.8.1->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (1.3.2)
    Requirement already satisfied: regex>=2021.8.3 in /usr/local/lib/python3.10/dist-packages (from nltk<4.0.0,>=3.8.1->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (2023.12.25)
    Requirement already satisfied: distro<2,>=1.7.0 in /usr/lib/python3/dist-packages (from openai>=1.1.0->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (1.7.0)
    Collecting PyMuPDFb==1.23.22 (from pymupdf<2.0.0,>=1.23.21->llama-index-readers-file<0.2.0,>=0.1.0->llama-index==0.10.7)
      Downloading PyMuPDFb-1.23.22-py3-none-manylinux2014_x86_64.manylinux_2_17_x86_64.whl (30.6 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m30.6/30.6 MB[0m [31m13.7 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: charset-normalizer<4,>=2 in /usr/local/lib/python3.10/dist-packages (from requests>=2.31.0->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (3.3.2)
    Requirement already satisfied: urllib3<3,>=1.21.1 in /usr/local/lib/python3.10/dist-packages (from requests>=2.31.0->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (2.0.7)
    Requirement already satisfied: greenlet!=0.4.17 in /usr/local/lib/python3.10/dist-packages (from SQLAlchemy[asyncio]>=1.4.49->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (3.0.3)
    Collecting mypy-extensions>=0.3.0 (from typing-inspect>=0.8.0->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7)
      Downloading mypy_extensions-1.0.0-py3-none-any.whl (4.7 kB)
    Collecting marshmallow<4.0.0,>=3.18.0 (from dataclasses-json->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7)
      Downloading marshmallow-3.20.2-py3-none-any.whl (49 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m49.4/49.4 kB[0m [31m4.2 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: python-dateutil>=2.8.1 in /usr/local/lib/python3.10/dist-packages (from pandas->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (2.8.2)
    Requirement already satisfied: pytz>=2020.1 in /usr/local/lib/python3.10/dist-packages (from pandas->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (2023.4)
    Requirement already satisfied: exceptiongroup in /usr/local/lib/python3.10/dist-packages (from anyio->httpx->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (1.2.0)
    Requirement already satisfied: packaging>=17.0 in /usr/local/lib/python3.10/dist-packages (from marshmallow<4.0.0,>=3.18.0->dataclasses-json->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (23.2)
    Requirement already satisfied: annotated-types>=0.4.0 in /usr/local/lib/python3.10/dist-packages (from pydantic>=1.10->llamaindex-py-client<0.2.0,>=0.1.13->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (0.6.0)
    Requirement already satisfied: pydantic-core==2.16.2 in /usr/local/lib/python3.10/dist-packages (from pydantic>=1.10->llamaindex-py-client<0.2.0,>=0.1.13->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (2.16.2)
    Requirement already satisfied: six>=1.5 in /usr/local/lib/python3.10/dist-packages (from python-dateutil>=2.8.1->pandas->llama-index-core<0.11.0,>=0.10.0->llama-index==0.10.7) (1.16.0)
    Installing collected packages: dirtyjson, pypdf, PyMuPDFb, mypy-extensions, marshmallow, h11, deprecated, typing-inspect, tiktoken, pymupdf, httpcore, bs4, httpx, dataclasses-json, openai, llamaindex-py-client, llama-index-legacy, llama-index-core, llama-index-readers-file, llama-index-llms-openai, llama-index-llms-llama-cpp, llama-index-embeddings-openai, llama-index-multi-modal-llms-openai, llama-index-agent-openai, llama-index-program-openai, llama-index-question-gen-openai, llama-index
    Successfully installed PyMuPDFb-1.23.22 bs4-0.0.2 dataclasses-json-0.6.4 deprecated-1.2.14 dirtyjson-1.0.8 h11-0.14.0 httpcore-1.0.3 httpx-0.26.0 llama-index-0.10.7 llama-index-agent-openai-0.1.4 llama-index-core-0.10.10 llama-index-embeddings-openai-0.1.5 llama-index-legacy-0.9.48 llama-index-llms-llama-cpp-0.1.2 llama-index-llms-openai-0.1.5 llama-index-multi-modal-llms-openai-0.1.3 llama-index-program-openai-0.1.3 llama-index-question-gen-openai-0.1.2 llama-index-readers-file-0.1.4 llamaindex-py-client-0.1.13 marshmallow-3.20.2 mypy-extensions-1.0.0 openai-1.12.0 pymupdf-1.23.25 pypdf-4.0.2 tiktoken-0.6.0 typing-inspect-0.9.0



```python
!pip show numpy
```

    Name: numpy
    Version: 1.25.2
    Summary: Fundamental package for array computing in Python
    Home-page: https://www.numpy.org
    Author: Travis E. Oliphant et al.
    Author-email: 
    License: BSD-3-Clause
    Location: /usr/local/lib/python3.10/dist-packages
    Requires: 
    Required-by: albumentations, altair, arviz, astropy, autograd, blis, bokeh, bqplot, chex, cmdstanpy, contourpy, cufflinks, cupy-cuda12x, cvxpy, datascience, db-dtypes, dopamine-rl, ecos, flax, folium, geemap, gensim, gym, h5py, holoviews, hyperopt, ibis-framework, imageio, imbalanced-learn, imgaug, jax, jaxlib, librosa, lightgbm, matplotlib, matplotlib-venn, missingno, mizani, ml-dtypes, mlxtend, moviepy, music21, nibabel, numba, numexpr, opencv-contrib-python, opencv-python, opencv-python-headless, opt-einsum, optax, orbax-checkpoint, osqp, pandas, pandas-gbq, patsy, plotnine, prophet, pyarrow, pycocotools, pyerfa, pymc, pytensor, python-louvain, PyWavelets, qdldl, qudida, scikit-image, scikit-learn, scipy, scs, seaborn, shapely, sklearn-pandas, soxr, spacy, stanio, statsmodels, tables, tensorboard, tensorflow, tensorflow-datasets, tensorflow-hub, tensorflow-probability, tensorstore, thinc, tifffile, torchtext, torchvision, transformers, wordcloud, xarray, xarray-einstats, xgboost, yellowbrick, yfinance



```python
!pip uninstall -y numpy
!pip uninstall -y setuptools
!pip install setuptools
!pip install numpy==1.24.4
```

    Found existing installation: numpy 1.26.4
    Uninstalling numpy-1.26.4:
      Successfully uninstalled numpy-1.26.4
    Found existing installation: setuptools 67.7.2
    Uninstalling setuptools-67.7.2:
      Successfully uninstalled setuptools-67.7.2
    Collecting setuptools
      Downloading setuptools-69.1.0-py3-none-any.whl (819 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m819.3/819.3 kB[0m [31m4.0 MB/s[0m eta [36m0:00:00[0m
    [?25hInstalling collected packages: setuptools
    [31mERROR: pip's dependency resolver does not currently take into account all the packages that are installed. This behaviour is the source of the following dependency conflicts.
    arviz 0.15.1 requires numpy>=1.20.0, which is not installed.
    cufflinks 0.17.3 requires numpy>=1.9.2, which is not installed.
    cvxpy 1.3.3 requires numpy>=1.15, which is not installed.
    datascience 0.17.6 requires numpy, which is not installed.
    ipython 7.34.0 requires jedi>=0.16, which is not installed.
    mlxtend 0.22.0 requires numpy>=1.16.2, which is not installed.
    moviepy 1.0.3 requires numpy; python_version >= "2.7", which is not installed.
    moviepy 1.0.3 requires numpy>=1.17.3; python_version != "2.7", which is not installed.
    nibabel 4.0.2 requires numpy>=1.17, which is not installed.
    pandas-gbq 0.19.2 requires numpy>=1.16.6, which is not installed.
    pymc 5.7.2 requires numpy>=1.15.0, which is not installed.
    pytensor 2.14.2 requires numpy>=1.17.0, which is not installed.
    spacy 3.7.4 requires numpy>=1.19.0; python_version >= "3.9", which is not installed.
    tensorboard 2.15.2 requires numpy>=1.12.0, which is not installed.
    tensorflow 2.15.0 requires numpy<2.0.0,>=1.23.5, which is not installed.
    thinc 8.2.3 requires numpy>=1.19.0; python_version >= "3.9", which is not installed.[0m[31m
    [0mSuccessfully installed setuptools-69.1.0




    Collecting numpy==1.24.4
      Downloading numpy-1.24.4-cp310-cp310-manylinux_2_17_x86_64.manylinux2014_x86_64.whl (17.3 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m17.3/17.3 MB[0m [31m28.5 MB/s[0m eta [36m0:00:00[0m
    [?25hInstalling collected packages: numpy
    Successfully installed numpy-1.24.4




Hay que reiniciar la session para poder actualizar


```python
import numpy
print(numpy.__version__)
```

    1.24.4



```python
import numpy
import scipy
import nltk
import numpy.linalg
import numpy.linalg._umath_linalg
# print(numpy.linalg._umath_linalg._ilp64)
import numpy.linalg._umath_linalg._ilp64
```


    ---------------------------------------------------------------------------

    ModuleNotFoundError                       Traceback (most recent call last)

    <ipython-input-1-ace3585c2ad1> in <cell line: 7>()
          5 import numpy.linalg._umath_linalg
          6 # print(numpy.linalg._umath_linalg._ilp64)
    ----> 7 import numpy.linalg._umath_linalg._ilp64
    

    ModuleNotFoundError: No module named 'numpy.linalg._umath_linalg._ilp64'; 'numpy.linalg._umath_linalg' is not a package

    

    ---------------------------------------------------------------------------
    NOTE: If your import is failing due to a missing package, you can
    manually install dependencies using either !pip or !apt.
    
    To view examples of installing some common dependencies, click the
    "Open Examples" button below.
    ---------------------------------------------------------------------------



Instanciating the Local LLM, with LlamaCpp , Mistral AI


```python
import torch

# from llama_index.legacy.llms import LlamaCPP
# from llama_index.llms.llama_utils import messages_to_prompt, completion_to_prompt
# MIGRAMOS A v0.10
from llama_index.llms.llama_cpp import LlamaCPP
from llama_index.llms.llama_cpp.llama_utils import (
    messages_to_prompt,
    completion_to_prompt,
)
llm = LlamaCPP(
    model_url=None, # We'll load locally.
    model_path='./mistral-7b-instruct-v0.2.Q4_K_M.gguf', # 4-bit model
    temperature=0.1,
    max_new_tokens=1024, # Increasing to support longer responses
    context_window=3900, # Mistral7B has an 8K context-window
    generate_kwargs={},
    # set to at least 1 to use GPU
    model_kwargs={"n_gpu_layers": -1}, # 40 was a good amount of layers for the RTX 3090, you may need to decrease yours if you have less VRAM than 24GB
    messages_to_prompt=messages_to_prompt,
    completion_to_prompt=completion_to_prompt,
    verbose=True
)
```

    llama_model_loader: loaded meta data with 24 key-value pairs and 291 tensors from ./mistral-7b-instruct-v0.2.Q4_K_M.gguf (version GGUF V3 (latest))
    llama_model_loader: Dumping metadata keys/values. Note: KV overrides do not apply in this output.
    llama_model_loader: - kv   0:                       general.architecture str              = llama
    llama_model_loader: - kv   1:                               general.name str              = mistralai_mistral-7b-instruct-v0.2
    llama_model_loader: - kv   2:                       llama.context_length u32              = 32768
    llama_model_loader: - kv   3:                     llama.embedding_length u32              = 4096
    llama_model_loader: - kv   4:                          llama.block_count u32              = 32
    llama_model_loader: - kv   5:                  llama.feed_forward_length u32              = 14336
    llama_model_loader: - kv   6:                 llama.rope.dimension_count u32              = 128
    llama_model_loader: - kv   7:                 llama.attention.head_count u32              = 32
    llama_model_loader: - kv   8:              llama.attention.head_count_kv u32              = 8
    llama_model_loader: - kv   9:     llama.attention.layer_norm_rms_epsilon f32              = 0.000010
    llama_model_loader: - kv  10:                       llama.rope.freq_base f32              = 1000000.000000
    llama_model_loader: - kv  11:                          general.file_type u32              = 15
    llama_model_loader: - kv  12:                       tokenizer.ggml.model str              = llama
    llama_model_loader: - kv  13:                      tokenizer.ggml.tokens arr[str,32000]   = ["<unk>", "<s>", "</s>", "<0x00>", "<...
    llama_model_loader: - kv  14:                      tokenizer.ggml.scores arr[f32,32000]   = [0.000000, 0.000000, 0.000000, 0.0000...
    llama_model_loader: - kv  15:                  tokenizer.ggml.token_type arr[i32,32000]   = [2, 3, 3, 6, 6, 6, 6, 6, 6, 6, 6, 6, ...
    llama_model_loader: - kv  16:                tokenizer.ggml.bos_token_id u32              = 1
    llama_model_loader: - kv  17:                tokenizer.ggml.eos_token_id u32              = 2
    llama_model_loader: - kv  18:            tokenizer.ggml.unknown_token_id u32              = 0
    llama_model_loader: - kv  19:            tokenizer.ggml.padding_token_id u32              = 0
    llama_model_loader: - kv  20:               tokenizer.ggml.add_bos_token bool             = true
    llama_model_loader: - kv  21:               tokenizer.ggml.add_eos_token bool             = false
    llama_model_loader: - kv  22:                    tokenizer.chat_template str              = {{ bos_token }}{% for message in mess...
    llama_model_loader: - kv  23:               general.quantization_version u32              = 2
    llama_model_loader: - type  f32:   65 tensors
    llama_model_loader: - type q4_K:  193 tensors
    llama_model_loader: - type q6_K:   33 tensors
    llm_load_vocab: special tokens definition check successful ( 259/32000 ).
    llm_load_print_meta: format           = GGUF V3 (latest)
    llm_load_print_meta: arch             = llama
    llm_load_print_meta: vocab type       = SPM
    llm_load_print_meta: n_vocab          = 32000
    llm_load_print_meta: n_merges         = 0
    llm_load_print_meta: n_ctx_train      = 32768
    llm_load_print_meta: n_embd           = 4096
    llm_load_print_meta: n_head           = 32
    llm_load_print_meta: n_head_kv        = 8
    llm_load_print_meta: n_layer          = 32
    llm_load_print_meta: n_rot            = 128
    llm_load_print_meta: n_embd_head_k    = 128
    llm_load_print_meta: n_embd_head_v    = 128
    llm_load_print_meta: n_gqa            = 4
    llm_load_print_meta: n_embd_k_gqa     = 1024
    llm_load_print_meta: n_embd_v_gqa     = 1024
    llm_load_print_meta: f_norm_eps       = 0.0e+00
    llm_load_print_meta: f_norm_rms_eps   = 1.0e-05
    llm_load_print_meta: f_clamp_kqv      = 0.0e+00
    llm_load_print_meta: f_max_alibi_bias = 0.0e+00
    llm_load_print_meta: n_ff             = 14336
    llm_load_print_meta: n_expert         = 0
    llm_load_print_meta: n_expert_used    = 0
    llm_load_print_meta: rope scaling     = linear
    llm_load_print_meta: freq_base_train  = 1000000.0
    llm_load_print_meta: freq_scale_train = 1
    llm_load_print_meta: n_yarn_orig_ctx  = 32768
    llm_load_print_meta: rope_finetuned   = unknown
    llm_load_print_meta: model type       = 7B
    llm_load_print_meta: model ftype      = Q4_K - Medium
    llm_load_print_meta: model params     = 7.24 B
    llm_load_print_meta: model size       = 4.07 GiB (4.83 BPW) 
    llm_load_print_meta: general.name     = mistralai_mistral-7b-instruct-v0.2
    llm_load_print_meta: BOS token        = 1 '<s>'
    llm_load_print_meta: EOS token        = 2 '</s>'
    llm_load_print_meta: UNK token        = 0 '<unk>'
    llm_load_print_meta: PAD token        = 0 '<unk>'
    llm_load_print_meta: LF token         = 13 '<0x0A>'
    llm_load_tensors: ggml ctx size =    0.22 MiB
    llm_load_tensors: offloading 32 repeating layers to GPU
    llm_load_tensors: offloading non-repeating layers to GPU
    llm_load_tensors: offloaded 33/33 layers to GPU
    llm_load_tensors:        CPU buffer size =    70.31 MiB
    llm_load_tensors:      CUDA0 buffer size =  4095.05 MiB
    ...............................................................................................
    llama_new_context_with_model: n_ctx      = 3900
    llama_new_context_with_model: freq_base  = 1000000.0
    llama_new_context_with_model: freq_scale = 1
    llama_kv_cache_init:      CUDA0 KV buffer size =   487.50 MiB
    llama_new_context_with_model: KV self size  =  487.50 MiB, K (f16):  243.75 MiB, V (f16):  243.75 MiB
    llama_new_context_with_model:  CUDA_Host input buffer size   =    16.64 MiB
    llama_new_context_with_model:      CUDA0 compute buffer size =   283.37 MiB
    llama_new_context_with_model:  CUDA_Host compute buffer size =     8.00 MiB
    llama_new_context_with_model: graph splits (measure): 3
    AVX = 1 | AVX_VNNI = 0 | AVX2 = 1 | AVX512 = 0 | AVX512_VBMI = 0 | AVX512_VNNI = 0 | FMA = 1 | NEON = 0 | ARM_FMA = 0 | F16C = 1 | FP16_VA = 0 | WASM_SIMD = 0 | BLAS = 1 | SSE3 = 1 | SSSE3 = 1 | VSX = 0 | MATMUL_INT8 = 0 | 
    Model metadata: {'tokenizer.chat_template': "{{ bos_token }}{% for message in messages %}{% if (message['role'] == 'user') != (loop.index0 % 2 == 0) %}{{ raise_exception('Conversation roles must alternate user/assistant/user/assistant/...') }}{% endif %}{% if message['role'] == 'user' %}{{ '[INST] ' + message['content'] + ' [/INST]' }}{% elif message['role'] == 'assistant' %}{{ message['content'] + eos_token}}{% else %}{{ raise_exception('Only user and assistant roles are supported!') }}{% endif %}{% endfor %}", 'tokenizer.ggml.add_eos_token': 'false', 'tokenizer.ggml.padding_token_id': '0', 'tokenizer.ggml.unknown_token_id': '0', 'tokenizer.ggml.eos_token_id': '2', 'general.architecture': 'llama', 'llama.rope.freq_base': '1000000.000000', 'llama.context_length': '32768', 'general.name': 'mistralai_mistral-7b-instruct-v0.2', 'tokenizer.ggml.add_bos_token': 'true', 'llama.embedding_length': '4096', 'llama.feed_forward_length': '14336', 'llama.attention.layer_norm_rms_epsilon': '0.000010', 'llama.rope.dimension_count': '128', 'tokenizer.ggml.bos_token_id': '1', 'llama.attention.head_count': '32', 'llama.block_count': '32', 'llama.attention.head_count_kv': '8', 'general.quantization_version': '2', 'tokenizer.ggml.model': 'llama', 'general.file_type': '15'}
    Using chat template: {{ bos_token }}{% for message in messages %}{% if (message['role'] == 'user') != (loop.index0 % 2 == 0) %}{{ raise_exception('Conversation roles must alternate user/assistant/user/assistant/...') }}{% endif %}{% if message['role'] == 'user' %}{{ '[INST] ' + message['content'] + ' [/INST]' }}{% elif message['role'] == 'assistant' %}{{ message['content'] + eos_token}}{% else %}{{ raise_exception('Only user and assistant roles are supported!') }}{% endif %}{% endfor %}
    Using chat eos_token: 
    Using chat bos_token: 


Instanciating the local Embedding model with huggingface embedding model **BAAI/bge-small-en-v1.5**


```python
!pip install llama-index-embeddings-huggingface
```

    Requirement already satisfied: llama-index-embeddings-huggingface in /usr/local/lib/python3.10/dist-packages (0.1.1)
    Requirement already satisfied: huggingface-hub[inference]>=0.19.0 in /usr/local/lib/python3.10/dist-packages (from llama-index-embeddings-huggingface) (0.20.3)
    Requirement already satisfied: llama-index-core<0.11.0,>=0.10.1 in /usr/local/lib/python3.10/dist-packages (from llama-index-embeddings-huggingface) (0.10.10)
    Requirement already satisfied: torch<3.0.0,>=2.1.2 in /usr/local/lib/python3.10/dist-packages (from llama-index-embeddings-huggingface) (2.2.0)
    Requirement already satisfied: transformers<5.0.0,>=4.37.0 in /usr/local/lib/python3.10/dist-packages (from llama-index-embeddings-huggingface) (4.37.2)
    Requirement already satisfied: filelock in /usr/local/lib/python3.10/dist-packages (from huggingface-hub[inference]>=0.19.0->llama-index-embeddings-huggingface) (3.13.1)
    Requirement already satisfied: fsspec>=2023.5.0 in /usr/local/lib/python3.10/dist-packages (from huggingface-hub[inference]>=0.19.0->llama-index-embeddings-huggingface) (2023.6.0)
    Requirement already satisfied: requests in /usr/local/lib/python3.10/dist-packages (from huggingface-hub[inference]>=0.19.0->llama-index-embeddings-huggingface) (2.31.0)
    Requirement already satisfied: tqdm>=4.42.1 in /usr/local/lib/python3.10/dist-packages (from huggingface-hub[inference]>=0.19.0->llama-index-embeddings-huggingface) (4.66.2)
    Requirement already satisfied: pyyaml>=5.1 in /usr/local/lib/python3.10/dist-packages (from huggingface-hub[inference]>=0.19.0->llama-index-embeddings-huggingface) (6.0.1)
    Requirement already satisfied: typing-extensions>=3.7.4.3 in /usr/local/lib/python3.10/dist-packages (from huggingface-hub[inference]>=0.19.0->llama-index-embeddings-huggingface) (4.9.0)
    Requirement already satisfied: packaging>=20.9 in /usr/local/lib/python3.10/dist-packages (from huggingface-hub[inference]>=0.19.0->llama-index-embeddings-huggingface) (23.2)
    Requirement already satisfied: aiohttp in /usr/local/lib/python3.10/dist-packages (from huggingface-hub[inference]>=0.19.0->llama-index-embeddings-huggingface) (3.9.3)
    Requirement already satisfied: pydantic<3.0,>1.1 in /usr/local/lib/python3.10/dist-packages (from huggingface-hub[inference]>=0.19.0->llama-index-embeddings-huggingface) (2.6.1)
    Requirement already satisfied: SQLAlchemy[asyncio]>=1.4.49 in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (2.0.27)
    Requirement already satisfied: dataclasses-json in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (0.6.4)
    Requirement already satisfied: deprecated>=1.2.9.3 in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (1.2.14)
    Requirement already satisfied: dirtyjson<2.0.0,>=1.0.8 in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (1.0.8)
    Requirement already satisfied: httpx in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (0.26.0)
    Requirement already satisfied: llamaindex-py-client<0.2.0,>=0.1.13 in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (0.1.13)
    Requirement already satisfied: nest-asyncio<2.0.0,>=1.5.8 in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (1.6.0)
    Requirement already satisfied: networkx>=3.0 in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (3.2.1)
    Requirement already satisfied: nltk<4.0.0,>=3.8.1 in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (3.8.1)
    Requirement already satisfied: numpy in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (1.24.4)
    Requirement already satisfied: openai>=1.1.0 in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (1.12.0)
    Requirement already satisfied: pandas in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (1.5.3)
    Requirement already satisfied: pillow>=9.0.0 in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (9.4.0)
    Requirement already satisfied: tenacity<9.0.0,>=8.2.0 in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (8.2.3)
    Requirement already satisfied: tiktoken>=0.3.3 in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (0.6.0)
    Requirement already satisfied: typing-inspect>=0.8.0 in /usr/local/lib/python3.10/dist-packages (from llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (0.9.0)
    Requirement already satisfied: sympy in /usr/local/lib/python3.10/dist-packages (from torch<3.0.0,>=2.1.2->llama-index-embeddings-huggingface) (1.12)
    Requirement already satisfied: jinja2 in /usr/local/lib/python3.10/dist-packages (from torch<3.0.0,>=2.1.2->llama-index-embeddings-huggingface) (3.1.3)
    Requirement already satisfied: nvidia-cuda-nvrtc-cu12==12.1.105 in /usr/local/lib/python3.10/dist-packages (from torch<3.0.0,>=2.1.2->llama-index-embeddings-huggingface) (12.1.105)
    Requirement already satisfied: nvidia-cuda-runtime-cu12==12.1.105 in /usr/local/lib/python3.10/dist-packages (from torch<3.0.0,>=2.1.2->llama-index-embeddings-huggingface) (12.1.105)
    Requirement already satisfied: nvidia-cuda-cupti-cu12==12.1.105 in /usr/local/lib/python3.10/dist-packages (from torch<3.0.0,>=2.1.2->llama-index-embeddings-huggingface) (12.1.105)
    Requirement already satisfied: nvidia-cudnn-cu12==8.9.2.26 in /usr/local/lib/python3.10/dist-packages (from torch<3.0.0,>=2.1.2->llama-index-embeddings-huggingface) (8.9.2.26)
    Requirement already satisfied: nvidia-cublas-cu12==12.1.3.1 in /usr/local/lib/python3.10/dist-packages (from torch<3.0.0,>=2.1.2->llama-index-embeddings-huggingface) (12.1.3.1)
    Requirement already satisfied: nvidia-cufft-cu12==11.0.2.54 in /usr/local/lib/python3.10/dist-packages (from torch<3.0.0,>=2.1.2->llama-index-embeddings-huggingface) (11.0.2.54)
    Requirement already satisfied: nvidia-curand-cu12==10.3.2.106 in /usr/local/lib/python3.10/dist-packages (from torch<3.0.0,>=2.1.2->llama-index-embeddings-huggingface) (10.3.2.106)
    Requirement already satisfied: nvidia-cusolver-cu12==11.4.5.107 in /usr/local/lib/python3.10/dist-packages (from torch<3.0.0,>=2.1.2->llama-index-embeddings-huggingface) (11.4.5.107)
    Requirement already satisfied: nvidia-cusparse-cu12==12.1.0.106 in /usr/local/lib/python3.10/dist-packages (from torch<3.0.0,>=2.1.2->llama-index-embeddings-huggingface) (12.1.0.106)
    Requirement already satisfied: nvidia-nccl-cu12==2.19.3 in /usr/local/lib/python3.10/dist-packages (from torch<3.0.0,>=2.1.2->llama-index-embeddings-huggingface) (2.19.3)
    Requirement already satisfied: nvidia-nvtx-cu12==12.1.105 in /usr/local/lib/python3.10/dist-packages (from torch<3.0.0,>=2.1.2->llama-index-embeddings-huggingface) (12.1.105)
    Requirement already satisfied: triton==2.2.0 in /usr/local/lib/python3.10/dist-packages (from torch<3.0.0,>=2.1.2->llama-index-embeddings-huggingface) (2.2.0)
    Requirement already satisfied: nvidia-nvjitlink-cu12 in /usr/local/lib/python3.10/dist-packages (from nvidia-cusolver-cu12==11.4.5.107->torch<3.0.0,>=2.1.2->llama-index-embeddings-huggingface) (12.3.101)
    Requirement already satisfied: regex!=2019.12.17 in /usr/local/lib/python3.10/dist-packages (from transformers<5.0.0,>=4.37.0->llama-index-embeddings-huggingface) (2023.12.25)
    Requirement already satisfied: tokenizers<0.19,>=0.14 in /usr/local/lib/python3.10/dist-packages (from transformers<5.0.0,>=4.37.0->llama-index-embeddings-huggingface) (0.15.2)
    Requirement already satisfied: safetensors>=0.4.1 in /usr/local/lib/python3.10/dist-packages (from transformers<5.0.0,>=4.37.0->llama-index-embeddings-huggingface) (0.4.2)
    Requirement already satisfied: aiosignal>=1.1.2 in /usr/local/lib/python3.10/dist-packages (from aiohttp->huggingface-hub[inference]>=0.19.0->llama-index-embeddings-huggingface) (1.3.1)
    Requirement already satisfied: attrs>=17.3.0 in /usr/local/lib/python3.10/dist-packages (from aiohttp->huggingface-hub[inference]>=0.19.0->llama-index-embeddings-huggingface) (23.2.0)
    Requirement already satisfied: frozenlist>=1.1.1 in /usr/local/lib/python3.10/dist-packages (from aiohttp->huggingface-hub[inference]>=0.19.0->llama-index-embeddings-huggingface) (1.4.1)
    Requirement already satisfied: multidict<7.0,>=4.5 in /usr/local/lib/python3.10/dist-packages (from aiohttp->huggingface-hub[inference]>=0.19.0->llama-index-embeddings-huggingface) (6.0.5)
    Requirement already satisfied: yarl<2.0,>=1.0 in /usr/local/lib/python3.10/dist-packages (from aiohttp->huggingface-hub[inference]>=0.19.0->llama-index-embeddings-huggingface) (1.9.4)
    Requirement already satisfied: async-timeout<5.0,>=4.0 in /usr/local/lib/python3.10/dist-packages (from aiohttp->huggingface-hub[inference]>=0.19.0->llama-index-embeddings-huggingface) (4.0.3)
    Requirement already satisfied: wrapt<2,>=1.10 in /usr/local/lib/python3.10/dist-packages (from deprecated>=1.2.9.3->llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (1.14.1)
    Requirement already satisfied: anyio in /usr/local/lib/python3.10/dist-packages (from httpx->llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (3.7.1)
    Requirement already satisfied: certifi in /usr/local/lib/python3.10/dist-packages (from httpx->llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (2024.2.2)
    Requirement already satisfied: httpcore==1.* in /usr/local/lib/python3.10/dist-packages (from httpx->llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (1.0.3)
    Requirement already satisfied: idna in /usr/local/lib/python3.10/dist-packages (from httpx->llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (3.6)
    Requirement already satisfied: sniffio in /usr/local/lib/python3.10/dist-packages (from httpx->llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (1.3.0)
    Requirement already satisfied: h11<0.15,>=0.13 in /usr/local/lib/python3.10/dist-packages (from httpcore==1.*->httpx->llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (0.14.0)
    Requirement already satisfied: click in /usr/local/lib/python3.10/dist-packages (from nltk<4.0.0,>=3.8.1->llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (8.1.7)
    Requirement already satisfied: joblib in /usr/local/lib/python3.10/dist-packages (from nltk<4.0.0,>=3.8.1->llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (1.3.2)
    Requirement already satisfied: distro<2,>=1.7.0 in /usr/lib/python3/dist-packages (from openai>=1.1.0->llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (1.7.0)
    Requirement already satisfied: annotated-types>=0.4.0 in /usr/local/lib/python3.10/dist-packages (from pydantic<3.0,>1.1->huggingface-hub[inference]>=0.19.0->llama-index-embeddings-huggingface) (0.6.0)
    Requirement already satisfied: pydantic-core==2.16.2 in /usr/local/lib/python3.10/dist-packages (from pydantic<3.0,>1.1->huggingface-hub[inference]>=0.19.0->llama-index-embeddings-huggingface) (2.16.2)
    Requirement already satisfied: charset-normalizer<4,>=2 in /usr/local/lib/python3.10/dist-packages (from requests->huggingface-hub[inference]>=0.19.0->llama-index-embeddings-huggingface) (3.3.2)
    Requirement already satisfied: urllib3<3,>=1.21.1 in /usr/local/lib/python3.10/dist-packages (from requests->huggingface-hub[inference]>=0.19.0->llama-index-embeddings-huggingface) (2.0.7)
    Requirement already satisfied: greenlet!=0.4.17 in /usr/local/lib/python3.10/dist-packages (from SQLAlchemy[asyncio]>=1.4.49->llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (3.0.3)
    Requirement already satisfied: mypy-extensions>=0.3.0 in /usr/local/lib/python3.10/dist-packages (from typing-inspect>=0.8.0->llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (1.0.0)
    Requirement already satisfied: marshmallow<4.0.0,>=3.18.0 in /usr/local/lib/python3.10/dist-packages (from dataclasses-json->llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (3.20.2)
    Requirement already satisfied: MarkupSafe>=2.0 in /usr/local/lib/python3.10/dist-packages (from jinja2->torch<3.0.0,>=2.1.2->llama-index-embeddings-huggingface) (2.1.5)
    Requirement already satisfied: python-dateutil>=2.8.1 in /usr/local/lib/python3.10/dist-packages (from pandas->llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (2.8.2)
    Requirement already satisfied: pytz>=2020.1 in /usr/local/lib/python3.10/dist-packages (from pandas->llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (2023.4)
    Requirement already satisfied: mpmath>=0.19 in /usr/local/lib/python3.10/dist-packages (from sympy->torch<3.0.0,>=2.1.2->llama-index-embeddings-huggingface) (1.3.0)
    Requirement already satisfied: exceptiongroup in /usr/local/lib/python3.10/dist-packages (from anyio->httpx->llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (1.2.0)
    Requirement already satisfied: six>=1.5 in /usr/local/lib/python3.10/dist-packages (from python-dateutil>=2.8.1->pandas->llama-index-core<0.11.0,>=0.10.1->llama-index-embeddings-huggingface) (1.16.0)



```python
# Este si sirvio
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.core import Settings

Settings.embed_model = HuggingFaceEmbedding(
    model_name="BAAI/bge-small-en-v1.5"
)
```

    /usr/local/lib/python3.10/dist-packages/huggingface_hub/utils/_token.py:88: UserWarning: 
    The secret `HF_TOKEN` does not exist in your Colab secrets.
    To authenticate with the Hugging Face Hub, create a token in your settings tab (https://huggingface.co/settings/tokens), set it as secret in your Google Colab and restart your session.
    You will be able to reuse this secret in all of your notebooks.
    Please note that authentication is recommended but still optional to access public models or datasets.
      warnings.warn(



    model.safetensors:   0%|          | 0.00/133M [00:00<?, ?B/s]



    tokenizer_config.json:   0%|          | 0.00/366 [00:00<?, ?B/s]



    vocab.txt:   0%|          | 0.00/232k [00:00<?, ?B/s]



    tokenizer.json:   0%|          | 0.00/711k [00:00<?, ?B/s]



    special_tokens_map.json:   0%|          | 0.00/125 [00:00<?, ?B/s]



```python
from llama_index.core.query_pipeline import QueryPipeline
```

## Setup

### Setup Data

We use the chinook database as sample data. [Source](https://www.sqlitetutorial.net/sqlite-sample-database/).


```python
# %pip install llama-index-llms-openai
```


```python
!curl "https://www.sqlitetutorial.net/wp-content/uploads/2018/03/chinook.zip" -O ./chinook.zip
!unzip -o ./chinook.zip
```

      % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current
                                     Dload  Upload   Total   Spent    Left  Speed
    100  298k  100  298k    0     0  1937k      0 --:--:-- --:--:-- --:--:-- 1950k
    curl: (6) Could not resolve host: .
    Archive:  ./chinook.zip
      inflating: chinook.db              



```python
from llama_index.core import SQLDatabase
from sqlalchemy import (
    create_engine,
    MetaData,
    Table,
    Column,
    String,
    Integer,
    select,
    column,
)

engine = create_engine("sqlite:///chinook.db")
sql_database = SQLDatabase(engine)
```

### Setup Calback Manager

We setup a global callback manager (helps in case you want to plug in downstream observability integrations).


```python
# define global callback setting
from llama_index.core.settings import Settings
from llama_index.core.callbacks import CallbackManager

callback_manager = CallbackManager()
Settings.callback_manager = callback_manager
```

## Setup Text-to-SQL Query Engine / Tool

Now we setup a simple text-to-SQL tool: given a query, translate text to SQL, execute against database, and get back a result.


```python
from llama_index.core.query_engine import NLSQLTableQueryEngine
from llama_index.core.tools import QueryEngineTool

sql_query_engine = NLSQLTableQueryEngine(
    llm=llm,
    # embed_model='local',
    sql_database=sql_database,
    tables=["albums", "tracks", "artists"],
    verbose=True,
)
sql_tool = QueryEngineTool.from_defaults(
    query_engine=sql_query_engine,
    name="sql_tool",
    description=(
        "Useful for translating a natural language query into a SQL query"
    ),
)
```

## Setup ReAct Agent Pipeline

We now setup a ReAct pipeline for a single step using our Query Pipeline syntax. This is a multi-part process that does the following:
1. Takes in agent inputs
2. Calls ReAct prompt using LLM to generate next action/tool (or returns a response).
3. If tool/action is selected, call tool pipeline to execute tool + collect response.
4. If response is generated, get response.

Throughout this we'll use a variety of agent-specific query components. Unlike normal query pipelines, these are specifically designed for query pipelines that are used in a `QueryPipelineAgentWorker`:
- An `AgentInputComponent` that allows you to convert the agent inputs (Task, state dictionary) into a set of inputs for the query pipeline.
- An `AgentFnComponent`: a general processor that allows you to take in the current Task, state, as well as any arbitrary inputs, and returns an output. In this cookbook we define a function component to format the ReAct prompt. However, you can put this anywhere.
- [Not used in this notebook] An `CustomAgentComponent`: similar to `AgentFnComponent`, you can implement `_run_component` to define your own logic, with access to Task and state. It is more verbose but more flexible than `AgentFnComponent` (e.g. you can define init variables, and callbacks are in the base class).

Note that any function passed into `AgentFnComponent` and `AgentInputComponent` MUST include `task` and `state` as input variables, as these are inputs passed from the agent.

Note that the output of an agentic query pipeline MUST be `Tuple[AgentChatResponse, bool]`. You'll see this below.


```python
from llama_index.core.query_pipeline import QueryPipeline as QP

qp = QP(verbose=True)
```

### Define Agent Input Component

Here we define the agent input component, called at the beginning of every agent step. Besides passing along the input, we also do initialization/state modification.


```python
from llama_index.core.agent.react.types import (
    ActionReasoningStep,
    ObservationReasoningStep,
    ResponseReasoningStep,
)
from llama_index.core.agent import Task, AgentChatResponse
from llama_index.core.query_pipeline import (
    AgentInputComponent,
    AgentFnComponent,
    CustomAgentComponent,
    QueryComponent,
    ToolRunnerComponent,
)
from llama_index.core.llms import MessageRole
from typing import Dict, Any, Optional, Tuple, List, cast


## Agent Input Component
## This is the component that produces agent inputs to the rest of the components
## Can also put initialization logic here.
def agent_input_fn(task: Task, state: Dict[str, Any]) -> Dict[str, Any]:
    """Agent input function.

    Returns:
        A Dictionary of output keys and values. If you are specifying
        src_key when defining links between this component and other
        components, make sure the src_key matches the specified output_key.

    """
    # initialize current_reasoning
    if "current_reasoning" not in state:
        state["current_reasoning"] = []
    reasoning_step = ObservationReasoningStep(observation=task.input)
    state["current_reasoning"].append(reasoning_step)
    return {"input": task.input}


agent_input_component = AgentInputComponent(fn=agent_input_fn)
```

### Define Agent Prompt

Here we define the agent component that generates a ReAct prompt, and after the output is generated from the LLM, parses into a structured object.


```python
from llama_index.core.agent import ReActChatFormatter
from llama_index.core.query_pipeline import InputComponent, Link
from llama_index.core.llms import ChatMessage
from llama_index.core.tools import BaseTool


## define prompt function
def react_prompt_fn(
    task: Task, state: Dict[str, Any], input: str, tools: List[BaseTool]
) -> List[ChatMessage]:
    # Add input to reasoning
    chat_formatter = ReActChatFormatter()
    return chat_formatter.format(
        tools,
        chat_history=task.memory.get() + state["memory"].get_all(),
        current_reasoning=state["current_reasoning"],
    )


react_prompt_component = AgentFnComponent(
    fn=react_prompt_fn, partial_dict={"tools": [sql_tool]}
)
```


```python
# from llama_index.core.llms.generic_utils import messages_to_prompt
from llama_index.llms.llama_cpp.llama_utils import messages_to_prompt

chat_formatter = ReActChatFormatter()
msgs = chat_formatter.format(
    [sql_tool],
    chat_history=[],
    current_reasoning=[]
)
print(messages_to_prompt(msgs))
```

    


### Define Agent Output Parser + Tool Pipeline

Once the LLM gives an output, we have a decision tree:
1. If an answer is given, then we're done. Process the output
2. If an action is given, we need to execute the specified tool with the specified args, and then process the output.

Tool calling can be done via the `ToolRunnerComponent` module. This is a simple wrapper module that takes in a list of tools, and can be "executed" with the specified tool name (every tool has a name) and tool action.

We implement this overall module `OutputAgentComponent` that subclasses `CustomAgentComponent`.

Note: we also implement `sub_query_components` to pass through higher-level callback managers to the tool runner submodule.


```python
from typing import Set, Optional
from llama_index.core.agent.react.output_parser import ReActOutputParser
from llama_index.core.llms import ChatResponse
from llama_index.core.agent.types import Task


def parse_react_output_fn(
    task: Task, state: Dict[str, Any], chat_response: ChatResponse
):
    """Parse ReAct output into a reasoning step."""
    output_parser = ReActOutputParser()
    reasoning_step = output_parser.parse(chat_response.message.content)
    return {"done": reasoning_step.is_done, "reasoning_step": reasoning_step}


parse_react_output = AgentFnComponent(fn=parse_react_output_fn)


def run_tool_fn(
    task: Task, state: Dict[str, Any], reasoning_step: ActionReasoningStep
):
    """Run tool and process tool output."""
    tool_runner_component = ToolRunnerComponent(
        [sql_tool], callback_manager=task.callback_manager
    )
    tool_output = tool_runner_component.run_component(
        tool_name=reasoning_step.action,
        tool_input=reasoning_step.action_input,
    )
    observation_step = ObservationReasoningStep(observation=str(tool_output))
    state["current_reasoning"].append(observation_step)
    # TODO: get output

    return {"response_str": observation_step.get_content(), "is_done": False}


run_tool = AgentFnComponent(fn=run_tool_fn)


def process_response_fn(
    task: Task, state: Dict[str, Any], response_step: ResponseReasoningStep
):
    """Process response."""
    state["current_reasoning"].append(response_step)
    response_str = response_step.response
    # Now that we're done with this step, put into memory
    state["memory"].put(ChatMessage(content=task.input, role=MessageRole.USER))
    state["memory"].put(
        ChatMessage(content=response_str, role=MessageRole.ASSISTANT)
    )

    return {"response_str": response_str, "is_done": True}


process_response = AgentFnComponent(fn=process_response_fn)


def process_agent_response_fn(
    task: Task, state: Dict[str, Any], response_dict: dict
):
    """Process agent response."""
    return (
        AgentChatResponse(response_dict["response_str"]),
        response_dict["is_done"],
    )


process_agent_response = AgentFnComponent(fn=process_agent_response_fn)
```

### Stitch together Agent Query Pipeline

We can now stitch together the top-level agent pipeline: agent_input -> react_prompt -> llm -> react_output.

The last component is the if-else component that calls sub-components.


```python
from llama_index.core.query_pipeline import QueryPipeline as QP
# from llama_index.llms.openai import OpenAI

qp.add_modules(
    {
        "agent_input": agent_input_component,
        "react_prompt": react_prompt_component,
        # "llm": OpenAI(model="gpt-4-1106-preview"),
        "llm": llm,
        "react_output_parser": parse_react_output,
        "run_tool": run_tool,
        "process_response": process_response,
        "process_agent_response": process_agent_response,
    }
)
```


```python
# link input to react prompt to parsed out response (either tool action/input or observation)
qp.add_chain(["agent_input", "react_prompt", "llm", "react_output_parser"])

# add conditional link from react output to tool call (if not done)
qp.add_link(
    "react_output_parser",
    "run_tool",
    condition_fn=lambda x: not x["done"],
    input_fn=lambda x: x["reasoning_step"],
)
# add conditional link from react output to final response processing (if done)
qp.add_link(
    "react_output_parser",
    "process_response",
    condition_fn=lambda x: x["done"],
    input_fn=lambda x: x["reasoning_step"],
)

# whether response processing or tool output processing, add link to final agent response
qp.add_link("process_response", "process_agent_response")
qp.add_link("run_tool", "process_agent_response")
```

### Setup Agent Worker around Text-to-SQL Query Pipeline

This is our way to setup an agent around a text-to-SQL Query Pipeline


```python
from llama_index.core.agent import QueryPipelineAgentWorker, AgentRunner
from llama_index.core.callbacks import CallbackManager

agent_worker = QueryPipelineAgentWorker(qp)
agent = AgentRunner(
    agent_worker, callback_manager=CallbackManager([]), verbose=True
)
```

### Test is stringable


```python
input_ex = """
system:
You are designed to help with a variety of tasks, from answering questions     to providing summaries to other types of analyses.

## Tools
You have access to a wide variety of tools. You are responsible for using
the tools in any sequence you deem appropriate to complete the task at hand.
This may require breaking the task into subtasks and using different tools
to complete each subtask.

You have access to the following tools:
> Tool Name: sql_tool
Tool Description: Useful for translating a natural language query into a SQL query
Tool Args: {"type": "object", "properties": {"input": {"title": "Input", "type": "string"}}, "required": ["input"]}


## Output Format
To answer the question, please use the following format.

```
Thought: I need to use a tool to help me answer the question.
Action: tool name (one of sql_tool) if using a tool.
Action Input: the input to the tool, in a JSON format representing the kwargs (e.g. {"input": "hello world", "num_beams": 5})
```

Please ALWAYS start with a Thought.

Please use a valid JSON format for the Action Input. Do NOT do this {'input': 'hello world', 'num_beams': 5}.

If this format is used, the user will respond in the following format:

```
Observation: tool response
```

You should keep repeating the above format until you have enough information
to answer the question without using any more tools. At that point, you MUST respond
in the one of the following two formats:

```
Thought: I can answer without using any more tools.
Answer: [your answer here]
```

```
Thought: I cannot answer the question with the provided tools.
Answer: Sorry, I cannot answer your query.
```

## Current Conversation
Below is the current conversation consisting of interleaving human and assistant messages.


"""
```


```python
"""Pipeline schema."""
from typing import (
    Any,
    Callable,
    Dict,
    Generator,
    List,
    Optional,
    Set,
    Union,
    cast,
    get_args,
)

from llama_index.core.base.llms.types import (
    ChatResponse,
    CompletionResponse,
)
from llama_index.core.base.response.schema import Response
from llama_index.core.bridge.pydantic import BaseModel, Field
from llama_index.core.callbacks.base import CallbackManager
from llama_index.core.schema import NodeWithScore, QueryBundle, TextNode

## Define common types used throughout these components
StringableInput = Union[
    CompletionResponse,
    ChatResponse,
    str,
    QueryBundle,
    Response,
    Generator,
    NodeWithScore,
    TextNode,
]

type(task.task_id)
task.input
isinstance(input_ex, get_args(StringableInput))
#is stringable
```




    True



### Run the Agent

Let's try the agent on some sample queries.


```python
agent.chat("What are some tracks from the artist AC/DC? Limit it to 3")
```

    > Running step 1a12913d-3152-4034-b894-ca0cc09ba08e. Step input: What are some tracks from the artist AC/DC? Limit it to 3
    [1;3;38;2;155;135;227m> Running module agent_input with input: 
    state: {'sources': [], 'memory': ChatMemoryBuffer(token_limit=3000, tokenizer_fn=functools.partial(<bound method Encoding.encode of <Encoding 'cl100k_base'>>, allowed_special='all'), chat_store=SimpleChatSto...
    task: task_id='c82cb19d-7e8f-459c-b851-26b6c76aca73' input='What are some tracks from the artist AC/DC? Limit it to 3' memory=ChatMemoryBuffer(token_limit=3000, tokenizer_fn=functools.partial(<bound method ...
    
    [0m[1;3;38;2;155;135;227m> Running module react_prompt with input: 
    input: What are some tracks from the artist AC/DC? Limit it to 3
    
    [0m[1;3;38;2;155;135;227m> Running module llm with input: 
    prompt: [ChatMessage(role=<MessageRole.SYSTEM: 'system'>, content='\nYou are designed to help with a variety of tasks, from answering questions     to providing summaries to other types of analyses.\n\n## Too...
    
    [0m


    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    <ipython-input-23-4966f624de31> in <cell line: 1>()
    ----> 1 agent.chat("What are some tracks from the artist AC/DC? Limit it to 3")
    

    /usr/local/lib/python3.10/dist-packages/llama_index/core/callbacks/utils.py in wrapper(self, *args, **kwargs)
         39             callback_manager = cast(CallbackManager, callback_manager)
         40             with callback_manager.as_trace(trace_id):
    ---> 41                 return func(self, *args, **kwargs)
         42 
         43         @functools.wraps(func)  # preserve signature, name, etc. of func


    /usr/local/lib/python3.10/dist-packages/llama_index/core/agent/runner/base.py in chat(self, message, chat_history, tool_choice)
        573             payload={EventPayload.MESSAGES: [message]},
        574         ) as e:
    --> 575             chat_response = self._chat(
        576                 message, chat_history, tool_choice, mode=ChatResponseMode.WAIT
        577             )


    /usr/local/lib/python3.10/dist-packages/llama_index/core/agent/runner/base.py in _chat(self, message, chat_history, tool_choice, mode)
        518         while True:
        519             # pass step queue in as argument, assume step executor is stateless
    --> 520             cur_step_output = self._run_step(
        521                 task.task_id, mode=mode, tool_choice=tool_choice
        522             )


    /usr/local/lib/python3.10/dist-packages/llama_index/core/agent/runner/base.py in _run_step(self, task_id, step, input, mode, **kwargs)
        370 
        371         if mode == ChatResponseMode.WAIT:
    --> 372             cur_step_output = self.agent_worker.run_step(step, task, **kwargs)
        373         elif mode == ChatResponseMode.STREAM:
        374             cur_step_output = self.agent_worker.stream_step(step, task, **kwargs)


    /usr/local/lib/python3.10/dist-packages/llama_index/core/callbacks/utils.py in wrapper(self, *args, **kwargs)
         39             callback_manager = cast(CallbackManager, callback_manager)
         40             with callback_manager.as_trace(trace_id):
    ---> 41                 return func(self, *args, **kwargs)
         42 
         43         @functools.wraps(func)  # preserve signature, name, etc. of func


    /usr/local/lib/python3.10/dist-packages/llama_index/core/agent/custom/pipeline_worker.py in run_step(self, step, task, **kwargs)
        152             agent_fn_component.partial(task=task, state=step.step_state)
        153 
    --> 154         agent_response, is_done = self.pipeline.run(state=step.step_state, task=task)
        155         response = self._get_task_step_response(agent_response, step, is_done)
        156         # sync step state with task state


    /usr/local/lib/python3.10/dist-packages/llama_index/core/query_pipeline/query.py in run(self, return_values_direct, callback_manager, *args, **kwargs)
        317                 CBEventType.QUERY, payload={EventPayload.QUERY_STR: query_payload}
        318             ) as query_event:
    --> 319                 return self._run(
        320                     *args, return_values_direct=return_values_direct, **kwargs
        321                 )


    /usr/local/lib/python3.10/dist-packages/llama_index/core/query_pipeline/query.py in _run(self, return_values_direct, *args, **kwargs)
        440         root_key, kwargs = self._get_root_key_and_kwargs(*args, **kwargs)
        441         # call run_multi with one root key
    --> 442         result_outputs = self._run_multi({root_key: kwargs})
        443         return self._get_single_result_output(result_outputs, return_values_direct)
        444 


    /usr/local/lib/python3.10/dist-packages/llama_index/core/query_pipeline/query.py in _run_multi(self, module_input_dict)
        542             if self.verbose:
        543                 print_debug_input(module_key, module_input)
    --> 544             output_dict = module.run_component(**module_input)
        545 
        546             # get new nodes and is_leaf


    /usr/local/lib/python3.10/dist-packages/llama_index/core/base/query_pipeline/query.py in run_component(self, **kwargs)
        196         """Run component."""
        197         kwargs.update(self.partial_dict)
    --> 198         kwargs = self.validate_component_inputs(kwargs)
        199         component_outputs = self._run_component(**kwargs)
        200         return self.validate_component_outputs(component_outputs)


    /usr/local/lib/python3.10/dist-packages/llama_index/core/base/query_pipeline/query.py in validate_component_inputs(self, input)
        185         # make sure set of input keys == self.input_keys
        186         self.input_keys.validate(set(input.keys()))
    --> 187         return self._validate_component_inputs(input)
        188 
        189     def validate_component_outputs(self, output: Dict[str, Any]) -> Dict[str, Any]:


    /usr/local/lib/python3.10/dist-packages/llama_index/core/llms/llm.py in _validate_component_inputs(self, input)
        386             input["prompt"] = validate_and_convert_stringable(input["prompt"])
        387         else:
    --> 388             input["prompt"] = validate_and_convert_stringable(input["prompt"])
        389             input["prompt"] = self.llm.completion_to_prompt(input["prompt"])
        390 


    /usr/local/lib/python3.10/dist-packages/llama_index/core/base/query_pipeline/query.py in validate_and_convert_stringable(input)
         55         new_input_list = []
         56         for elem in input:
    ---> 57             new_input_list.append(validate_and_convert_stringable(elem))
         58         return str(new_input_list)
         59     elif isinstance(input, ChatResponse):


    /usr/local/lib/python3.10/dist-packages/llama_index/core/base/query_pipeline/query.py in validate_and_convert_stringable(input)
         62         return str(input)
         63     else:
    ---> 64         raise ValueError(f"Input {input} is not stringable.")
         65 
         66 


    ValueError: Input system: 
    You are designed to help with a variety of tasks, from answering questions     to providing summaries to other types of analyses.
    
    ## Tools
    You have access to a wide variety of tools. You are responsible for using
    the tools in any sequence you deem appropriate to complete the task at hand.
    This may require breaking the task into subtasks and using different tools
    to complete each subtask.
    
    You have access to the following tools:
    > Tool Name: sql_tool
    Tool Description: Useful for translating a natural language query into a SQL query
    Tool Args: {"type": "object", "properties": {"input": {"title": "Input", "type": "string"}}, "required": ["input"]}
    
    
    ## Output Format
    To answer the question, please use the following format.
    
    ```
    Thought: I need to use a tool to help me answer the question.
    Action: tool name (one of sql_tool) if using a tool.
    Action Input: the input to the tool, in a JSON format representing the kwargs (e.g. {"input": "hello world", "num_beams": 5})
    ```
    
    Please ALWAYS start with a Thought.
    
    Please use a valid JSON format for the Action Input. Do NOT do this {'input': 'hello world', 'num_beams': 5}.
    
    If this format is used, the user will respond in the following format:
    
    ```
    Observation: tool response
    ```
    
    You should keep repeating the above format until you have enough information
    to answer the question without using any more tools. At that point, you MUST respond
    in the one of the following two formats:
    
    ```
    Thought: I can answer without using any more tools.
    Answer: [your answer here]
    ```
    
    ```
    Thought: I cannot answer the question with the provided tools.
    Answer: Sorry, I cannot answer your query.
    ```
    
    ## Current Conversation
    Below is the current conversation consisting of interleaving human and assistant messages.
    
     is not stringable.



```python
# start task
task = agent.create_task("What are some tracks from the artist AC/DC? Limit it to 3")
```


```python
step_output = agent.run_step(task.task_id)
```

    > Running step cd3d6e36-b04e-4799-8fda-9801e4e820ac. Step input: What are some tracks from the artist AC/DC? Limit it to 3
    [1;3;38;2;155;135;227m> Running module agent_input with input: 
    state: {'sources': [], 'memory': ChatMemoryBuffer(token_limit=3000, tokenizer_fn=functools.partial(<bound method Encoding.encode of <Encoding 'cl100k_base'>>, allowed_special='all'), chat_store=SimpleChatSto...
    task: task_id='ef8fbec0-d927-4305-ab26-3ba1878065a5' input='What are some tracks from the artist AC/DC? Limit it to 3' memory=ChatMemoryBuffer(token_limit=3000, tokenizer_fn=functools.partial(<bound method ...
    
    [0m[1;3;38;2;155;135;227m> Running module react_prompt with input: 
    input: What are some tracks from the artist AC/DC? Limit it to 3
    
    [0m[1;3;38;2;155;135;227m> Running module llm with input: 
    prompt: [ChatMessage(role=<MessageRole.SYSTEM: 'system'>, content='\nYou are designed to help with a variety of tasks, from answering questions     to providing summaries to other types of analyses.\n\n## Too...
    
    [0m


    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    <ipython-input-21-540316236b4e> in <cell line: 1>()
    ----> 1 step_output = agent.run_step(task.task_id)
    

    /usr/local/lib/python3.10/dist-packages/llama_index/core/agent/runner/base.py in run_step(self, task_id, input, step, **kwargs)
        430         """Run step."""
        431         step = validate_step_from_args(task_id, input, step, **kwargs)
    --> 432         return self._run_step(
        433             task_id, step, input=input, mode=ChatResponseMode.WAIT, **kwargs
        434         )


    /usr/local/lib/python3.10/dist-packages/llama_index/core/agent/runner/base.py in _run_step(self, task_id, step, input, mode, **kwargs)
        370 
        371         if mode == ChatResponseMode.WAIT:
    --> 372             cur_step_output = self.agent_worker.run_step(step, task, **kwargs)
        373         elif mode == ChatResponseMode.STREAM:
        374             cur_step_output = self.agent_worker.stream_step(step, task, **kwargs)


    /usr/local/lib/python3.10/dist-packages/llama_index/core/callbacks/utils.py in wrapper(self, *args, **kwargs)
         39             callback_manager = cast(CallbackManager, callback_manager)
         40             with callback_manager.as_trace(trace_id):
    ---> 41                 return func(self, *args, **kwargs)
         42 
         43         @functools.wraps(func)  # preserve signature, name, etc. of func


    /usr/local/lib/python3.10/dist-packages/llama_index/core/agent/custom/pipeline_worker.py in run_step(self, step, task, **kwargs)
        152             agent_fn_component.partial(task=task, state=step.step_state)
        153 
    --> 154         agent_response, is_done = self.pipeline.run(state=step.step_state, task=task)
        155         response = self._get_task_step_response(agent_response, step, is_done)
        156         # sync step state with task state


    /usr/local/lib/python3.10/dist-packages/llama_index/core/query_pipeline/query.py in run(self, return_values_direct, callback_manager, *args, **kwargs)
        317                 CBEventType.QUERY, payload={EventPayload.QUERY_STR: query_payload}
        318             ) as query_event:
    --> 319                 return self._run(
        320                     *args, return_values_direct=return_values_direct, **kwargs
        321                 )


    /usr/local/lib/python3.10/dist-packages/llama_index/core/query_pipeline/query.py in _run(self, return_values_direct, *args, **kwargs)
        440         root_key, kwargs = self._get_root_key_and_kwargs(*args, **kwargs)
        441         # call run_multi with one root key
    --> 442         result_outputs = self._run_multi({root_key: kwargs})
        443         return self._get_single_result_output(result_outputs, return_values_direct)
        444 


    /usr/local/lib/python3.10/dist-packages/llama_index/core/query_pipeline/query.py in _run_multi(self, module_input_dict)
        542             if self.verbose:
        543                 print_debug_input(module_key, module_input)
    --> 544             output_dict = module.run_component(**module_input)
        545 
        546             # get new nodes and is_leaf


    /usr/local/lib/python3.10/dist-packages/llama_index/core/base/query_pipeline/query.py in run_component(self, **kwargs)
        196         """Run component."""
        197         kwargs.update(self.partial_dict)
    --> 198         kwargs = self.validate_component_inputs(kwargs)
        199         component_outputs = self._run_component(**kwargs)
        200         return self.validate_component_outputs(component_outputs)


    /usr/local/lib/python3.10/dist-packages/llama_index/core/base/query_pipeline/query.py in validate_component_inputs(self, input)
        185         # make sure set of input keys == self.input_keys
        186         self.input_keys.validate(set(input.keys()))
    --> 187         return self._validate_component_inputs(input)
        188 
        189     def validate_component_outputs(self, output: Dict[str, Any]) -> Dict[str, Any]:


    /usr/local/lib/python3.10/dist-packages/llama_index/core/llms/llm.py in _validate_component_inputs(self, input)
        386             input["prompt"] = validate_and_convert_stringable(input["prompt"])
        387         else:
    --> 388             input["prompt"] = validate_and_convert_stringable(input["prompt"])
        389             input["prompt"] = self.llm.completion_to_prompt(input["prompt"])
        390 


    /usr/local/lib/python3.10/dist-packages/llama_index/core/base/query_pipeline/query.py in validate_and_convert_stringable(input)
         55         new_input_list = []
         56         for elem in input:
    ---> 57             new_input_list.append(validate_and_convert_stringable(elem))
         58         return str(new_input_list)
         59     elif isinstance(input, ChatResponse):


    /usr/local/lib/python3.10/dist-packages/llama_index/core/base/query_pipeline/query.py in validate_and_convert_stringable(input)
         62         return str(input)
         63     else:
    ---> 64         raise ValueError(f"Input {input} is not stringable.")
         65 
         66 


    ValueError: Input system: 
    You are designed to help with a variety of tasks, from answering questions     to providing summaries to other types of analyses.
    
    ## Tools
    You have access to a wide variety of tools. You are responsible for using
    the tools in any sequence you deem appropriate to complete the task at hand.
    This may require breaking the task into subtasks and using different tools
    to complete each subtask.
    
    You have access to the following tools:
    > Tool Name: sql_tool
    Tool Description: Useful for translating a natural language query into a SQL query
    Tool Args: {"type": "object", "properties": {"input": {"title": "Input", "type": "string"}}, "required": ["input"]}
    
    
    ## Output Format
    To answer the question, please use the following format.
    
    ```
    Thought: I need to use a tool to help me answer the question.
    Action: tool name (one of sql_tool) if using a tool.
    Action Input: the input to the tool, in a JSON format representing the kwargs (e.g. {"input": "hello world", "num_beams": 5})
    ```
    
    Please ALWAYS start with a Thought.
    
    Please use a valid JSON format for the Action Input. Do NOT do this {'input': 'hello world', 'num_beams': 5}.
    
    If this format is used, the user will respond in the following format:
    
    ```
    Observation: tool response
    ```
    
    You should keep repeating the above format until you have enough information
    to answer the question without using any more tools. At that point, you MUST respond
    in the one of the following two formats:
    
    ```
    Thought: I can answer without using any more tools.
    Answer: [your answer here]
    ```
    
    ```
    Thought: I cannot answer the question with the provided tools.
    Answer: Sorry, I cannot answer your query.
    ```
    
    ## Current Conversation
    Below is the current conversation consisting of interleaving human and assistant messages.
    
     is not stringable.



```python
step_output.is_last
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    <ipython-input-36-1536daf05328> in <cell line: 1>()
    ----> 1 step_output.is_last
    

    NameError: name 'step_output' is not defined



```python
step_output = agent.run_step(task.task_id)
```


    ---------------------------------------------------------------------------

    IndexError                                Traceback (most recent call last)

    <ipython-input-34-540316236b4e> in <cell line: 1>()
    ----> 1 step_output = agent.run_step(task.task_id)
    

    /usr/local/lib/python3.10/dist-packages/llama_index/core/agent/runner/base.py in run_step(self, task_id, input, step, **kwargs)
        430         """Run step."""
        431         step = validate_step_from_args(task_id, input, step, **kwargs)
    --> 432         return self._run_step(
        433             task_id, step, input=input, mode=ChatResponseMode.WAIT, **kwargs
        434         )


    /usr/local/lib/python3.10/dist-packages/llama_index/core/agent/runner/base.py in _run_step(self, task_id, step, input, mode, **kwargs)
        359         task = self.state.get_task(task_id)
        360         step_queue = self.state.get_step_queue(task_id)
    --> 361         step = step or step_queue.popleft()
        362         if input is not None:
        363             step.input = input


    IndexError: pop from an empty deque



```python
step_output.is_last
```




    True




```python
response = agent.finalize_response(task.task_id)
```


```python
print(str(response))
```

    The top 3 tracks by AC/DC are "For Those About To Rock (We Salute You)", "Put The Finger On You", and "Let's Get It Up".



```python
# run this e2e
agent.reset()
response = agent.chat(
    "What are some tracks from the artist AC/DC? Limit it to 3"
)
```

    > Running step 9a428c53-a81d-48fd-a8aa-e02e20aeec82. Step input: What are some tracks from the artist AC/DC? Limit it to 3
    [1;3;38;2;155;135;227m> Running module agent_input with input: 
    state: {'sources': [], 'memory': ChatMemoryBuffer(token_limit=3000, tokenizer_fn=functools.partial(<bound method Encoding.encode of <Encoding 'cl100k_base'>>, allowed_special='all'), chat_store=SimpleChatSto...
    task: task_id='78536a3f-785d-400c-9af9-7fec08d28c1c' input='What are some tracks from the artist AC/DC? Limit it to 3' memory=ChatMemoryBuffer(token_limit=3000, tokenizer_fn=functools.partial(<bound method ...
    
    [0m[1;3;38;2;155;135;227m> Running module react_prompt with input: 
    input: What are some tracks from the artist AC/DC? Limit it to 3
    
    [0m[1;3;38;2;155;135;227m> Running module llm with input: 
    prompt: [ChatMessage(role=<MessageRole.SYSTEM: 'system'>, content='\nYou are designed to help with a variety of tasks, from answering questions     to providing summaries to other types of analyses.\n\n## Too...
    
    [0m


    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    <ipython-input-24-181d85fa7f86> in <cell line: 3>()
          1 # run this e2e
          2 agent.reset()
    ----> 3 response = agent.chat(
          4     "What are some tracks from the artist AC/DC? Limit it to 3"
          5 )


    /usr/local/lib/python3.10/dist-packages/llama_index/core/callbacks/utils.py in wrapper(self, *args, **kwargs)
         39             callback_manager = cast(CallbackManager, callback_manager)
         40             with callback_manager.as_trace(trace_id):
    ---> 41                 return func(self, *args, **kwargs)
         42 
         43         @functools.wraps(func)  # preserve signature, name, etc. of func


    /usr/local/lib/python3.10/dist-packages/llama_index/core/agent/runner/base.py in chat(self, message, chat_history, tool_choice)
        573             payload={EventPayload.MESSAGES: [message]},
        574         ) as e:
    --> 575             chat_response = self._chat(
        576                 message, chat_history, tool_choice, mode=ChatResponseMode.WAIT
        577             )


    /usr/local/lib/python3.10/dist-packages/llama_index/core/agent/runner/base.py in _chat(self, message, chat_history, tool_choice, mode)
        518         while True:
        519             # pass step queue in as argument, assume step executor is stateless
    --> 520             cur_step_output = self._run_step(
        521                 task.task_id, mode=mode, tool_choice=tool_choice
        522             )


    /usr/local/lib/python3.10/dist-packages/llama_index/core/agent/runner/base.py in _run_step(self, task_id, step, input, mode, **kwargs)
        370 
        371         if mode == ChatResponseMode.WAIT:
    --> 372             cur_step_output = self.agent_worker.run_step(step, task, **kwargs)
        373         elif mode == ChatResponseMode.STREAM:
        374             cur_step_output = self.agent_worker.stream_step(step, task, **kwargs)


    /usr/local/lib/python3.10/dist-packages/llama_index/core/callbacks/utils.py in wrapper(self, *args, **kwargs)
         39             callback_manager = cast(CallbackManager, callback_manager)
         40             with callback_manager.as_trace(trace_id):
    ---> 41                 return func(self, *args, **kwargs)
         42 
         43         @functools.wraps(func)  # preserve signature, name, etc. of func


    /usr/local/lib/python3.10/dist-packages/llama_index/core/agent/custom/pipeline_worker.py in run_step(self, step, task, **kwargs)
        152             agent_fn_component.partial(task=task, state=step.step_state)
        153 
    --> 154         agent_response, is_done = self.pipeline.run(state=step.step_state, task=task)
        155         response = self._get_task_step_response(agent_response, step, is_done)
        156         # sync step state with task state


    /usr/local/lib/python3.10/dist-packages/llama_index/core/query_pipeline/query.py in run(self, return_values_direct, callback_manager, *args, **kwargs)
        317                 CBEventType.QUERY, payload={EventPayload.QUERY_STR: query_payload}
        318             ) as query_event:
    --> 319                 return self._run(
        320                     *args, return_values_direct=return_values_direct, **kwargs
        321                 )


    /usr/local/lib/python3.10/dist-packages/llama_index/core/query_pipeline/query.py in _run(self, return_values_direct, *args, **kwargs)
        440         root_key, kwargs = self._get_root_key_and_kwargs(*args, **kwargs)
        441         # call run_multi with one root key
    --> 442         result_outputs = self._run_multi({root_key: kwargs})
        443         return self._get_single_result_output(result_outputs, return_values_direct)
        444 


    /usr/local/lib/python3.10/dist-packages/llama_index/core/query_pipeline/query.py in _run_multi(self, module_input_dict)
        542             if self.verbose:
        543                 print_debug_input(module_key, module_input)
    --> 544             output_dict = module.run_component(**module_input)
        545 
        546             # get new nodes and is_leaf


    /usr/local/lib/python3.10/dist-packages/llama_index/core/base/query_pipeline/query.py in run_component(self, **kwargs)
        196         """Run component."""
        197         kwargs.update(self.partial_dict)
    --> 198         kwargs = self.validate_component_inputs(kwargs)
        199         component_outputs = self._run_component(**kwargs)
        200         return self.validate_component_outputs(component_outputs)


    /usr/local/lib/python3.10/dist-packages/llama_index/core/base/query_pipeline/query.py in validate_component_inputs(self, input)
        185         # make sure set of input keys == self.input_keys
        186         self.input_keys.validate(set(input.keys()))
    --> 187         return self._validate_component_inputs(input)
        188 
        189     def validate_component_outputs(self, output: Dict[str, Any]) -> Dict[str, Any]:


    /usr/local/lib/python3.10/dist-packages/llama_index/core/llms/llm.py in _validate_component_inputs(self, input)
        386             input["prompt"] = validate_and_convert_stringable(input["prompt"])
        387         else:
    --> 388             input["prompt"] = validate_and_convert_stringable(input["prompt"])
        389             input["prompt"] = self.llm.completion_to_prompt(input["prompt"])
        390 


    /usr/local/lib/python3.10/dist-packages/llama_index/core/base/query_pipeline/query.py in validate_and_convert_stringable(input)
         55         new_input_list = []
         56         for elem in input:
    ---> 57             new_input_list.append(validate_and_convert_stringable(elem))
         58         return str(new_input_list)
         59     elif isinstance(input, ChatResponse):


    /usr/local/lib/python3.10/dist-packages/llama_index/core/base/query_pipeline/query.py in validate_and_convert_stringable(input)
         62         return str(input)
         63     else:
    ---> 64         raise ValueError(f"Input {input} is not stringable.")
         65 
         66 


    ValueError: Input system: 
    You are designed to help with a variety of tasks, from answering questions     to providing summaries to other types of analyses.
    
    ## Tools
    You have access to a wide variety of tools. You are responsible for using
    the tools in any sequence you deem appropriate to complete the task at hand.
    This may require breaking the task into subtasks and using different tools
    to complete each subtask.
    
    You have access to the following tools:
    > Tool Name: sql_tool
    Tool Description: Useful for translating a natural language query into a SQL query
    Tool Args: {"type": "object", "properties": {"input": {"title": "Input", "type": "string"}}, "required": ["input"]}
    
    
    ## Output Format
    To answer the question, please use the following format.
    
    ```
    Thought: I need to use a tool to help me answer the question.
    Action: tool name (one of sql_tool) if using a tool.
    Action Input: the input to the tool, in a JSON format representing the kwargs (e.g. {"input": "hello world", "num_beams": 5})
    ```
    
    Please ALWAYS start with a Thought.
    
    Please use a valid JSON format for the Action Input. Do NOT do this {'input': 'hello world', 'num_beams': 5}.
    
    If this format is used, the user will respond in the following format:
    
    ```
    Observation: tool response
    ```
    
    You should keep repeating the above format until you have enough information
    to answer the question without using any more tools. At that point, you MUST respond
    in the one of the following two formats:
    
    ```
    Thought: I can answer without using any more tools.
    Answer: [your answer here]
    ```
    
    ```
    Thought: I cannot answer the question with the provided tools.
    Answer: Sorry, I cannot answer your query.
    ```
    
    ## Current Conversation
    Below is the current conversation consisting of interleaving human and assistant messages.
    
     is not stringable.



```python
print(str(response))
```

    The top 3 tracks by AC/DC are "For Those About To Rock (We Salute You)", "Put The Finger On You", and "Let's Get It Up".

