from typing import List

from llama_index.core.query_engine import CustomQueryEngine, BaseQueryEngine
from llama_index.core.response_synthesizers import TreeSummarize

from dataclasses import fields
from pydantic import BaseModel
from dataclasses import fields
from pydantic import BaseModel
import json

from llama_index.core.base.response.schema import RESPONSE_TYPE, Response
from llama_index.core.bridge.pydantic import BaseModel, Field
from llama_index.core.schema import QueryBundle, QueryType

from llama_index.core.types import BaseOutputParser
from llama_index.core import PromptTemplate

from pydantic import Field


class Answer(BaseModel):
    choice: int
    reason: str


class Answers(BaseModel):
    """Represents a list of answers."""

    answers: List[Answer]


def _escape_curly_braces(input_string: str) -> str:
    # Replace '{' with '{{' and '}' with '}}' to escape curly braces
    escaped_string = input_string.replace("{", "{{").replace("}", "}}")
    return escaped_string


def _marshal_output_to_json(output: str) -> str:
    output = output.strip()
    left = output.find("[")
    right = output.find("]")
    output = output[left: right + 1]
    return output


FORMAT_STR = """The output should be formatted as a JSON instance that conforms to 
the JSON schema below. 

Here is the output schema:
{
  "type": "array",
  "items": {
    "type": "object",
    "properties": {
      "choice": {
        "type": "integer"
      },
      "reason": {
        "type": "string"
      }
    },
    "required": [
      "choice",
      "reason"
    ],
    "additionalProperties": false
  }
}
"""


def get_choice_str(choices):
    choices_str = "\n\n".join(
        [f"{idx + 1}. {c}" for idx, c in enumerate(choices)]
    )
    return choices_str


class RouterOutputParser(BaseOutputParser):
    def parse(self, output: str) -> List[Answer]:
        """Parse string."""
        json_output = _marshal_output_to_json(output)
        json_dicts = json.loads(json_output)
        answers = [Answer.from_dict(json_dict) for json_dict in json_dicts]
        return answers

    def format(self, prompt_template: str) -> str:
        return prompt_template + "\n\n" + _escape_curly_braces(FORMAT_STR)


router_prompt0 = PromptTemplate(
    "Some choices are given below. It is provided in a numbered list (1 to"
    " {num_choices}), where each item in the list corresponds to a"
    " summary.\n---------------------\n{context_list}\n---------------------\nUsing"
    " only the choices above and not prior knowledge, return the top choices"
    " (no more than {max_outputs}, but only select what is needed) that are"
    " most relevant to the question: '{query_str}'\n"
)

# choices = [
#     "Useful for questions related to apples",
#     "Useful for questions related to oranges",
# ]

choices = [
    (
        "Useful for answering questions about specific sections of the Llama 2"
        " paper"
    ),
    "Useful for questions that ask for a summary of the whole paper",
]

router_prompt1 = router_prompt0.partial_format(
    num_choices=len(choices),
    max_outputs=len(choices),
)


class RouterQueryEngine(CustomQueryEngine):
    """Use our Pydantic program to perform routing."""

    query_engines: List[BaseQueryEngine]
    choice_descriptions: List[str]
    verbose: bool = False
    router_prompt: PromptTemplate
    llm: None
    summarizer: TreeSummarize = Field(default_factory=TreeSummarize)

    def query(self, str_or_query_bundle: QueryType) -> RESPONSE_TYPE:
        with self.callback_manager.as_trace("query"):
            # if query bundle, just run the query
            if isinstance(str_or_query_bundle, QueryBundle):
                query_str = str_or_query_bundle.query_str
            else:
                query_str = str_or_query_bundle
            raw_response = self.custom_query(query_str)
            return (
                Response(raw_response)
                if isinstance(raw_response, str)
                else raw_response
            )

    def custom_query(self, query_str: str):
        """Define custom query."""

        # program = OpenAIPydanticProgram.from_defaults(
        #     output_cls=Answers,
        #     prompt=router_prompt1,
        #     verbose=self.verbose,
        #     llm=self.llm,
        # )

        from router.custom_pydantic_program import CustomPydanticProgram
        program = CustomPydanticProgram.from_defaults(
            output_cls=Answers,
            prompt=self.router_prompt,
            verbose=self.verbose,
            llm=self.llm
        )

        choices_str = get_choice_str(self.choice_descriptions)
        output = program(context_list=choices_str, query_str=query_str)
        # print choice and reason, and query the underlying engine
        if self.verbose:
            print(f"Selected choice(s):")
            for answer in output.answers:
                print(f"Choice: {answer.choice}, Reason: {answer.reason}")

        responses = []
        for answer in output.answers:
            choice_idx = answer.choice - 1
            query_engine = self.query_engines[choice_idx]
            response = query_engine.query(query_str)
            responses.append(response)

        # if a single choice is picked, we can just return that response
        if len(responses) == 1:
            return responses[0]
        else:
            # if multiple choices are picked, we can pick a summarizer
            response_strs = [str(r) for r in responses]
            result_response = self.summarizer.get_response(
                query_str, response_strs
            )
            return result_response

def test_llm_program():
    from llama_index.program.openai import OpenAIPydanticProgram

    router_prompt1 = router_prompt0.partial_format(
        num_choices=len(choices),
        max_outputs=len(choices),
    )

    # logging.debug(f'router_prompt1: {router_prompt1}')

    from router.custom_pydantic_program import CustomPydanticProgram
    program = CustomPydanticProgram.from_defaults(
        llm=llm,
        output_cls=Answers,
        prompt=router_prompt1,
        verbose=True,
    )

    choices_str = get_choice_str(
        choices=[
            "Useful for questions related to apples",
            "Useful for questions related to oranges",
        ])

    query_str = "What are the health benefits of eating orange peels?"
    output = program(context_list=choices_str, query_str=query_str)
    print(f'output: {output}')


def main():
    print(json.dumps(Answer.schema(), indent=4))
    print(json.dumps(Answers.schema(), indent=4))

    # build engine tools
    from rag.rag_test2 import load_data
    vector_query_engine, summary_query_engine = load_data()

    choices = [
        (
            "Useful for answering questions about specific sections of the Llama 2"
            " paper"
        ),
        "Useful for questions that ask for a summary of the whole paper",
    ]

    router_query_engine = RouterQueryEngine(
        query_engines=[
            vector_query_engine,
            summary_query_engine
        ],
        choice_descriptions=choices,
        verbose=True,
        router_prompt=router_prompt1,
        llm=llm
    )

    logging.info(f'Query engine loaded.')

    response = router_query_engine.query(
        "How does the Llama 2 model compare to GPT-4 in the experimental results?"
    )

    print(str(response))


if __name__ == '__main__':
    import logging
    import sys

    logging.basicConfig(stream=sys.stdout,
                        level=logging.DEBUG,
                        format="[%(levelname)s] %(filename)s[%(levelno)s]{%(funcName)s} %(message)s")

    # logging.getLogger().addHandler(logging.StreamHandler(stream=sys.stdout))

    from llama_index.llms.openai_like import OpenAILike

    llm = OpenAILike(
        # model="Qwen1.5-0.5B-Chat",
        # api_base="http://192.168.150.181:8000/v1",
        model='Mistral-7B-Instruct-v0.2',
        api_base="http://192.168.100.21:8000/v1",
        api_key='EMPTY',
        temperature=0.,
        max_tokens=1000,
    )

    main()
    # test_llm_program()