import logging
from typing import Any, Dict, Generator, List, Optional, Tuple, Type, Union, cast

from llama_index.agent.openai.utils import resolve_tool_choice
from llama_index.core.llms.llm import LLM
from llama_index.core.program.llm_prompt_program import BaseLLMFunctionProgram
from llama_index.core.program.utils import create_list_model
from llama_index.core.prompts.base import BasePromptTemplate, PromptTemplate
from llama_index.core.settings import Settings
from llama_index.core.types import Model
from llama_index.llms.openai import OpenAI
from llama_index.llms.openai.utils import OpenAIToolCall, to_openai_tool
import json
from llama_index.core.output_parsers.utils import _marshal_llm_to_json
from llama_index.core.output_parsers.base import (
    OutputParserException,
    StructuredOutput,
)

_logger = logging.getLogger(__name__)

from llama_index.core.callbacks import CallbackManager

'''
modify for opensource model
based on llama_index.program.openai.base.OpenAIPydanticProgram

'''
from llama_index.program.openai.base import _parse_tool_calls, _default_tool_choice, _get_json_str

# class OpenAIPydanticProgram(BaseLLMFunctionProgram[LLM]):
class CustomPydanticProgram(BaseLLMFunctionProgram[LLM]):
    """
    An OpenAI-based function that returns a pydantic model.

    Note: this interface is not yet stable.
    """

    def __init__(
        self,
        output_cls: Type[Model],
        llm: LLM,
        prompt: BasePromptTemplate,
        tool_choice: Union[str, Dict[str, Any]],
        allow_multiple: bool = False,
        verbose: bool = False,
    ) -> None:
        """Init params."""
        self._output_cls = output_cls
        self._llm = llm
        self._prompt = prompt
        self._verbose = verbose
        self._allow_multiple = allow_multiple
        self._tool_choice = tool_choice

    @classmethod
    def from_defaults(
        cls,
        output_cls: Type[Model],
        prompt_template_str: Optional[str] = None,
        prompt: Optional[PromptTemplate] = None,
        llm: Optional[LLM] = None,
        verbose: bool = False,
        allow_multiple: bool = False,
        tool_choice: Optional[Union[str, Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> "CustomPydanticProgram":
        llm = llm or Settings.llm

        # if not isinstance(llm, OpenAI):
        #     raise ValueError(
        #         "OpenAIPydanticProgram only supports OpenAI LLMs. " f"Got: {type(llm)}"
        #     )

        # if not llm.metadata.is_function_calling_model:
        #     raise ValueError(
        #         f"Model name {llm.metadata.model_name} does not support "
        #         "function calling API. "
        #     )

        if prompt is None and prompt_template_str is None:
            raise ValueError("Must provide either prompt or prompt_template_str.")
        if prompt is not None and prompt_template_str is not None:
            raise ValueError("Must provide either prompt or prompt_template_str.")
        if prompt_template_str is not None:
            prompt = PromptTemplate(prompt_template_str)

        tool_choice = tool_choice or _default_tool_choice(output_cls, allow_multiple)
        logging.debug(f'tool_choice: {tool_choice}')

        # add output_cls schema to prompt
        # from router.structed_output import _escape_curly_braces
        # prompt.template += '\noutput format is a JSON object like below:\n' + _escape_curly_braces(
        #     str(output_cls.schema()))
        PYDANTIC_FORMAT_TMPL = """
                Here's a JSON schema to follow:
                {schema}

                Output a valid JSON object but do not repeat the schema.
                """
        schema_dict = output_cls.schema()
        # for key in self._excluded_schema_keys_from_format:
        #     del schema_dict[key]

        schema_str = json.dumps(schema_dict)
        output_str = PYDANTIC_FORMAT_TMPL.format(schema=schema_str)
        output_str = output_str.replace("{", "{{").replace("}", "}}")
        logging.debug(f'output cls schema: {output_str}')
        prompt.template += "\n\n" + output_str

        return cls(
            output_cls=output_cls,
            llm=llm,
            # prompt=cast(PromptTemplate, prompt),
            prompt=prompt,
            tool_choice=tool_choice,
            allow_multiple=allow_multiple,
            verbose=verbose,
        )

    @property
    def output_cls(self) -> Type[Model]:
        return self._output_cls

    @property
    def prompt(self) -> BasePromptTemplate:
        return self._prompt

    @prompt.setter
    def prompt(self, prompt: BasePromptTemplate) -> None:
        self._prompt = prompt

    def parse_struct_output_from_llm_response(self, output: str) -> Any:
        json_string = _marshal_llm_to_json(output)
        try:
            json_obj = json.loads(json_string)
        except json.JSONDecodeError as e_json:
            try:
                import yaml

                # NOTE: parsing again with pyyaml
                #       pyyaml is less strict, and allows for trailing commas
                #       right now we rely on this since guidance program generates
                #       trailing commas
                json_obj = yaml.safe_load(json_string)
            except yaml.YAMLError as e_yaml:
                raise OutputParserException(
                    f"Got invalid JSON object. Error: {e_json} {e_yaml}. "
                    f"Got JSON string: {json_string}"
                )
            except NameError as exc:
                raise ImportError("Please pip install PyYAML.") from exc

        # if isinstance(json_obj, dict):
        #     json_obj = [json_obj]
        #
        # if not json_obj:
        #     raise ValueError(f"Failed to convert output to JSON: {output!r}")

        # # json_output = self._format_output(json_obj)
        # answers = [self._output_cls.from_dict(json_dict) for json_dict in json_output]
        # answers = self._output_cls.from_orm()
        # return StructuredOutput(raw_output=output, parsed_output=answers)
        return json_obj

    def __call__(
        self,
        llm_kwargs: Optional[Dict[str, Any]] = None,
        *args: Any,
        **kwargs: Any,
    ) -> Union[Model, List[Model]]:
        llm_kwargs = llm_kwargs or {}
        description = self._description_eval(**kwargs)
        logging.debug(f'description: {description}')
        openai_fn_spec = to_openai_tool(self._output_cls, description=description)

        logging.debug(f'prompt: {self._prompt}')
        messages = self._prompt.format_messages(llm=self._llm, **kwargs)
        logging.debug(f'messages: {messages}')
        logging.debug(f'llm_kwargs: {llm_kwargs}')
        chat_response = self._llm.chat(
            messages=messages,
            # tools=[openai_fn_spec],
            # tool_choice=self._tool_choice,
            **llm_kwargs,
        )
        logging.debug(f'llm_response: {chat_response.raw}')

        # parse tools information
        parse_result = self.parse_struct_output_from_llm_response(chat_response.raw['choices'][0].text)
        logging.debug(f'parse_result: {parse_result}')
        validate_result = self._output_cls.model_validate(parse_result)
        logging.debug(f'validate: {validate_result}')

        if self._verbose:
            print(f"Selected choice(s):")
            for answer in validate_result.answers:
                print(f"Choice: {answer.choice}, Reason: {answer.reason}")

        # exit(0)

        return validate_result


        # message = chat_response.message
        # if "tool_calls" not in message.additional_kwargs:
        #     raise ValueError(
        #         "Expected tool_calls in ai_message.additional_kwargs, "
        #         "but none found."
        #     )
        #
        # tool_calls = message.additional_kwargs["tool_calls"]
        # return _parse_tool_calls(
        #     tool_calls,
        #     output_cls=self.output_cls,
        #     allow_multiple=self._allow_multiple,
        #     verbose=self._verbose,
        # )

    async def acall(
        self,
        llm_kwargs: Optional[Dict[str, Any]] = None,
        *args: Any,
        **kwargs: Any,
    ) -> Union[Model, List[Model]]:
        # llm_kwargs = llm_kwargs or {}
        # description = self._description_eval(**kwargs)
        #
        # openai_fn_spec = to_openai_tool(self._output_cls, description=description)
        #
        # messages = self._prompt.format_messages(llm=self._llm, **kwargs)
        #
        # chat_response = await self._llm.achat(
        #     messages=messages,
        #     tools=[openai_fn_spec],
        #     tool_choice=self._tool_choice,
        #     **llm_kwargs,
        # )
        # message = chat_response.message
        # if "tool_calls" not in message.additional_kwargs:
        #     raise ValueError(
        #         "Expected function call in ai_message.additional_kwargs, "
        #         "but none found."
        #     )
        #
        # tool_calls = message.additional_kwargs["tool_calls"]
        # return _parse_tool_calls(
        #     tool_calls,
        #     output_cls=self.output_cls,
        #     allow_multiple=self._allow_multiple,
        #     verbose=self._verbose,
        # )
        pass

    def stream_list(
        self,
        llm_kwargs: Optional[Dict[str, Any]] = None,
        *args: Any,
        **kwargs: Any,
    ) -> Generator[Model, None, None]:
        """Streams a list of objects."""
        # llm_kwargs = llm_kwargs or {}
        # messages = self._prompt.format_messages(llm=self._llm, **kwargs)
        #
        # description = self._description_eval(**kwargs)
        #
        # list_output_cls = create_list_model(self._output_cls)
        # openai_fn_spec = to_openai_tool(list_output_cls, description=description)
        #
        # chat_response_gen = self._llm.stream_chat(
        #     messages=messages,
        #     tools=[openai_fn_spec],
        #     tool_choice=_default_tool_choice(list_output_cls),
        #     **llm_kwargs,
        # )
        # # extract function call arguments
        # # obj_start_idx finds start position (before a new "{" in JSON)
        # obj_start_idx: int = -1  # NOTE: uninitialized
        # for stream_resp in chat_response_gen:
        #     kwargs = stream_resp.message.additional_kwargs
        #     tool_calls = kwargs["tool_calls"]
        #     if len(tool_calls) == 0:
        #         continue
        #
        #     # NOTE: right now assume only one tool call
        #     # TODO: handle parallel tool calls in streaming setting
        #     fn_args = kwargs["tool_calls"][0].function.arguments
        #
        #     # this is inspired by `get_object` from `MultiTaskBase` in
        #     # the openai_function_call repo
        #
        #     if fn_args.find("[") != -1:
        #         if obj_start_idx == -1:
        #             obj_start_idx = fn_args.find("[") + 1
        #     else:
        #         # keep going until we find the start position
        #         continue
        #
        #     new_obj_json_str, obj_start_idx = _get_json_str(fn_args, obj_start_idx)
        #     if new_obj_json_str is not None:
        #         obj_json_str = new_obj_json_str
        #         obj = self._output_cls.parse_raw(obj_json_str)
        #         if self._verbose:
        #             print(f"Extracted object: {obj.json()}")
        #         yield obj
        pass

    def _description_eval(self, **kwargs: Any) -> Optional[str]:
        description = kwargs.get("description", None)

        ## __doc__ checks if docstring is provided in the Pydantic Model
        if not (self._output_cls.__doc__ or description):
            raise ValueError(
                "Must provide description for your Pydantic Model. Either provide a docstring or add `description=<your_description>` to the method. Required to convert Pydantic Model to OpenAI Function."
            )

        ## If both docstring and description are provided, raise error
        if self._output_cls.__doc__ and description:
            raise ValueError(
                "Must provide either a docstring or a description, not both."
            )

        return description

    def set_callback_manager(self, callback_manager: CallbackManager) -> None:
        """Set callback manager."""
        # go through every module in module dict and set callback manager
        self.callback_manager = callback_manager
        # for module in self.module_dict.values():
        #     module.set_callback_manager(callback_manager)








