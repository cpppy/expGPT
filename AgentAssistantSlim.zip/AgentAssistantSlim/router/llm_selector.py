
'''
https://docs.llamaindex.ai/en/stable/examples/pipeline/query_pipeline_routing/?h=selector

'''


def main():

    from llama_index.core.query_engine import RouterQueryEngine
    from llama_index.core.selectors import LLMSingleSelector, LLMMultiSelector
    from llama_index.core.selectors import (
        PydanticMultiSelector,
        PydanticSingleSelector,
    )

    # query_engine = RouterQueryEngine(
    #     selector=PydanticSingleSelector.from_defaults(),
    #     query_engine_tools=[
    #         list_tool,
    #         vector_tool,
    #     ],
    # )

    from llama_index.llms.openai_like import OpenAILike

    # https://docs.llamaindex.ai/en/stable/examples/llm/vllm/
    llm = OpenAILike(
        # model="Qwen1.5-0.5B-Chat",
        # api_base="http://192.168.150.181:8000/v1",
        model='Mistral-7B-Instruct-v0.2',
        api_base="http://192.168.100.21:8000/v1",
        api_key='EMPTY',
        temperature=0,
        max_tokens=1000,
    )
    logging.info(f'llm is_chat_model: {llm.is_chat_model}')

    # single select
    DEFAULT_SINGLE_SELECT_PROMPT_TMPL = (
        "Some choices are given below. It is provided in a numbered list "
        "(1 to {num_choices}), "
        "where each item in the list corresponds to a summary.\n"
        "---------------------\n"
        "{context_list}"
        "\n---------------------\n"
        "Using only the choices above and not prior knowledge, return "
        "the choice that is most relevant to the question: '{query_str}'\n"
    )
    from llama_index.core.output_parsers.selection import SelectionOutputParser

    selector = LLMSingleSelector.from_defaults(
        llm=llm,
        prompt_template_str=DEFAULT_SINGLE_SELECT_PROMPT_TMPL,
        output_parser=SelectionOutputParser(),
    )

    print(f'selector prompts: {selector.get_prompts()}')

    from llama_index.core.tools.types import ToolMetadata, DefaultToolFnSchema
    from llama_index.core.schema import QueryBundle

    # fn_schema_str: {"type": "object", "properties": {"input": {"title": "Input", "type": "string"}}, "required": ["input"]}

    tools_metadata = [
        ToolMetadata(name='tool_1',
                     description='contain a name list of books in library, when user want to search a book, use this tool.',
                     fn_schema=DefaultToolFnSchema),
        ToolMetadata(name='tool_2',
                     description='contain a name list of fruit in shop, when user want to ask the price of one fruit, use this tool.',
                     fn_schema=DefaultToolFnSchema),
    ]

    ########### DEBUG ###########
    # ensemble prompt in llm.predict
    from llama_index.core.selectors.llm_selectors import _build_choices_text
    choices_text = _build_choices_text(choices=tools_metadata)

    # build prompt as input of llm
    query = QueryBundle(query_str='how much is the orange for 1kg ?')
    prompt_args = dict(
        num_choices=len(tools_metadata),
        context_list=choices_text,
        query_str=query.query_str,
    )
    formatted_prompt = llm._get_prompt(selector._prompt, **prompt_args)
    logging.debug(f'formatted_prompt: {formatted_prompt}')
    # exit(0)

    response = selector.select(
        choices=tools_metadata,  # List(ToolMetadata)
        query=QueryBundle(query_str='how much is the orange for 1kg ?'),  # QueryBundle
    )
    print(response)


if __name__=='__main__':
    import logging
    import sys

    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
    # logging.getLogger().addHandler(logging.StreamHandler(stream=sys.stdout))
    main()

