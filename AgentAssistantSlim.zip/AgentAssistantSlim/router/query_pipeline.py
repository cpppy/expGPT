from typing import List
from pydantic import BaseModel, Field
from llama_index.core.output_parsers import PydanticOutputParser


class Movie(BaseModel):
    """Object representing a single movie."""

    name: str = Field(..., description="Name of the movie.")
    year: int = Field(..., description="Year of the movie.")


class Movies(BaseModel):
    """Object representing a list of movies."""

    movies: List[Movie] = Field(..., description="List of movies.")


def main():

    from agents.demo_custom_agent_v2 import load_model
    llm = load_model(with_embedding=False)

    from llama_index.core.query_pipeline import QueryPipeline
    from llama_index.core import PromptTemplate

    output_parser = PydanticOutputParser(Movies)
    json_prompt_str = """
    Please generate related movies to {movie_name}. Output with the following JSON format: 
    """
    json_prompt_str = output_parser.format(json_prompt_str)

    # add JSON spec to prompt template
    json_prompt_tmpl = PromptTemplate(json_prompt_str)

    p = QueryPipeline(chain=[json_prompt_tmpl, llm, output_parser], verbose=True)

    # # create graph
    # from pyvis.network import Network
    # net = Network(notebook=True, cdn_resources="in_line", directed=True)
    # net.from_nx(p.dag)
    # net.show("rag_dag.html")

    # # another option using `pygraphviz`
    # from networkx.drawing.nx_agraph import to_agraph
    # from IPython.display import Image
    # agraph = to_agraph(p.dag)
    # agraph.layout(prog="dot")
    # agraph.draw('rag_dag.png')
    # # display(Image('rag_dag.png'))


    output = p.run(movie_name="Toy Story")

    logging.debug(f'output: {output}')

    # import time
    # time.sleep(600)



if __name__=='__main__':
    import logging
    import sys

    logging.basicConfig(stream=sys.stdout,
                        level=logging.DEBUG,
                        format="[%(levelname)s] %(filename)s[%(levelno)s]{%(funcName)s} %(message)s")

    main()

