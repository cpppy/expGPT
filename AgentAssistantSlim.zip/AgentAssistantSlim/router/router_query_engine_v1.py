
'''
https://docs.llamaindex.ai/en/stable/examples/low_level/router/?h=routerquery#define-routerqueryengine

router to matched branch

'''


def main():
    from llama_index.core import PromptTemplate

    choices = [
        "Useful for questions related to apples",
        "Useful for questions related to oranges",
    ]


    def get_choice_str(choices):
        choices_str = "\n\n".join(
            [f"{idx+1}. {c}" for idx, c in enumerate(choices)]
        )
        return choices_str


    choices_str = get_choice_str(choices)

    router_prompt0 = PromptTemplate(
        "Some choices are given below. It is provided in a numbered list (1 to"
        " {num_choices}), where each item in the list corresponds to a"
        " summary.\n---------------------\n{context_list}\n---------------------\nUsing"
        " only the choices above and not prior knowledge, return the top choices"
        " (no more than {max_outputs}, but only select what is needed) that are"
        " most relevant to the question: '{query_str}'\n"
    )

    from llama_index.llms.openai import OpenAI

    from agents.demo_custom_agent_v2 import load_model
    llm = load_model()

    def get_formatted_prompt(query_str):
        fmt_prompt = router_prompt0.format(
            num_choices=len(choices),
            max_outputs=2,
            context_list=choices_str,
            query_str=query_str,
        )
        return fmt_prompt

    query_str = "Can you tell me more about the amount of Vitamin C in apples"
    fmt_prompt = get_formatted_prompt(query_str)
    response = llm.complete(fmt_prompt)

    print(str(response))


if __name__ == '__main__':
    import logging
    import sys

    logging.basicConfig(stream=sys.stdout,
                        level=logging.DEBUG,
                        format="[%(levelname)s] %(filename)s[%(levelno)s]{%(funcName)s} %(message)s")

    # logging.getLogger().addHandler(logging.StreamHandler(stream=sys.stdout))
    main()




