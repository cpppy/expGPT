'''
https://docs.llamaindex.ai/en/stable/examples/query_engine/RouterQueryEngine/?h=router+selector

https://docs.llamaindex.ai/en/stable/examples/pipeline/query_pipeline_routing/?h=selector

'''

import os
os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'
os.environ['NUMEXPR_MAX_THREADS'] = '12'

def load_model():
    from llama_index.llms.openai_like import OpenAILike
    llm = OpenAILike(
        # model="Qwen1.5-0.5B-Chat",
        # api_base="http://192.168.150.181:8000/v1",
        model='Mistral-7B-Instruct-v0.2',
        api_base="http://192.168.100.21:8000/v1",
        api_key='EMPTY',
        temperature=0.,
        max_tokens=1000,
    )

    from llama_index.embeddings.huggingface import HuggingFaceEmbedding
    from llama_index.core import Settings

    Settings.embed_model = HuggingFaceEmbedding(
        model_name="BAAI/bge-small-en-v1.5"
        # model_name="BAAI/bge-small-zh-v1.5"
        # model_name = "BAAI/bge-large-zh-v1.5"
    )

    Settings.llm = llm
    return llm


def main():

    load_model()

    from llama_index.core import SimpleDirectoryReader

    # load documents
    documents = SimpleDirectoryReader("../documents/data/pdf/").load_data()

    from llama_index.core import Settings

    # initialize settings (set chunk size)
    Settings.chunk_size = 1024
    nodes = Settings.node_parser.get_nodes_from_documents(documents)

    from llama_index.core import StorageContext

    # initialize storage context (by default it's in-memory)
    storage_context = StorageContext.from_defaults()
    storage_context.docstore.add_documents(nodes)

    from llama_index.core import SummaryIndex
    from llama_index.core import VectorStoreIndex

    summary_index = SummaryIndex(nodes, storage_context=storage_context)
    vector_index = VectorStoreIndex(nodes, storage_context=storage_context)

    list_query_engine = summary_index.as_query_engine(
        response_mode="tree_summarize",
        use_async=True,
    )
    vector_query_engine = vector_index.as_query_engine()

    from llama_index.core.tools import QueryEngineTool

    list_tool = QueryEngineTool.from_defaults(
        query_engine=list_query_engine,
        description=(
            "Useful for summarization questions related to Paul Graham eassy on"
            " What I Worked On."
        ),
    )

    vector_tool = QueryEngineTool.from_defaults(
        query_engine=vector_query_engine,
        description=(
            "Useful for retrieving specific context from Paul Graham essay on What"
            " I Worked On."
        ),
    )

    from llama_index.core.query_engine import RouterQueryEngine
    from llama_index.core.selectors import LLMSingleSelector, LLMMultiSelector
    from llama_index.core.selectors import (
        PydanticMultiSelector,
        PydanticSingleSelector,
    )

    from router.llm_selector_rel import CustomLLMSingleSelector
    query_engine = RouterQueryEngine(
        # selector=PydanticSingleSelector.from_defaults(),
        selector=CustomLLMSingleSelector.from_defaults(),
        query_engine_tools=[
            list_tool,
            vector_tool,
        ],
    )

    response = query_engine.query("What is the summary of the document? Answer it in Chinese Language.")
    print(str(response))


if __name__=='__main__':
    import logging
    import sys

    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
    logging.getLogger().addHandler(logging.StreamHandler(stream=sys.stdout))
    main()

