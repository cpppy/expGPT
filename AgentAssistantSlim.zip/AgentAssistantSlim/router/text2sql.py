


from llama_index.core.query_engine import NLSQLTableQueryEngine
from llama_index.core.tools import QueryEngineTool


def main():

    from llama_index.core.tools import QueryEngineTool
    from sqlalchemy import (
        create_engine,
        MetaData,
        Table,
        Column,
        String,
        Integer,
        select,
        column,
    )
    from llama_index.core import SQLDatabase

    engine = create_engine("sqlite:///:memory:", future=True)
    # engine = create_engine("sqlite:///local_cache.db", future=True)
    metadata_obj = MetaData()
    # create city SQL table
    table_name = "city_stats"
    city_stats_table = Table(
        table_name,
        metadata_obj,
        Column("city_name", String(16), primary_key=True),
        Column("population", Integer),
        Column("country", String(16), nullable=False),
    )

    metadata_obj.create_all(engine)

    from sqlalchemy import insert

    rows = [
        {"city_name": "Toronto", "population": 2930000, "country": "Canada"},
        {"city_name": "Tokyo", "population": 13960000, "country": "Japan"},
        {"city_name": "Berlin", "population": 3645000, "country": "Germany"},
    ]
    for row in rows:
        stmt = insert(city_stats_table).values(**row)
        with engine.begin() as connection:
            cursor = connection.execute(stmt)

    sql_database = SQLDatabase(engine, include_tables=["city_stats"])

    from agents.demo_custom_agent_v2 import load_model
    llm = load_model()

    from llama_index.core.query_engine import NLSQLTableQueryEngine
    sql_query_engine = NLSQLTableQueryEngine(
        llm=llm,
        sql_database=sql_database,
        tables=["city_stats"],
        verbose=True,
    )
    sql_tool = QueryEngineTool.from_defaults(
        query_engine=sql_query_engine,
        name="sql_tool",
        description=(
            "Useful for translating a natural language query into a SQL query"
        ),
    )

    response = sql_tool.call('introduce some famous city to me.')
    print(f'response: {response}')



if __name__ == '__main__':
    import logging
    import sys

    logging.basicConfig(stream=sys.stdout,
                        level=logging.DEBUG,
                        format="[%(levelname)s] %(filename)s[%(levelno)s]{%(funcName)s} %(message)s")

    # logging.getLogger().addHandler(logging.StreamHandler(stream=sys.stdout))
    main()


