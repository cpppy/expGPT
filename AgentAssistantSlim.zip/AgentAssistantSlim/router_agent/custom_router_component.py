from typing import (
    Any,
    Dict,
    Set
)
from llama_index.core.utils import print_text

from llama_index.core.query_pipeline.components import RouterComponent

import logging
import json


class CustomRouterComponent(RouterComponent):

    def _run_component(self, **kwargs: Any) -> Any:
        logging.debug(
            f'[custom_router_component kwargs] {json.dumps(kwargs, indent=4, default=lambda o: o.__dict__, ensure_ascii=False)}')

        """Run component."""
        # for the output selection, run the corresponding component, aggregate into list
        sel_output = self.selector.select(self.choices, kwargs["query"])

        # assume one selection
        if len(sel_output.selections) != 1:
            raise ValueError("Expected one selection")
        component = self.components[sel_output.ind]
        log_str = f"Selecting component {sel_output.ind}: " f"{sel_output.reason}."
        if self.verbose:
            print_text(log_str + "\n", color="pink")
        # run component
        # run with input_keys of component
        return component.run_component(
            **{self._query_keys[sel_output.ind]: kwargs["query"]}
        ), log_str

    async def _arun_component(self, **kwargs: Any) -> Any:
        """Run component (async)."""
        pass

    def run_component(self, **kwargs: Any) -> Any:
        """Run component."""
        kwargs.update(self.partial_dict)
        kwargs = self.validate_component_inputs(kwargs)
        component_outputs, log_str = self._run_component(**kwargs)
        return self.validate_component_outputs(component_outputs), log_str

    async def arun_component(self, **kwargs: Any) -> Dict[str, Any]:
        pass
