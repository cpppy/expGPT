from llama_index.core.query_pipeline import (
    CustomQueryComponent,
    # InputKeys,
    # OutputKeys,
)
from llama_index.core.query_pipeline.components.input import InputKeys, OutputKeys

from typing import Dict, Any
from llama_index.core.llms.llm import LLM
from pydantic import Field

from llama_index.core import PromptTemplate
from llama_index.core.query_pipeline import QueryPipeline

import logging

class RelatedMovieComponent(CustomQueryComponent):
    """Related movie component."""

    llm: LLM = Field(..., description="OpenAI LLM")

    def _validate_component_inputs(
        self, input: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Validate component inputs during run_component."""
        # NOTE: this is OPTIONAL but we show you here how to do validation as an example
        return input

    @property
    def _input_keys(self) -> set:
        """Input keys dict."""
        # NOTE: These are required inputs. If you have optional inputs please override
        # `optional_input_keys_dict`
        return {"movie"}

    @property
    def _output_keys(self) -> set:
        return {"output"}

    def _run_component(self, **kwargs) -> Dict[str, Any]:
        """Run the component."""
        # use QueryPipeline itself here for convenience
        prompt_str = "Please generate related movies to {movie_name}"
        prompt_tmpl = PromptTemplate(prompt_str)
        p = QueryPipeline(chain=[prompt_tmpl, self.llm])
        # return {"output": p.run(movie_name=kwargs["movie"])}
        output = p.run(movie_name=kwargs["movie"])
        logging.debug(f'{self.__class__.__name__} output: {output}')
        return {"output": output}


def main():

    from agents.demo_custom_agent_v2 import load_model
    llm = load_model(with_embedding=False)

    component = RelatedMovieComponent(llm=llm)

    # let's add some subsequent prompts for fun
    prompt_str = """\
    Here's some text:

    {text}

    Can you rewrite this in the voice of Shakespeare?
    """
    prompt_tmpl = PromptTemplate(prompt_str)

    p = QueryPipeline(chain=[component, prompt_tmpl, llm], verbose=True)

    output = p.run(movie="Love Actually")
    print(f'---------------------- Final Result ----------------------------')
    print(output)




if __name__=='__main__':

    import logging
    import sys

    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
    # logging.getLogger().addHandler(logging.StreamHandler(stream=sys.stdout))
    main()



