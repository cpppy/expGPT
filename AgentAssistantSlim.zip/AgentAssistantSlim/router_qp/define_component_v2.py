from llama_index.core.query_pipeline import (
    CustomQueryComponent,
    # InputKeys,
    # OutputKeys,
)
from llama_index.core.query_pipeline.components.input import InputKeys#, OutputKeys
from llama_index.core.base.query_pipeline.query import OutputKeys

from typing import Dict, Any, Set
from llama_index.core.llms.llm import LLM
from pydantic import Field

from llama_index.core import PromptTemplate
from llama_index.core.query_pipeline import QueryPipeline, QueryComponent


class RelatedMovieComponent(CustomQueryComponent):
    """Related movie component."""

    llm: LLM = Field(..., description="OpenAI LLM")

    def _validate_component_inputs(
            self, input: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Validate component inputs during run_component."""
        # NOTE: this is OPTIONAL but we show you here how to do validation as an example
        return input

    @property
    def _input_keys(self) -> Set[str]:
        """Input keys dict."""
        # NOTE: These are required inputs. If you have optional inputs please override
        # `optional_input_keys_dict`
        return {"movie"}

    @property
    def _output_keys(self) -> Set[str]:
        return {"output"}

    # def _run_component(self, **kwargs) -> Dict[str, Any]:
    #     """Run the component."""
    #     # use QueryPipeline itself here for convenience
    #     prompt_str = "Please generate related movies to {movie_name}"
    #     prompt_tmpl = PromptTemplate(prompt_str)
    #     p = QueryPipeline(chain=[prompt_tmpl, self.llm])
    #     # return {"output": p.run(movie_name=kwargs["movie"])}
    #     output = p.run(movie_name=kwargs["movie"])
    #     logging.debug(f'{self.__class__.__name__} output: {output}')
    #     return {"output": output}

    def _run_component(self, **kwargs) -> Dict[str, Any]:
        """Run the component."""
        # use QueryPipeline itself here for convenience
        prompt_str = "Please generate related movies to {movie_name}"
        prompt_tmpl = PromptTemplate(prompt_str)
        # p = QueryPipeline(chain=[prompt_tmpl, self.llm])
        # return {"output": p.run(movie_name=kwargs["movie"])}
        # output = p.run(movie_name=kwargs["movie"])
        llm_output = self.llm.complete(prompt=prompt_tmpl.format(movie_name=kwargs['movie']))
        logging.debug(f'llm_output: {llm_output}')
        return {'output': {"llm_output": llm_output, "is_done": False}}


from llama_index.core.callbacks.base import CallbackManager


class DecisionComponent(QueryComponent):
    """ Decision Component """

    callback_manager: CallbackManager = Field(
        default_factory=CallbackManager, description="Callback manager"
    )

    class Config:
        arbitrary_types_allowed = True

    def _validate_component_inputs(self, input: Dict[str, Any]) -> Dict[str, Any]:
        """Validate component inputs during run_component."""
        return input

    def set_callback_manager(self, callback_manager: CallbackManager) -> None:
        """Set callback manager."""
        # TODO: refactor so that callback_manager is always passed in during runtime.
        self.callback_manager = callback_manager

    def _run_component(self, **kwargs: Any) -> Dict:
        """Run component."""
        logging.debug(f'input: {kwargs}')
        if kwargs['output']['is_done']:
            return {'output': 'task finished.'}
        else:
            return {'output': 'task failed.'}

    async def _arun_component(self, **kwargs: Any) -> Any:
        """Run component (async)."""
        pass

    @property
    def input_keys(self) -> InputKeys:
        """Input keys."""
        # NOTE: user can override this too, but we have them implement an
        # abstract method to make sure they do it

        return InputKeys.from_keys(
            required_keys=self._input_keys, optional_keys=self._optional_input_keys
        )

    @property
    def _optional_input_keys(self) -> Set[str]:
        """Optional input keys dict."""
        return set()

    @property
    def output_keys(self) -> OutputKeys:
        """Output keys."""
        # NOTE: user can override this too, but we have them implement an
        # abstract method to make sure they do it
        return OutputKeys.from_keys(self._output_keys)

    @property
    def _input_keys(self) -> set:
        """Input keys."""
        return {'output'}

    @property
    def _output_keys(self) -> Set[str]:
        """Output keys."""
        return {'output'}


def main():
    from agents.demo_custom_agent_v2 import load_model
    llm = load_model(with_embedding=False)

    component = RelatedMovieComponent(llm=llm)

    # let's add some subsequent prompts for fun
    prompt_str = """\
    Here's some text:

    {text}

    Can you rewrite this in the voice of Shakespeare?
    """
    prompt_tmpl = PromptTemplate(prompt_str)

    component2 = DecisionComponent()

    # p = QueryPipeline(
    #     chain=[
    #         component,
    #         component2,
    #         # prompt_tmpl, llm
    #     ],
    #     verbose=True
    # )
    p = QueryPipeline(verbose=True)
    p.add_modules(
        {
            'comp1': component,
            'comp2': component2,
        }
    )
    from typing import Union
    p.add_link(src='comp1', dest='comp2')

    output = p.run(movie="Love Actually")
    print(f'---------------------- Final Result ----------------------------')
    print(output)


if __name__ == '__main__':
    import logging
    import sys

    logging.basicConfig(stream=sys.stdout,
                        level=logging.DEBUG,
                        format="[%(levelname)s] %(filename)s[%(levelno)s]{%(funcName)s} %(message)s")

    main()
