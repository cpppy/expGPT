from typing import List
from pydantic import BaseModel, Field

'''
https://docs.llamaindex.ai/en/stable/examples/pipeline/query_pipeline/
'''


class Movie(BaseModel):
    """Object representing a single movie."""

    name: str = Field(..., description="Name of the movie.")
    year: int = Field(..., description="Year of the movie.")


class Movies(BaseModel):
    """Object representing a list of movies."""

    movies: List[Movie] = Field(..., description="List of movies.")


class Func1OutputData(BaseModel):
    """Output random of number"""
    random_num: int = Field(..., description="random num selected from [0, 1, 2].")
    task_status: bool = Field(..., description="is there any error in this task, True means success, False means fail.")


from router.custom_pydantic_program import CustomPydanticProgram

def main():

    from agents.demo_custom_agent_v2 import load_model
    llm = load_model(with_embedding=False)
    callback_manager = llm.callback_manager

    from llama_index.core.query_pipeline import QueryPipeline
    from llama_index.core import PromptTemplate

    # from llama_index.core.output_parsers import PydanticOutputParser
    # output_parser = PydanticOutputParser(Movies)

    TEMPLATE = """
Here's a JSON schema to follow:
{schema}

Output a valid JSON object but do not repeat the schema.
"""

    from router.parser import CustomPydanticOutputParser
    output_parser = CustomPydanticOutputParser(output_cls=Movies,
                                               pydantic_format_tmpl=TEMPLATE)

    json_prompt_str = """
    Please generate related movies to {movie_name}. Output with the following JSON format: 
    """
    json_prompt_str = output_parser.format(json_prompt_str)

    # add JSON spec to prompt template
    json_prompt_tmpl = PromptTemplate(json_prompt_str)

    # p = QueryPipeline(chain=[json_prompt_tmpl, llm, output_parser], verbose=True)

    # func1_prompt = PromptTemplate(
    #     "just introduce some thing about 1.'\n"
    # )
    #
    # func1_cell = CustomPydanticProgram.from_defaults(
    #     llm=llm,
    #     output_cls=Func1OutputData,
    #     output_parser=CustomPydanticOutputParser,
    #     prompt=func1_prompt,
    #
    # )

    from llama_index.core.query_pipeline import QueryComponent
    func1_cell = QueryComponent(

    )


    qp = QueryPipeline(verbose=True, callback_manager=callback_manager)
    qp.add_modules({
        'input': json_prompt_tmpl,
        'llm': llm,
        'output': output_parser,
        'func1': func1_cell,
    })
    qp.add_link(
        'input',
        'llm'
    )
    qp.add_link(
        'llm',
        'output'
    )
    qp.add_link(
        'output',
        'func1',
    )

    # p.add_link(
    #     "react_output_parser",
    #     "run_tool",
    #     condition_fn=lambda x: not x["done"],
    #     input_fn=lambda x: x["reasoning_step"],
    # )

    # # create graph
    # from pyvis.network import Network
    # net = Network(notebook=True, cdn_resources="in_line", directed=True)
    # net.from_nx(p.dag)
    # net.show("rag_dag.html")

    # # another option using `pygraphviz`
    # from networkx.drawing.nx_agraph import to_agraph
    # from IPython.display import Image
    # agraph = to_agraph(p.dag)
    # agraph.layout(prog="dot")
    # agraph.draw('rag_dag.png')
    # # display(Image('rag_dag.png'))


    # is_done, output = qp.run(movie_name="Toy Story")
    # logging.debug(f'output: {output}')
    # for movie in output.movies:
    #     print(f'name: {movie.name}, year: {movie.year}')

    output = qp.run(movie_name="Toy Story", callback_manager=callback_manager)
    logging.debug(f'output: {output}')

    # import time
    # time.sleep(600)



if __name__=='__main__':
    import logging
    import sys

    logging.basicConfig(stream=sys.stdout,
                        level=logging.DEBUG,
                        format="[%(levelname)s] %(filename)s[%(levelno)s]{%(funcName)s} %(message)s")

    main()

