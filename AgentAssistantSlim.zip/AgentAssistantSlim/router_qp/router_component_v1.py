
'''
https://docs.llamaindex.ai/en/stable/examples/pipeline/query_pipeline_routing/

'''

from llama_index.core import PromptTemplate
from llama_index.core.query_pipeline import QueryPipeline, RouterComponent

def main():

    from agents.demo_custom_agent_v2 import load_model
    llm = load_model(with_embedding=False)

    prompt_str = "[Movie] please answer the user's question about movie, Question: {query_str}"
    prompt_tmpl = PromptTemplate(prompt_str)

    qp1 = QueryPipeline(chain=[prompt_tmpl, llm])
    response = qp1.run(query_str='select a movie with a happy ending for the weekend rest time.')
    logging.debug(f'response: {response}')

    prompt_str = "[Fruit] please answer the user's question about fruit, Question: {query_str}"
    prompt_tmpl = PromptTemplate(prompt_str)

    qp2 = QueryPipeline(chain=[prompt_tmpl, llm])
    response = qp2.run(query_str='Can I eat some orange when headache ?')
    logging.debug(f'response: {response}')

    choices = [
        'if user ask something about movie, choose this action.',
        'if user ask something about fruit, choose this action.',
    ]

    from router.llm_selector_rel import CustomLLMSingleSelector
    selector = CustomLLMSingleSelector.from_defaults(llm=llm)

    router_c = RouterComponent(
        selector=selector,
        choices=choices,
        components=[qp1, qp2],
        verbose=True,
    )

    qp_router = QueryPipeline(chain=[router_c])
    output = qp_router.run("which kind of fruit is benefit for human's hair ?")
    print('----------------- final output --------------------')
    print(output)



if __name__ == '__main__':
    import logging
    import sys

    logging.basicConfig(stream=sys.stdout,
                        level=logging.DEBUG,
                        format="[%(levelname)s] %(filename)s[%(levelno)s]{%(funcName)s} %(message)s")

    main()

