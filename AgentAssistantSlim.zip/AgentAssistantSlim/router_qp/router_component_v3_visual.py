'''
https://docs.llamaindex.ai/en/stable/examples/pipeline/query_pipeline_routing/

'''

from llama_index.core import PromptTemplate
from llama_index.core.query_pipeline import QueryPipeline, RouterComponent

from llama_index.core.bridge.pydantic import Field, BaseModel


class ResponseClassify(BaseModel):
    """Evaluation of whether the response has an error."""

    has_error: bool = Field(
        ..., description="Whether the response has an error."
    )
    # new_question: str = Field(..., description="The suggested new question.")
    to_fruit_shop: bool = Field(...,
                                description="based on the response text, whether the user will go to a fruit shop at next step ?")
    explanation: str = Field(
        ...,
        description=(
            "The explanation for the error as well as for the new question."
            "Can include the direct stack trace as well."
        ),
    )


def condition_fn(x):
    logging.debug(f'condition_fn x: {x}')
    return x['to_fruit_shop']

def main():
    from agents.demo_custom_agent_v2 import load_model
    llm = load_model(with_embedding=False)

    prompt_str = "[Movie] please answer the user's question about movie, Question: {query_str}"
    prompt_tmpl = PromptTemplate(prompt_str)

    qp1 = QueryPipeline(chain=[prompt_tmpl, llm])
    response = qp1.run(query_str='select a movie with a happy ending for the weekend rest time.')
    logging.debug(f'response: {response}')

    prompt_str = "[Fruit] please answer the user's question about fruit, Question: {query_str}"
    prompt_tmpl = PromptTemplate(prompt_str)

    qp2 = QueryPipeline(chain=[prompt_tmpl, llm])
    response = qp2.run(query_str='Can I eat some orange when headache ?')
    logging.debug(f'response: {response}')

    choices = [
        'if user ask something about movie, choose this action.',
        'if user ask something about fruit, choose this action.',
    ]

    from router.llm_selector_rel import CustomLLMSingleSelector
    selector = CustomLLMSingleSelector.from_defaults(llm=llm)

    router_c = RouterComponent(
        selector=selector,
        choices=choices,
        components=[qp1, qp2],
        verbose=True,
    )

    # qp_router = QueryPipeline(chain=[router_c])
    # output = qp_router.run("which kind of fruit is benefit for human's hair ?")
    # print('----------------- final output --------------------')
    # print(output)

    # add branch
    from router.parser import CustomPydanticOutputParser
    from router.llm_program import CustomLLMTextCompletionProgram
    # prompt_str = "analyse the response from llm, then generate a new question about this topic, Response: {response_str}"
    # prompt_tmpl = PromptTemplate(prompt_str)
    # llm_program = CustomLLMTextCompletionProgram.from_defaults(
    #     # output_parser=PydanticOutputParser(output_cls=ResponseEval),
    #     # output_parser=CustomPydanticOutputParser(output_cls=ResponseEval),
    #     output_parser=CustomPydanticOutputParser(output_cls=ResponseClassify),
    #     prompt=prompt_tmpl,
    #     llm=llm,
    #     verbose=True,
    # )
    # # test llm_program
    # llm_p_output = llm_program(
    #     response_str='orange is good for human"s health.',
    # )
    # logging.debug(f'llm_p_output: {llm_p_output}')

    ### add output parser
    TEMPLATE = """
    Here's a JSON schema to follow:
    {schema}

    Output a valid JSON object but do not repeat the schema.
    """

    from router.parser import CustomPydanticOutputParser
    output_parser = CustomPydanticOutputParser(output_cls=ResponseClassify,
                                               pydantic_format_tmpl=TEMPLATE)

    json_prompt_str = """
        analyse the response from llm, give suggestion of the next step about this topic.
        \n Response: {response_str}. 
        \n Output with the following JSON format: 
        """
    json_prompt_str = output_parser.format(json_prompt_str)
    json_prompt_tmpl = PromptTemplate(json_prompt_str)
    qp_cls = QueryPipeline(chain=[json_prompt_tmpl, llm, output_parser])
    # qp_router = QueryPipeline(chain=[router_c, qp_cls])
    # output = qp_router.run("which kind of fruit is benefit for human's hair ?")
    # print('----------------- final output --------------------')
    # print(output)

    ## add action
    from router_qp.define_component_v3_branch import DecisionComponent
    from typing import Any, Dict
    class DecisionComponent_Fruit(DecisionComponent):

        def _run_component(self, **kwargs: Any) -> Dict:
            """Run component."""

            return {'output': f'SubPath of component: {self.__class__.__name__}.'}

    class DecisionComponent_Other(DecisionComponent):

        def _run_component(self, **kwargs: Any) -> Dict:
            """Run component."""
            return {'output': f'SubPath of component: {self.__class__.__name__}.'}

    # from llama_index.core.query_pipeline import InputComponent
    # input = InputComponent()
    qp_router = QueryPipeline(verbose=True)
    qp_router.add_modules(
        {
            'actions': router_c,
            'qp_cls': qp_cls,
            'subpath_0': DecisionComponent_Fruit(),
            'subpath_1': DecisionComponent_Other(),
        }
    )
    qp_router.add_chain(['actions', 'qp_cls'])
    qp_router.add_link(src='qp_cls', dest='subpath_0',
                       # condition_fn=condition_fn,
                       condition_fn=lambda x: x.to_fruit_shop,
                       input_fn=lambda x: x)

    qp_router.add_link(src='qp_cls', dest='subpath_1',
                       # condition_fn=condition_fn,
                       condition_fn=lambda x: not x.to_fruit_shop,
                       input_fn=lambda x: x)

    output = qp_router.run("which kind of fruit is benefit for human's hair ?")
    # output = qp_router.run('recommend a movie with a happy ending for the weekend.')
    # output = qp_router.run('给我推荐一种水果，要求对头发比较好的。')
    print('----------------- final output --------------------')
    print(output)

    # another option using `pygraphviz`
    from networkx.drawing.nx_agraph import to_agraph
    # from IPython.display import Image
    agraph = to_agraph(qp_router.dag)
    agraph.layout(prog="dot")
    agraph.draw(f'router_component_qp_dag.png')
    # display(Image('rag_dag.png'))


if __name__ == '__main__':
    import logging
    import sys

    logging.basicConfig(stream=sys.stdout,
                        level=logging.DEBUG,
                        format="[%(levelname)s] %(filename)s[%(levelno)s]{%(funcName)s} %(message)s")

    main()
