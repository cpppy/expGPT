from pyvis.network import Network

if __name__=='__main__':
    g = Network()
    g.add_node(0)
    g.add_node(1)
    g.add_edge(0, 1, title='link_0-1')
    g.show("basic.html", notebook=False)

    # from pyvis import network as net
    # import networkx as nx
    #
    # # %%
    # g = net.Network(notebook=False)
    # nxg = nx.complete_graph(5)
    # g.from_nx(nxg)
    #
    # # %%
    # g.show("example.html", notebook=False)
    # # g.save_graph('test.html')

    from pyvis.network import Network

    g = Network()
    g.add_node(0)
    g.add_node(1)
    g.add_edge(0, 1)
    template = g.templateEnv.get_template(g.path)
    g.template = template
    g.show("basic.html", notebook=False)





