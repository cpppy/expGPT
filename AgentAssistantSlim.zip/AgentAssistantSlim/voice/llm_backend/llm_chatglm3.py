from langchain.prompts import PromptTemplate
from langchain_community.llms.chatglm3 import ChatGLM3

from langchain_core.messages import AIMessage, HumanMessage
from langchain.prompts import (
        ChatPromptTemplate,
        MessagesPlaceholder,
        SystemMessagePromptTemplate,
        HumanMessagePromptTemplate,
    )
from langchain.chains import LLMChain
from langchain.memory import ConversationBufferMemory



def main():
    template = """{question}"""
    prompt = PromptTemplate.from_template(template)


    endpoint_url = "http://192.168.100.21:8010/v1/chat/completions"
    # endpoint_url = "http://127.0.0.1:8010/v1/chat/completions"

    # direct access endpoint in a proxied environment
    import os
    os.environ['NO_PROXY'] = '127.0.0.1'

    messages = [
        # AIMessage(content="我将从美国到中国来旅游，出行前希望了解中国的城市"),
        AIMessage(content="你是一个知识丰富的助手，你可以回答人类提出的任何问题，但是回答请尽量简短，尽量不要超过3句话。"),
        # AIMessage(content="You are a waiter in a hotel in America, "
        #                   "your customers are all speaking in English with you, "
        #                   "you should talk with them like a kindness friend. "
        #                   "Each answer should be less than 3 sentences. "
        #                   "Do not use too much words."),
    ]

    llm = ChatGLM3(
        endpoint_url=endpoint_url,
        max_tokens=1000,
        prefix_messages=messages,
        top_p=0.3,
        temperature=0.0,
    )
    # turn on with_history only when you want the LLM object to keep track of the conversation history
    # and send the accumulated context to the backend model api, which make it stateful. By default it is stateless.
    # llm.with_history = True

    llm_chain = LLMChain(prompt=prompt, llm=llm)

    # question = "北京和上海两座城市有什么不同？"
    # result = llm_chain.run(question)
    # print(result)

    # question = '四川高考分数线？'
    # result = llm_chain.run(question)
    # print(result)

    return llm, llm_chain


def glm3_with_memory():
    # template = """{question}"""
    # prompt = PromptTemplate.from_template(template)

    endpoint_url = "http://192.168.100.21:8010/v1/chat/completions"
    # endpoint_url = "http://127.0.0.1:8010/v1/chat/completions"

    # direct access endpoint in a proxied environment
    import os
    os.environ['NO_PROXY'] = '127.0.0.1'

    messages = [
        # AIMessage(content="我将从美国到中国来旅游，出行前希望了解中国的城市"),
        AIMessage(content="你是一个知识丰富的助手，你可以回答人类提出的任何问题，但是回答请尽量简短，尽量不要超过3句话。"),
        # AIMessage(content="You are a waiter in a hotel in America, "
        #                   "your customers are all speaking in English with you, "
        #                   "you should talk with them like a kindness friend. "
        #                   "Each answer should be less than 3 sentences. "
        #                   "Do not use too much words."),
    ]

    llm = ChatGLM3(
        endpoint_url=endpoint_url,
        max_tokens=1000,
        prefix_messages=messages,
        top_p=0.3,
        temperature=0.0,
    )

    prompt = ChatPromptTemplate(
        messages=[
            SystemMessagePromptTemplate.from_template(
                "You are a nice chatbot having a conversation with a human."
            ),
            # The `variable_name` here is what must align with memory
            MessagesPlaceholder(variable_name="chat_history"),
            HumanMessagePromptTemplate.from_template("{question}")
        ]
    )
    # Notice that we `return_messages=True` to fit into the MessagesPlaceholder
    # Notice that `"chat_history"` aligns with the MessagesPlaceholder name.
    memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)
    llm_chat = LLMChain(
        llm=llm,
        prompt=prompt,
        verbose=True,
        memory=memory
    )

    # # Notice that we just pass in the `question` variables - `chat_history` gets populated by memory
    # response = llm_chat({"question": "hi"})
    # print(response['text'])
    #
    # response = llm_chat({"question": "May I ask you some question?"})
    # print(response['text'])

    # response = conversation.run(question="what this word means?", chat_history=[
    #     HumanMessage(content="What does LLM stand for?"),
    #     AIMessage(content="Large language model"),
    # ], )
    return llm_chat


if __name__=='__main__':

    main()

    glm3_with_memory()




