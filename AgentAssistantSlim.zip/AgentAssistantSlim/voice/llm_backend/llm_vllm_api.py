
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_openai import ChatOpenAI

from langchain.prompts import (
    ChatPromptTemplate,
    MessagesPlaceholder,
    SystemMessagePromptTemplate,
    HumanMessagePromptTemplate,
)
from langchain.chains import LLMChain
from langchain.memory import ConversationBufferMemory


def load_llm_chat():

    inference_server_url = "http://localhost:8000/v1"

    chat = ChatOpenAI(
        model="Qwen1.5-0.5B-Chat",
        openai_api_key="EMPTY",
        openai_api_base=inference_server_url,
        max_tokens=5,
        temperature=0,
    )

    messages = [
        SystemMessage(
            content="You are a helpful assistant that translates English to Italian."
        ),
        HumanMessage(
            content="Translate the following sentence from English to Italian: I love programming."
        ),
    ]
    response = chat(messages)
    print(response)

    # template = (
    #     "You are a helpful assistant that translates {input_language} to {output_language}."
    # )
    # system_message_prompt = SystemMessagePromptTemplate.from_template(template)
    # human_template = "{text}"
    # human_message_prompt = HumanMessagePromptTemplate.from_template(human_template)
    #
    # chat_prompt = ChatPromptTemplate.from_messages(
    #     [system_message_prompt, human_message_prompt]
    # )
    #
    # # get a chat completion from the formatted messages
    # response = chat.invoke(
    #     chat_prompt.format_prompt(
    #         input_language="English", output_language="Italian", text="I love programming."
    #     ).to_messages()
    # )
    #
    # print(response)

def load_llm():

    from langchain_community.llms import VLLMOpenAI

    inference_server_url = "http://localhost:8000/v1"

    # import os
    # os.environ['NO_PROXY'] = '127.0.0.1'

    llm = VLLMOpenAI(
        openai_api_key="EMPTY",
        openai_api_base=inference_server_url,
        model_name="Qwen1.5-0.5B-Chat",
        # model_kwargs={"stop": ["."]},
    )
    print(llm.invoke("Rome is"))
    return llm

    # from langchain.chains import LLMChain
    # from langchain.prompts import PromptTemplate
    #
    # template = """Question: {question}
    #
    # Answer: Let's think step by step."""
    # prompt = PromptTemplate.from_template(template)
    #
    # llm_chain = LLMChain(prompt=prompt, llm=llm)
    #
    # question = "Who was the US president in the year the first Pokemon game was released?"
    #
    # print(llm_chain.invoke(question)['text'])


def load_llm_chat_with_memory():

    '''
    model='Mistral-7B-Instruct-v0.2',
    api_base="http://192.168.100.21:8000/v1",
    api_key='EMPTY',
    '''

    inference_server_url = "http://192.168.100.21:8000/v1"

    llm = ChatOpenAI(
        model="Mistral-7B-Instruct-v0.2",
        openai_api_key="EMPTY",
        openai_api_base=inference_server_url,
        max_tokens=1000,
        temperature=0,
    )
    prompt = ChatPromptTemplate(
        messages=[
            SystemMessagePromptTemplate.from_template(
                "You are a nice chatbot having a conversation with a human."
            ),
            # The `variable_name` here is what must align with memory
            MessagesPlaceholder(variable_name="chat_history"),
            HumanMessagePromptTemplate.from_template("{question}")
        ]
    )
    # Notice that we `return_messages=True` to fit into the MessagesPlaceholder
    # Notice that `"chat_history"` aligns with the MessagesPlaceholder name.
    memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)
    conversation = LLMChain(
        llm=llm,
        prompt=prompt,
        verbose=True,
        memory=memory
    )

    # # Notice that we just pass in the `question` variables - `chat_history` gets populated by memory
    # response = conversation({"question": "hi"})
    # print(response['text'])
    response = conversation.run(question='hi')
    print(response)
    response = conversation.run(question='how is the weather today?')
    print(response)
    return conversation


if __name__=='__main__':

    load_llm_chat_with_memory()

