from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain.schema.messages import AIMessage
from langchain_community.llms.chatglm3 import ChatGLM3
from langchain_core.messages import AIMessage, HumanMessage



def main():
    template = """{question}"""
    prompt = PromptTemplate.from_template(template)


    endpoint_url = "http://192.168.100.21:8010/v1/chat/completions"
    # endpoint_url = "http://127.0.0.1:8010/v1/chat/completions"

    # direct access endpoint in a proxied environment
    import os
    os.environ['NO_PROXY'] = '127.0.0.1'
    # os.environ['NO_PROXY'] = '192.168.100.21'

    messages = [
        # AIMessage(content="我将从美国到中国来旅游，出行前希望了解中国的城市"),
        AIMessage(content="欢迎问我任何问题。"),
    ]

    llm = ChatGLM3(
        endpoint_url=endpoint_url,
        max_tokens=80000,
        prefix_messages=messages,
        top_p=0.9,
    )
    # turn on with_history only when you want the LLM object to keep track of the conversation history
    # and send the accumulated context to the backend model api, which make it stateful. By default it is stateless.
    # llm.with_history = True

    llm_chain = LLMChain(prompt=prompt, llm=llm)

    # question = "北京和上海两座城市有什么不同？"
    #
    # result = llm_chain.run(question)
    # print(result)

    # question = '四川高考分数线？'
    # result = llm_chain.run(question)
    # print(result)

    return llm, llm_chain


def langchain_doc_example():

    from langchain.prompts import (
        ChatPromptTemplate,
        MessagesPlaceholder,
        SystemMessagePromptTemplate,
        HumanMessagePromptTemplate,
    )
    from langchain.chains import LLMChain
    from langchain.memory import ConversationBufferMemory

    endpoint_url = "http://192.168.100.21:8010/v1/chat/completions"
    # endpoint_url = "http://127.0.0.1:8010/v1/chat/completions"

    # # direct access endpoint in a proxied environment
    import os
    os.environ['NO_PROXY'] = '127.0.0.1'

    messages = [
        # AIMessage(content="我将从美国到中国来旅游，出行前希望了解中国的城市"),
        AIMessage(content="欢迎问我任何问题。"),
    ]

    llm = ChatGLM3(
        endpoint_url=endpoint_url,
        max_tokens=80000,
        prefix_messages=messages,
        top_p=0.9,
    )
    # print(llm.generate(prompts=['hi', 'hi']))
    # return llm
    # # llm = ChatOpenAI()
    prompt = ChatPromptTemplate(
        messages=[
            SystemMessagePromptTemplate.from_template(
                "You are a nice chatbot having a conversation with a human."
            ),
            # The `variable_name` here is what must align with memory
            MessagesPlaceholder(variable_name="chat_history"),
            HumanMessagePromptTemplate.from_template("{question}")
        ]
    )
    # Notice that we `return_messages=True` to fit into the MessagesPlaceholder
    # Notice that `"chat_history"` aligns with the MessagesPlaceholder name.
    # memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)
    conversation = LLMChain(
        llm=llm,
        prompt=prompt,
        verbose=True,
        # memory=memory
    )

    # # Notice that we just pass in the `question` variables - `chat_history` gets populated by memory
    # response = conversation({"question": "hi"})
    # print(response['text'])

    response = conversation.run(question="what this word means?", chat_history=[
            HumanMessage(content="What does LLM stand for?"),
            AIMessage(content="Large language model"),
        ],)
    print(response)

    return conversation



def langchain_chatglm3_model():

    from langchain.prompts import (
        ChatPromptTemplate,
        MessagesPlaceholder,
        SystemMessagePromptTemplate,
        HumanMessagePromptTemplate,
    )
    from langchain.chains import LLMChain
    from langchain.memory import ConversationBufferMemory

    endpoint_url = "http://192.168.100.21:8010/v1/chat/completions"
    # endpoint_url = "http://127.0.0.1:8010/v1/chat/completions"

    # # direct access endpoint in a proxied environment
    import os
    os.environ['NO_PROXY'] = '127.0.0.1'

    messages = [
        # AIMessage(content="我将从美国到中国来旅游，出行前希望了解中国的城市"),
        AIMessage(content="欢迎问我任何问题。"),
    ]

    llm = ChatGLM3(
        endpoint_url=endpoint_url,
        max_tokens=80000,
        prefix_messages=messages,
        top_p=0.9,
    )

    return llm
    # # print(llm.generate(prompts=['hi', 'hi']))
    # # return llm
    # # # llm = ChatOpenAI()
    # prompt = ChatPromptTemplate(
    #     messages=[
    #         SystemMessagePromptTemplate.from_template(
    #             "You are a nice chatbot having a conversation with a human."
    #         ),
    #         # The `variable_name` here is what must align with memory
    #         MessagesPlaceholder(variable_name="chat_history"),
    #         HumanMessagePromptTemplate.from_template("{question}")
    #     ]
    # )
    # # Notice that we `return_messages=True` to fit into the MessagesPlaceholder
    # # Notice that `"chat_history"` aligns with the MessagesPlaceholder name.
    # memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)
    # conversation = LLMChain(
    #     llm=llm,
    #     prompt=prompt,
    #     verbose=True,
    #     memory=memory
    # )
    #
    # # # Notice that we just pass in the `question` variables - `chat_history` gets populated by memory
    # # response = conversation({"question": "hi"})
    # # print(response['text'])
    # response = conversation.run(question='hi')
    # print(response)
    # return conversation

if __name__=='__main__':

    # main()
    langchain_doc_example()


    # kb_template = """Answer the question based only on the following context:
    # {context}
    #
    # Question: {question}
    # """
    # from langchain.prompts import PromptTemplate
    # prompt = PromptTemplate.from_template(kb_template)
    # question = prompt.format(context='123', question='456')
    # print(question)
