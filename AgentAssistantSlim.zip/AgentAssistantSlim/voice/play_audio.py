import torch
from TTS.api import TTS

import os

os.environ[
    'KMP_DUPLICATE_LIB_OK'] = 'True'  # to avoid duplicate clash on OpenMP package (may not be required, I haven't tidied up previous attempts)
import sounddevice as sd


def main():
    import wave
    from io import BytesIO
    # from picotts import PicoTTS
    #
    # picotts = PicoTTS()
    # picotts.voice = 'de-DE'
    # wav = picotts.synth_wav('Hallo Welt!')
    #
    # sd.play(wav, samplerate=22050)
    # status = sd.wait()  # Wait until file is done playing

    import soundfile as sf
    data, sr = sf.read('./sound/ping-82822.mp3')
    print(data.shape)
    import numpy as np
    data2 = np.concatenate([data, data], axis=0)

    sd.play(data, samplerate=sr * 2)  # 22050)
    import time
    time.sleep(1)

    sd.play(data2, samplerate=int(sr * 2)) #22050)
    status = sd.wait()  # Wait until file is done playing


if __name__ == '__main__':
    main()
