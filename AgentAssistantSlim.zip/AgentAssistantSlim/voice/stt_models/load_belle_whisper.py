import torch
import torch.nn as nn
import torch.nn.functional as F

from transformers import pipeline


class WhisperInfer:

    def __init__(self):
        self.transcriber = pipeline(
            task="automatic-speech-recognition",
            # model="BELLE-2/Belle-whisper-large-v3-zh",
            model="/data/Belle-whisper-large-v3-zh",
            device='cuda:0',
            torch_dtype=torch.bfloat16,
            # device='cpu',
        )

        self.transcriber.model.config.forced_decoder_ids = (
            self.transcriber.tokenizer.get_decoder_prompt_ids(
                language="zh",
                task="transcribe",
            )
        )

        # self.transcriber.model.generate()

    def run(self, audio):
        transcription = self.transcriber(audio,
                                         # generate_kwargs=dict(prompt='推荐一组营养早餐')
                                         )
        print(transcription)
        return transcription['text']


def main():

    tool = WhisperInfer()

    import soundfile as sf
    # audio, sr = sf.read('../audio.wav')
    audio, sr = sf.read('../audio_zh_test_1.wav')

    tool.run(audio)



if __name__ == '__main__':

    main()
