import os

os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'
os.environ['NUMEXPR_MAX_THREADS'] = '12'

from funasr import AutoModel


class FunASR:

    def __init__(self):
        # paraformer-zh is a multi-functional asr model
        # use vad, punc, spk or not as you need
        # model = AutoModel(model="paraformer-zh", model_revision="v2.0.4",
        #                   vad_model="fsmn-vad", vad_model_revision="v2.0.4",
        #                   punc_model="ct-punc-c", punc_model_revision="v2.0.4",
        #                   # spk_model="cam++", spk_model_revision="v2.0.2",
        #                   )
        self.model = AutoModel(
            model="/data/paraformer-zh-streaming", model_revision="v2.0.4",
            # model="fsmn-vad", model_revision="v2.0.4",
            # vad_model="fsmn-vad", vad_model_revision="v2.0.4",
            # punc_model="ct-punc-c", punc_model_revision="v2.0.4",
            # spk_model="cam++", spk_model_revision="v2.0.2",
        )

    def run(self, wave):
        res = self.model.generate(input=wave,
                                  # batch_size_s=300,
                                  cache={},
                                  hotword='伊春森工')
        print(res)
        return res['text']


def main():
    tool = FunASR()

    audio_path = "/data/AgentAssistant/voice/audio_zh_test_1.wav"

    import soundfile as sf
    audio, sr = sf.read(audio_path)

    tool.run(wave=audio)


if __name__ == '__main__':
    main()
