import os

os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'
os.environ['NUMEXPR_MAX_THREADS'] = '12'
import torch

import whisper


class WhisperInfer:

    def __init__(self):
        self.device = "cuda:0" if torch.cuda.is_available() else "cpu"
        self.model = whisper.load_model(
            # "large-v2",
            "medium",
            download_root="/data/AgentAssistant/voice/stt_models/whisper_model",
            device=self.device,
        )

    def run(self, wave):
        audio = whisper.pad_or_trim(wave)
        mel = whisper.log_mel_spectrogram(audio).to(self.device)

        # options = whisper.DecodingOptions(beam_size=5, prompt='伊春森工')

        # result = whisper.decode(self.model, mel, options)
        result = whisper.decode(self.model, mel)
        # print(result.text)
        return result.text


def main():

    audio_path = "/data/AgentAssistant/voice/audio_zh_test_1.wav"

    device = "cuda:0" if torch.cuda.is_available() else "cpu"
    audio = whisper.load_audio(audio_path)
    audio = whisper.pad_or_trim(audio)

    model = whisper.load_model(
        # "large-v2",
        "medium",
        download_root="./whisper_model/",
        device=device,
    )

    mel = whisper.log_mel_spectrogram(audio).to(model.device)

    options = whisper.DecodingOptions(beam_size=5, prompt='伊春森工')

    result = whisper.decode(model, mel, options)
    print(result.text)


if __name__=='__main__':

    main()

