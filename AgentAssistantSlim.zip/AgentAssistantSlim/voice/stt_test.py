import speech_recognition as sr
import pyttsx3
import time

import logging

engine = pyttsx3.init()


# init sound tag
import soundfile as sf
data_start, sr_start = sf.read('./sound/ping-82822.mp3')

import sounddevice as sd

import torch


def listen():
    r = sr.Recognizer()

    print("Calibrating...")
    print("Okay, go!")
    while True:
        try:
            # sd.play(data_start, samplerate=sr_start * 2)  # 22050)
            print("listening now...")
            with sr.Microphone() as source:
                audio = r.listen(source, timeout=2, phrase_time_limit=10)
            print("Recognizing...")
            # whisper model options are found here: https://github.com/openai/whisper#available-models-and-languages
            # other speech recognition models are also available.
            text = r.recognize_whisper(
                audio,
                # model="medium.en",
                # model="tiny.en",
                # model="small",
                model="medium",
                # model='large-v3',
                show_dict=True,
            )["text"]
            print(f'Human: {text}')
        except Exception as e:
            unrecognized_speech_text = (
                f"Sorry, I didn't catch that. Exception was: {e}s"
            )
            text = unrecognized_speech_text
            print(f'[ERROR QUERY] {text}')
            continue

        if len(text) < 6:
            print(f'[INVALID QUERY] {text}')
            continue

        # print(f'Speaker Over.')
        print(f'------------------------------------------')

        torch.cuda.empty_cache()


if __name__ == '__main__':

    logging.basicConfig(level=logging.INFO)

    listen()
