from transformers import pipeline
import scipy


def main():
    from transformers import AutoProcessor, AutoModel

    processor = AutoProcessor.from_pretrained(
        # "suno/bark"
        "/data/bark",
    )
    model = AutoModel.from_pretrained(
        # "suno/bark"
        "/data/bark"
    ).to("cuda")

    inputs = processor(
        # text=["Hello, my name is Suno. And, uh — and I like pizza. [laughs] But I also have other interests such as playing tic tac toe."],
        text=[
            "2024年艾山水文站任务书, 总则, 按照黄委水文局下达我局的责任目标及山东黄河防汛工作的需要，结合山东测区实际情况，参照水文业务相关标准制定本任务书。总的要求是: 以洪水测、报、整为中心，保证相应花园口水文站22000立方米每秒（花园口设防流量）流量以下的各级洪水测得到、测得准、报得出，对超标准洪水有对策。",
            # "完善制定测站管理制度，注重制度的可操作性、可执行性，提升管理水平；认真做好汛前准备工作，结合测站特性认真修订单站预报方案、洪水测报方案，对特殊水情及突发事件有应急预案；",
            # "严格执行“四随四不”制度，杜绝缺测、漏测等质量事故的发生；合理布置测次，完整控制水沙过程；",
            # "强化质量管理，加强学规练功，提高单次测验质量；认真做好即时资料整编工作，做到方法正确，成果合理可靠，符合刊印标准；",
            # "加强测站特性、水文规律的分析研究，为指导洪水测报做好基础工作；做好新技术、新仪器的研究与比测工作"
        ],
        return_tensors="pt",
    ).to("cuda")
    # print(inputs.keys())
    # for k, v in inputs.items():
    #     v.cuda()


    '''
    2024年艾山水文站任务书, 总则, 按照黄委水文局下达我局的责任目标及山东黄河防汛工作的需要，结合山东测区实际情况，参照水文业务相关标准制定本任务书。总的要求是: 以洪水测、报、整为中心，保证相应花园口水文站22000立方米每秒（花园口设防流量）流量以下的各级洪水测得到、测得准、报得出，对超标准洪水有对策。
            
    
    
    '''

    speech_values = model.generate(**inputs, do_sample=True)

    import scipy

    # sampling_rate = model.config.sample_rate
    sampling_rate = 24000
    scipy.io.wavfile.write("bark_gen_test1_shuiwen_notice.wav", rate=sampling_rate, data=speech_values.cpu().numpy().squeeze())



if __name__=='__main__':

    main()

