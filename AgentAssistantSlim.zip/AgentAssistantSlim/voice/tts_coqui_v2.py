from TTS.utils.manage import ModelManager
from TTS.utils.synthesizer import Synthesizer
import site
import sounddevice as sd


class CoQuiVoice:

    def __init__(self):
        self.synthesizer = self._load_model()

    def _load_model(self):
        # location = site.getsitepackages()[0]
        # path = location+"/TTS/.models.json"
        # path = "~/.local/lib/python3.10/site-packages/TTS/.models.json"
        path = '/data/TTS/TTS/.models.json'
        print(path)

        model_manager = ModelManager(path)

        model_manager.list_models()
        # exit(0)

        model_type = "tts_models/en/ljspeech/tacotron2-DDC"
        # model_type = "tts_models/en/ljspeech/tacotron2-DDC_ph"
        # model_type = 'tts_models/zh-CN/baker/tacotron2-DDC-GST'
        # model_type = 'tts_models/multilingual/multi-dataset/your_tts'
        # model_type = 'tts_models/multilingual/multi-dataset/xtts_v2'
        model_path, config_path, model_item = model_manager.download_model(model_type)
        # cache dir: ~/.local/share/tts

        voc_path, voc_config_path, _ = model_manager.download_model(model_item["default_vocoder"])
        voc_path, voc_config_path, _ = model_manager.download_model(model_item["default_vocoder"])

        # model_path = "/data/data/coqui_ai/"
        # config_path = "/data/data/coqui_ai/config.json"

        synthesizer = Synthesizer(
            tts_checkpoint=model_path,
            tts_config_path=config_path,
            vocoder_checkpoint=voc_path,
            vocoder_config=voc_config_path,
            use_cuda=True,
        )
        return synthesizer

    def generate_wav(self, text, lang='en'):
        wav = self.synthesizer.tts(text, language_name=lang)
        # synthesizer.save_wav(wav, "audio-1.wav")
        return wav

    def generate_and_play(self, text, lang='en'):
        wav = self.generate_wav(text, lang=lang)
        sd.play(wav, samplerate=22050)
        status = sd.wait()  # Wait until file is done playing


def main():

    coqui_tts = CoQuiVoice()

    text = "Hello from a machine"
    coqui_tts.generate_and_play(text)

    # text = "这本书是以程序员的角度来介绍计算机系统，主要内容是计算机体系结构与编译器和操作系统的交互，强调对计算机系统的概念理解。本书为程序员描述计算机系统的实现细节，目的是帮助程序员衔接计算机系统各个领域的知识，为程序员构造一个概念性的框架，能写出更高效、可移植，健壮的程序。"
    # coqui_tts.generate_and_play(text, lang='cn')



if __name__ == '__main__':
    main()
