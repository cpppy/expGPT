import os
os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'
os.environ['NUMEXPR_MAX_THREADS'] = '12'

from TTS.utils.manage import ModelManager
from TTS.utils.synthesizer import Synthesizer
import site
import sounddevice as sd


class CoQuiVoice:

    def __init__(self):
        self.synthesizer = self._load_model()

    def _load_model(self):
        # location = site.getsitepackages()[0]
        # path = location+"/TTS/.models.json"
        # path = "~/.local/lib/python3.10/site-packages/TTS/.models.json"
        path = '/data/TTS/TTS/.models.json'

        print(path)

        model_manager = ModelManager(path)

        model_manager.list_models()
        # exit(0)

        # model_type = "tts_models/en/ljspeech/tacotron2-DDC"
        # model_type = "tts_models/en/ljspeech/tacotron2-DDC_ph"
        model_type = 'tts_models/zh-CN/baker/tacotron2-DDC-GST'
        # model_type = 'tts_models/multilingual/multi-dataset/your_tts'
        # model_type = 'tts_models/multilingual/multi-dataset/xtts_v2'
        # model_type = 'tts_models/multilingual/multi-dataset/xtts_v1.1'
        # model_type = 'tts_models/multilingual/multi-dataset/bark'
        model_path, config_path, model_item = model_manager.download_model(model_type)
        # cache dir: ~/.local/share/tts

        print(model_path, config_path, model_item)

        print(f'model_path: {model_path}')
        print(f'config_path: {config_path}')

        '''
        /home/data/.local/share/tts/tts_models--multilingual--multi-dataset--xtts_v2 
        None 
        {
            'description': 'XTTS-v2.0.3 by Coqui with 17 languages.', 
            'hf_url': ['https://coqui.gateway.scarf.sh/hf-coqui/XTTS-v2/main/model.pth', 
                'https://coqui.gateway.scarf.sh/hf-coqui/XTTS-v2/main/config.json', 
                'https://coqui.gateway.scarf.sh/hf-coqui/XTTS-v2/main/vocab.json', 
                'https://coqui.gateway.scarf.sh/hf-coqui/XTTS-v2/main/hash.md5', 
                'https://coqui.gateway.scarf.sh/hf-coqui/XTTS-v2/main/speakers_xtts.pth'
                ], 
            'model_hash': '10f92b55c512af7a8d39d650547a15a7', 
            'default_vocoder': None, 
            'commit': '480a6cdf7', 
            'license': 'CPML', 
            'contact': 'info@coqui.ai', 
            'tos_required': True, 
            'model_type': 'tts_models', 'model_url': ['https://coqui.gateway.scarf.sh/hf-coqui/XTTS-v2/main/model.pth', 'https://coqui.gateway.scarf.sh/hf-coqui/XTTS-v2/main/config.json', 'https://coqui.gateway.scarf.sh/hf-coqui/XTTS-v2/main/vocab.json', 'https://coqui.gateway.scarf.sh/hf-coqui/XTTS-v2/main/hash.md5', 'https://coqui.gateway.scarf.sh/hf-coqui/XTTS-v2/main/speakers_xtts.pth']}
        '''

        # voc_path, voc_config_path, _ = model_manager.download_model(model_item["default_vocoder"])

        # vocoder_type = 'vocoder_models/universal/libri-tts/wavegrad'
        vocoder_type = 'vocoder_models/universal/libri-tts/fullband-melgan'
        voc_path, voc_config_path, _ = model_manager.download_model(vocoder_type)

        print(f'voc_path: {voc_path}')
        print(f'voc_config_path: {voc_config_path}')

        # model_path = '/home/data/.local/share/tts/tts_models--multilingual--multi-dataset--xtts_v2'
        # config_path = '/home/data/.local/share/tts/tts_models--multilingual--multi-dataset--xtts_v2/config.json'
        # voc_path = '~/.local/share/tts/vocoder_models--universal--libri-tts--fullband-melgan'
        # voc_config_path = '~/.local/share/tts/vocoder_models--universal--libri-tts--fullband-melgan'


        synthesizer = Synthesizer(
            tts_checkpoint=model_path,
            tts_config_path=config_path,
            vocoder_checkpoint=voc_path,
            vocoder_config=voc_config_path,
            use_cuda=True,
        )
        return synthesizer

    def generate_wav(self, text, lang='en', save=None):
        wav = self.synthesizer.tts(text, language_name=lang)
        if save is not None:
            self.synthesizer.save_wav(wav, save)
        return wav

    def generate_and_play(self, text, lang='en'):
        wav = self.generate_wav(text, lang=lang)
        sd.play(wav, samplerate=22050)
        status = sd.wait()  # Wait until file is done playing


def main():

    coqui_tts = CoQuiVoice()

    # text = "Hello from a machine"
    # coqui_tts.generate_and_play(text)


    # text = "这本书是以程序员的角度来介绍计算机系统，主要内容是计算机体系结构与编译器和操作系统的交互，强调对计算机系统的概念理解。本书为程序员描述计算机系统的实现细节，目的是帮助程序员衔接计算机系统各个领域的知识，为程序员构造一个概念性的框架，能写出更高效、可移植，健壮的程序。"
    # coqui_tts.generate_and_ply(text, lang='cn')

    text = "推荐一组营养早餐"
    coqui_tts.generate_wav(text=text, lang='zh', save='audio_zh_test_1.wav')


if __name__ == '__main__':
    main()
