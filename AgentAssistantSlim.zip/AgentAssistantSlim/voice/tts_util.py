import pyttsx4


'''
# https://github.com/Jiangshan00001/pyttsx4
engine type:
1 nsss
2 sapi5
3 espeak
4 coqui_ai_tts
'''
engine = pyttsx4.init("espeak")
voices = engine.getProperty('voices')
engine.setProperty('voice',voices[11].id) #English


def speak(text):
    engine.say(text)
    engine.runAndWait()


if __name__=='__main__':
    speak("Hello World and this is a test.")




























