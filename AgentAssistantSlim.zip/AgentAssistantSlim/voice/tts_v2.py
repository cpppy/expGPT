from elevenlabs import generate, play

# Generate audio
audio = generate(
 text="Hi! My name is Bella, nice to meet you!",
 # voice="Bella",
 model="eleven_monolingual_v1"
)

# Play audio
play(audio)

# # Save the audio to an MP3 file
# with open("output.mp3", "wb") as out:
#  out.write(audio)