import speech_recognition as sr
import pyttsx3
import time

import logging

engine = pyttsx3.init()

from elevenlabs import generate, play

from voice.llm_backend import llm_chatglm3
# llm, llm_chain = llm_chatglm3.main()
llm_chat = llm_chatglm3.glm3_with_memory()

# from voice.llm_backend import llm_vllm_api
# llm_chain = llm_vllm_api.load_llm_chat_with_memory()

from voice.tts_coqui_v3 import CoQuiVoice
coqui_tts = CoQuiVoice()

# init sound tag
import soundfile as sf
data_start, sr_start = sf.read('./sound/ping-82822.mp3')

import sounddevice as sd

import torch


def listen():
    r = sr.Recognizer()

    print("Calibrating...")
    print("Okay, go!")
    while True:
        try:
            sd.play(data_start, samplerate=sr_start * 2)  # 22050)
            print("listening now...")
            with sr.Microphone() as source:
                audio = r.listen(source, timeout=2, phrase_time_limit=10)
            print("Recognizing...")
            # whisper model options are found here: https://github.com/openai/whisper#available-models-and-languages
            # other speech recognition models are also available.
            text = r.recognize_whisper(
                audio,
                # model="medium.en",
                # model="tiny.en",
                # model="small",
                # model="medium",
                model='large-v3',
                show_dict=True,
                # load_options={'device': 'cuda:0'}
            )["text"]
            print(f'Human: {text}')
        except Exception as e:
            unrecognized_speech_text = (
                f"Sorry, I didn't catch that. Exception was: {e}s"
            )
            text = unrecognized_speech_text
            print(f'[ERROR QUERY] {text}')
            continue

        if len(text) < 3:
            print(f'[INVALID QUERY] {text}')
            continue

        # response_text = chatgpt_chain.predict(human_input=text)
        # response_text = f'response_{time.time()}'
        # response_text = llm_chain.run(text)
        # response_text = llm_chat({'question': text})['text']
        continue
        print(f'AI: {response_text}')
        # engine.say(response_text)
        # engine.runAndWait()

        # # Generate audio
        # audio = generate(
        #     # text="Hi! My name is Bella, nice to meet you!",
        #     # voice="Bella",
        #     response_text,
        #     model="eleven_monolingual_v1"
        # )

        # Play audio
        # play(audio)

        coqui_tts.generate_and_play(response_text, lang='cn')
        print(f'Speaker Over.')

        torch.cuda.empty_cache()


if __name__ == '__main__':

    logging.basicConfig(level=logging.INFO)

    listen()
